#!/usr/bin/env python3
import zipfile
import os
import json

base_path = "/workspaces/aethex.us"
exports_path = os.path.join(base_path, "_exports")

# Create exports directory
os.makedirs(exports_path, exist_ok=True)

zips = [
    ("Contribute.zip", "Contribute"),
    ("Events (2).zip", "Events"),
    ("gameforge.zip", "gameforge")
]

results = {}

for zip_file, folder_name in zips:
    zip_path = os.path.join(base_path, zip_file)
    extract_path = os.path.join(exports_path, folder_name)
    
    print(f"\n{'='*60}")
    print(f"Processing: {zip_file}")
    print(f"{'='*60}")
    
    if not os.path.exists(zip_path):
        print(f"ERROR: {zip_path} not found!")
        continue
    
    os.makedirs(extract_path, exist_ok=True)
    
    try:
        with zipfile.ZipFile(zip_path, 'r') as zf:
            # List contents first
            file_list = zf.namelist()
            print(f"\nContains {len(file_list)} files/folders")
            
            # Extract
            zf.extractall(extract_path)
            print(f"Extracted to: {extract_path}")
            
            results[folder_name] = {
                "file_count": len(file_list),
                "files": file_list
            }
            
    except Exception as e:
        print(f"ERROR extracting {zip_file}: {e}")

print("\n\n" + "="*60)
print("EXTRACTION COMPLETE")
print("="*60)

# List extracted contents
for folder_name in ["Contribute", "Events", "gameforge"]:
    folder_path = os.path.join(exports_path, folder_name)
    if os.path.exists(folder_path):
        print(f"\n{folder_name}/:")
        for root, dirs, files in os.walk(folder_path):
            level = root.replace(folder_path, '').count(os.sep)
            indent = ' ' * 2 * level
            print(f'{indent}{os.path.basename(root)}/')
            subindent = ' ' * 2 * (level + 1)
            for file in files:
                print(f'{subindent}{file}')
