# AeThex

Infrastructure for the Metaverse.

## About

AeThex provides foundational infrastructure for building immersive digital experiences. The platform is organized into three divisions:

- **Foundation** - Education, community programs, and mentorship for developers
- **Corporation** - Technology conglomerate powering digital ecosystems and platforms
- **Labs** - The Grid bounty platform for creators to ship code and earn rewards

## Tech Stack

- [Astro](https://astro.build) - Static site generator
- CSS with custom properties and animations
- Responsive design with mobile-first breakpoints

## Project Structure

```
/
├── public/
│   └── global.css          # Global styles
├── src/
│   ├── components/         # Reusable UI components
│   ├── layouts/
│   │   └── MainLayout.astro
│   └── pages/
│       ├── index.astro     # Homepage
│       ├── foundation.astro
│       ├── corporation.astro
│       ├── labs.astro
│       ├── products.astro
│       ├── community.astro
│       ├── docs.astro
│       └── about.astro
└── package.json
```

## Development

```sh
# Install dependencies
npm install

# Start dev server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## License

© 2026 AeThex
