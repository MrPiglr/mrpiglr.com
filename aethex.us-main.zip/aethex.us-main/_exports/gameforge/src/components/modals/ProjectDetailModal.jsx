import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, GitBranch, Clock, Calendar, CheckSquare, Layers, Users, Plus, Trash2, Eye, UserPlus, HardDrive } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import AssetManager from '@/components/AssetManager';
import ProjectTeamModal from '@/components/modals/ProjectTeamModal';

const TabButton = ({ isActive, onClick, children }) => (
  <button
    onClick={onClick}
    className={`px-4 py-2 text-sm font-mono uppercase transition-colors relative ${isActive ? 'text-green-400' : 'text-green-400/60 hover:text-green-400'}`}
  >
    {children}
    {isActive && <motion.div className="absolute bottom-0 left-0 right-0 h-0.5 bg-green-400" layoutId="tab-underline" />}
  </button>
);

const ProjectDetailModal = ({ isOpen, onClose, project, onDeleteProject, onOpenInviteTeam, onViewProfile }) => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('details');
  const [isTeamModalOpen, setTeamModalOpen] = useState(false);

  const handleDelete = async () => {
    try {
      await onDeleteProject(project.id);
      toast({ title: '> PROJECT DELETED', description: `Project "${project.title}" has been successfully deleted.` });
      onClose();
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error deleting project', description: error.message });
    }
  };

  const statusConfig = {
    'In Progress': { color: 'text-blue-400', bgColor: 'bg-blue-400/10' },
    'Completed': { color: 'text-green-400', bgColor: 'bg-green-400/10' },
    'On Hold': { color: 'text-yellow-400', bgColor: 'bg-yellow-400/10' },
    'Archived': { color: 'text-gray-500', bgColor: 'bg-gray-500/10' },
  };

  const currentStatus = statusConfig[project?.status] || statusConfig['Archived'];

  if (!isOpen || !project) return null;
  
  const renderContent = () => {
    switch(activeTab) {
      case 'details':
        return (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-bold text-green-400 font-mono uppercase mb-2">&gt; DESCRIPTION</h3>
              <p className="text-sm text-green-400/80 font-mono leading-relaxed">{project.description}</p>
            </div>
            <div className="space-y-4">
              <h3 className="font-bold text-green-400 font-mono uppercase mb-2">&gt; METADATA</h3>
              <div className="flex items-center text-sm"><GitBranch className="w-4 h-4 mr-3 text-green-400/70" /> <span className="font-mono text-green-400/80">Engine: <span className="text-green-300 font-bold">{project.engine}</span></span></div>
              <div className="flex items-center text-sm"><Layers className="w-4 h-4 mr-3 text-green-400/70" /> <span className="font-mono text-green-400/80">Priority: <span className="text-green-300 font-bold">{project.priority}</span></span></div>
              <div className="flex items-center text-sm"><Clock className="w-4 h-4 mr-3 text-green-400/70" /> <span className="font-mono text-green-400/80">Created: <span className="text-green-300 font-bold">{new Date(project.created_at).toLocaleDateString()}</span></span></div>
              <div className="flex items-center text-sm"><Calendar className="w-4 h-4 mr-3 text-green-400/70" /> <span className="font-mono text-green-400/80">Last Update: <span className="text-green-300 font-bold">{new Date(project.updated_at).toLocaleDateString()}</span></span></div>
            </div>
            <div>
              <h3 className="font-bold text-green-400 font-mono uppercase mb-2">&gt; TECHNOLOGIES</h3>
              <div className="flex flex-wrap gap-2">
                {project.technologies?.map(tech => <span key={tech} className="text-xs font-mono px-2 py-1 rounded cyber-border text-purple-400 border-purple-400/30">{tech}</span>)}
              </div>
            </div>
          </div>
        );
      case 'assets':
        return <AssetManager projectId={project.id} isModalView={true} />;
      case 'team':
        return <ProjectTeamModal projectId={project.id} onViewProfile={onViewProfile} onOpenInviteTeam={onOpenInviteTeam} />;
      default:
        return null;
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, y: -20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="cyber-card p-6 rounded-lg w-full max-w-4xl relative flex flex-col h-full max-h-[90vh]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex-shrink-0">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h2 className="text-2xl font-bold terminal-glow tracking-wider uppercase">{project.title}</h2>
                  <div className={`inline-flex items-center text-xs font-mono uppercase px-2 py-1 rounded mt-2 ${currentStatus.bgColor} ${currentStatus.color}`}>
                    <CheckSquare className="w-3 h-3 mr-2" />
                    {project.status}
                  </div>
                </div>
                <Button onClick={onClose} className="cyber-button p-2" variant="ghost"><X className="w-4 h-4" /></Button>
              </div>

              <div className="border-b border-green-400/20 mb-6">
                <AnimatePresence>
                  <motion.div className="flex space-x-4">
                    <TabButton isActive={activeTab === 'details'} onClick={() => setActiveTab('details')}>Details</TabButton>
                    <TabButton isActive={activeTab === 'assets'} onClick={() => setActiveTab('assets')}>Assets</TabButton>
                    <TabButton isActive={activeTab === 'team'} onClick={() => setActiveTab('team')}>Team</TabButton>
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>

            <div className="flex-grow overflow-y-auto pr-2 custom-scrollbar">
              {renderContent()}
            </div>

            <div className="flex-shrink-0 pt-6 mt-auto border-t border-green-400/20 flex justify-between items-center">
              <Button onClick={handleDelete} className="cyber-button" variant="destructive">
                <Trash2 className="w-4 h-4 mr-2" />
                DELETE
              </Button>
              <Button className="cyber-button">
                <Eye className="w-4 h-4 mr-2" />
                OPEN_PROJECT
              </Button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default ProjectDetailModal;