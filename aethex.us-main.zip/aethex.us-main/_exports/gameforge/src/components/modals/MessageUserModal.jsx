import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send, Loader2, MessageSquare, Mail as MailIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/customSupabaseClient';

const MessageUserModal = ({ isOpen, onClose, recipient }) => {
  const { toast } = useToast();
  const { user: currentUser, profile: currentUserProfile } = useAuth();
  const [message, setMessage] = useState('');
  const [subject, setSubject] = useState('');
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [conversationId, setConversationId] = useState(null);
  const [messageType, setMessageType] = useState('dm'); // 'dm' or 'email'
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isOpen]);

  const findOrCreateConversation = useCallback(async () => {
    if (!currentUser || !recipient) return;
    setLoading(true);
    try {
      const participantIds = [currentUser.id, recipient.id].sort();
      
      let { data: conv, error } = await supabase
        .from('conversations')
        .select('id')
        .contains('participant_ids', participantIds)
        .limit(1)
        .single();
      
      if (error && error.code !== 'PGRST116') { // PGRST116 means no rows found
        throw new Error(`Could not load conversation: ${error.message}`);
      }

      if (!conv) {
        const { data: newConv, error: newConvError } = await supabase
          .from('conversations')
          .insert({ participant_ids: participantIds, last_message_at: new Date().toISOString() })
          .select('id')
          .single();
        
        if (newConvError) {
          throw new Error(`Could not create conversation: ${newConvError.message}`);
        }
        conv = newConv;
      }
      
      setConversationId(conv.id);
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error', description: error.message });
      setLoading(false);
    }
  }, [currentUser, recipient, toast]);

  useEffect(() => {
    if (isOpen) {
      findOrCreateConversation();
    } else {
      setMessages([]);
      setConversationId(null);
      setMessage('');
      setSubject('');
      setMessageType('dm');
    }
  }, [isOpen, findOrCreateConversation]);

  const fetchMessages = useCallback(async (convId) => {
    setLoading(true);
    const { data, error } = await supabase
      .from('messages')
      .select('*, sender:sender_id(id, username)')
      .eq('conversation_id', convId)
      .order('created_at', { ascending: true });

    if (error) {
      toast({ variant: 'destructive', title: 'Error', description: 'Could not fetch messages.' });
    } else {
      setMessages(data);
    }
    setLoading(false);
  }, [toast]);

  useEffect(() => {
    if (!conversationId) {
        if(loading) setLoading(false);
        return;
    }

    fetchMessages(conversationId);

    const channel = supabase
      .channel(`messages:${conversationId}`)
      .on('postgres_changes', { 
        event: 'INSERT', 
        schema: 'public', 
        table: 'messages', 
        filter: `conversation_id=eq.${conversationId}` 
      }, (payload) => {
          const newMessage = {
              ...payload.new,
              sender: payload.new.sender_id === currentUser.id 
                  ? { id: currentUser.id, username: currentUserProfile.username }
                  : { id: recipient.id, username: recipient.username }
          };

          setMessages(currentMessages => {
              if (currentMessages.find(m => m.id === newMessage.id)) {
                  return currentMessages;
              }
              return [...currentMessages, newMessage];
          });
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [conversationId, toast, fetchMessages, currentUser.id, currentUserProfile.username, recipient.id, recipient.username]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (message.trim() === '' || !conversationId) return;
    if (messageType === 'email' && subject.trim() === '') {
      toast({ variant: 'destructive', title: 'Error', description: 'Subject is required for email-style messages.' });
      return;
    }
    
    const content = message.trim();
    const messageSubject = messageType === 'email' ? subject.trim() : null;

    const tempId = `temp_${Date.now()}`;
    const newMessage = {
      id: tempId,
      conversation_id: conversationId,
      sender_id: currentUser.id,
      content: content,
      subject: messageSubject,
      type: messageType,
      created_at: new Date().toISOString(),
      sender: {
        id: currentUser.id,
        username: currentUserProfile.username,
      }
    };

    setMessages(currentMessages => [...currentMessages, newMessage]);
    setMessage('');
    if (messageType === 'email') setSubject('');

    const { data: insertedMessage, error } = await supabase
      .from('messages')
      .insert({
        conversation_id: conversationId,
        sender_id: currentUser.id,
        content: content,
        subject: messageSubject,
        type: messageType,
      })
      .select()
      .single();

    if (error) {
      toast({ variant: 'destructive', title: 'Error sending message', description: error.message });
      setMessages(currentMessages => currentMessages.filter(m => m.id !== tempId));
      setMessage(content);
      if (messageType === 'email') setSubject(messageSubject);
    } else {
        setMessages(currentMessages => 
            currentMessages.map(m => m.id === tempId ? { ...m, ...insertedMessage, id: insertedMessage.id } : m)
        );
    }
  };

  if (!recipient) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, y: -20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="cyber-card p-6 rounded-lg w-full max-w-2xl relative flex flex-col h-[80vh] max-h-[700px]"
            onClick={(e) => e.stopPropagation()}
          >
            <Button onClick={onClose} className="absolute top-4 right-4 cyber-button p-2" variant="ghost"><X className="w-4 h-4" /></Button>
            <div className="flex-shrink-0">
              <h2 className="text-xl font-bold terminal-glow tracking-wider uppercase mb-2">
                &gt; MESSAGE: <span className="text-cyan-400">{recipient.username}</span>
              </h2>
              <div className="flex space-x-2 border-b border-green-400/20 pb-4 mb-4">
                <Button onClick={() => setMessageType('dm')} variant={messageType === 'dm' ? 'secondary' : 'ghost'} className="cyber-button text-xs h-8">
                  <MessageSquare className="w-4 h-4 mr-2" /> Direct Message
                </Button>
                <Button onClick={() => setMessageType('email')} variant={messageType === 'email' ? 'secondary' : 'ghost'} className="cyber-button text-xs h-8">
                  <MailIcon className="w-4 h-4 mr-2" /> Email-Style
                </Button>
              </div>
            </div>
            
            <div className="flex-grow overflow-y-auto pr-2 space-y-4 mb-4 custom-scrollbar">
              {loading && messages.length === 0 ? (
                <div className="flex justify-center items-center h-full">
                  <Loader2 className="w-8 h-8 text-green-400 animate-spin" />
                </div>
              ) : (
                messages.map((msg) => (
                  <div key={msg.id} className={`flex flex-col ${msg.sender_id === currentUser.id ? 'items-end' : 'items-start'}`}>
                    <div className={`max-w-md px-4 py-2 rounded-lg font-mono text-sm ${msg.sender_id === currentUser.id ? 'bg-green-400/10 text-green-300' : 'bg-gray-500/10 text-gray-300'}`}>
                      {msg.subject && <p className="font-bold text-cyan-400 border-b border-cyan-400/20 pb-1 mb-2">{msg.subject}</p>}
                      <p className="whitespace-pre-wrap">{msg.content}</p>
                      <p className="text-xs text-gray-500 mt-1 text-right">{new Date(msg.created_at).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</p>
                    </div>
                  </div>
                ))
              )}
              <div ref={messagesEndRef} />
            </div>

            <form onSubmit={handleSendMessage} className="flex-shrink-0 space-y-2">
              {messageType === 'email' && (
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Subject..."
                  className="w-full bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono placeholder-green-400/50 focus:outline-none focus:ring-2 focus:ring-green-400/50"
                  disabled={loading || !conversationId}
                />
              )}
              <div className="flex space-x-2">
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Type your message..."
                  className="flex-grow bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono placeholder-green-400/50 focus:outline-none focus:ring-2 focus:ring-green-400/50 resize-none h-20"
                  disabled={loading || !conversationId}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage(e);
                    }
                  }}
                />
                <Button type="submit" className="cyber-button self-end" disabled={loading || message.trim() === '' || !conversationId}>
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default MessageUserModal;