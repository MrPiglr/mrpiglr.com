import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const BroadcastMessageModal = ({ isOpen, onClose }) => {
  const { toast } = useToast();

  const handleSubmit = (e) => {
    e.preventDefault();
    toast({
      title: '> MESSAGE BROADCASTED',
      description: 'Your message has been sent to all active users.',
    });
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, y: -20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="cyber-card p-8 rounded-lg w-full max-w-lg relative"
            onClick={(e) => e.stopPropagation()}
          >
            <Button onClick={onClose} className="absolute top-4 right-4 cyber-button p-2" variant="ghost"><X className="w-4 h-4" /></Button>
            <h2 className="text-2xl font-bold terminal-glow tracking-wider uppercase mb-6">&gt; BROADCAST_MESSAGE</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <textarea rows="5" placeholder="Enter your message..." className="w-full bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono placeholder-green-400/50 focus:outline-none focus:ring-2 focus:ring-green-400/50" />
              <div className="flex justify-end">
                <Button type="submit" className="cyber-button">
                  <Send className="w-4 h-4 mr-2" />
                  SEND
                </Button>
              </div>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default BroadcastMessageModal;