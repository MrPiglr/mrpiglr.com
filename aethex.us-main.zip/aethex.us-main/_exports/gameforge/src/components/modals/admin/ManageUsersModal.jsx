import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Search, Plus, UserX } from 'lucide-react';
import { Button } from '@/components/ui/button';
import UserFormModal from '@/components/modals/admin/UserFormModal';
import ConfirmationModal from '@/components/modals/ConfirmationModal';

const ManageUsersModal = ({ isOpen, onClose, users, onAddUser, onEditUser, onDeleteUser }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isFormModalOpen, setFormModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState(null);
  const [isConfirmModalOpen, setConfirmModalOpen] = useState(false);
  const [deletingUserId, setDeletingUserId] = useState(null);

  const handleOpenFormModal = (user = null) => {
    setEditingUser(user);
    setFormModalOpen(true);
  };

  const handleCloseFormModal = () => {
    setEditingUser(null);
    setFormModalOpen(false);
  };

  const handleSaveUser = (userData) => {
    if (editingUser) {
      onEditUser({ ...editingUser, ...userData });
    } else {
      onAddUser(userData);
    }
    handleCloseFormModal();
  };

  const openDeleteConfirm = (userId) => {
    setDeletingUserId(userId);
    setConfirmModalOpen(true);
  };

  const confirmDelete = () => {
    onDeleteUser(deletingUserId);
    setConfirmModalOpen(false);
    setDeletingUserId(null);
  };

  const filteredUsers = users.filter(user => {
    const lowerCaseSearchTerm = searchTerm.toLowerCase();
    const name = user.name || '';
    const email = user.email || '';
    const role = user.role || '';

    return name.toLowerCase().includes(lowerCaseSearchTerm) ||
           email.toLowerCase().includes(lowerCaseSearchTerm) ||
           role.toLowerCase().includes(lowerCaseSearchTerm);
  });

  return (
    <>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50"
            onClick={onClose}
          >
            <motion.div
              initial={{ scale: 0.9, y: -20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="cyber-card p-8 rounded-lg w-full max-w-3xl relative"
              onClick={(e) => e.stopPropagation()}
            >
              <Button onClick={onClose} className="absolute top-4 right-4 cyber-button p-2" variant="ghost"><X className="w-4 h-4" /></Button>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold terminal-glow tracking-wider uppercase">&gt; MANAGE_USERS</h2>
                <Button onClick={() => handleOpenFormModal()} className="cyber-button">
                  <Plus className="w-4 h-4 mr-2" />
                  ADD_USER
                </Button>
              </div>
              <div className="flex-1 relative mb-4">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-green-400/50" />
                <input
                  type="text"
                  placeholder="SEARCH_USERS..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full bg-black/50 cyber-border rounded px-10 py-2 text-green-400 font-mono placeholder-green-400/50 focus:outline-none focus:ring-2 focus:ring-green-400/50"
                />
              </div>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {filteredUsers.map(user => (
                  <div key={user.id} className="p-3 cyber-border rounded bg-green-400/5 flex justify-between items-center">
                    <div>
                      <p className="text-green-400 font-mono">{user.name || 'N/A'} ({user.email || 'N/A'})</p>
                      <p className="text-xs text-green-400/70 font-mono">{user.role || 'N/A'} - <span className={user.status === 'Active' ? 'text-green-400' : 'text-red-400'}>{user.status || 'Unknown'}</span></p>
                    </div>
                    <div className="flex space-x-2">
                      <Button onClick={() => handleOpenFormModal(user)} variant="outline" size="sm" className="cyber-button">Edit</Button>
                      <Button onClick={() => openDeleteConfirm(user.id)} variant="destructive" size="sm" className="cyber-button">Delete</Button>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <UserFormModal
        isOpen={isFormModalOpen}
        onClose={handleCloseFormModal}
        onSave={handleSaveUser}
        user={editingUser}
      />

      <ConfirmationModal
        isOpen={isConfirmModalOpen}
        onClose={() => setConfirmModalOpen(false)}
        onConfirm={confirmDelete}
        title="> CONFIRM_DELETION"
        icon={<UserX className="w-12 h-12 text-red-400" />}
      >
        <p className="text-green-400/80 font-mono text-center">Are you sure you want to delete this user?</p>
        <p className="text-yellow-400/80 font-mono text-sm text-center mt-2">This action is irreversible.</p>
      </ConfirmationModal>
    </>
  );
};

export default ManageUsersModal;