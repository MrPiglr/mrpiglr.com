import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Save, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { usePresence } from '@/context/PresenceContext';

const ManagePermissionsModal = ({ isOpen, onClose, user }) => {
  const { toast } = useToast();
  const [selectedRole, setSelectedRole] = useState('');
  const [loading, setLoading] = useState(false);
  const { refetchTeamMembers } = usePresence();

  useEffect(() => {
    if (user) {
      setSelectedRole(user.role);
    }
  }, [user]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);

    try {
      const { error } = await supabase.rpc('update_user_role_by_admin', {
        target_user_id: user.id,
        new_role: selectedRole,
      });

      if (error) throw error;

      toast({
        title: '> PERMISSIONS SAVED',
        description: `User ${user.username}'s role has been updated to ${selectedRole}.`,
      });
      
      setTimeout(() => {
         window.location.reload();
      }, 1000);


      onClose();
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Error updating role',
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };
  
  const roles = ['owner', 'admin', 'editor', 'member'];

  if (!user) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, y: -20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="cyber-card p-8 rounded-lg w-full max-w-md relative"
            onClick={(e) => e.stopPropagation()}
          >
            <Button onClick={onClose} className="absolute top-4 right-4 cyber-button p-2" variant="ghost"><X className="w-4 h-4" /></Button>
            <h2 className="text-2xl font-bold terminal-glow tracking-wider uppercase mb-2">&gt; MANAGE_PERMISSIONS</h2>
            <p className="text-green-400/70 font-mono mb-6">For user: <span className="text-cyan-400">{user.username}</span></p>
            <form onSubmit={handleSubmit}>
              <div className="space-y-4">
                <label htmlFor="role-select" className="text-sm font-mono text-green-400/80">Select Role:</label>
                <select
                  id="role-select"
                  value={selectedRole}
                  onChange={(e) => setSelectedRole(e.target.value)}
                  className="w-full appearance-none bg-black/50 cyber-border rounded px-4 py-3 text-green-400 font-mono placeholder-green-400/50 focus:outline-none focus:ring-2 focus:ring-green-400/50"
                >
                  {roles.map(role => (
                    <option key={role} value={role} className="capitalize">{role.charAt(0).toUpperCase() + role.slice(1)}</option>
                  ))}
                </select>
              </div>
              <div className="flex justify-end mt-6">
                <Button type="submit" className="cyber-button" disabled={loading}>
                  {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                  SAVE
                </Button>
              </div>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default ManagePermissionsModal;