import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const SystemLogsModal = ({ isOpen, onClose }) => {
  const logs = [
    `[INFO] 2025-08-08 14:30:15 - User 'MRPIGLR' logged in.`,
    `[WARN] 2025-08-08 14:32:01 - High memory usage detected on build server.`,
    `[ERROR] 2025-08-08 14:35:45 - Failed to connect to payment gateway.`,
    `[INFO] 2025-08-08 14:40:22 - Project 'CyberPunk RPG' build succeeded.`
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, y: -20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="cyber-card p-8 rounded-lg w-full max-w-4xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <Button onClick={onClose} className="absolute top-4 right-4 cyber-button p-2" variant="ghost"><X className="w-4 h-4" /></Button>
            <h2 className="text-2xl font-bold terminal-glow tracking-wider uppercase mb-6">&gt; SYSTEM_LOGS</h2>
            <div className="bg-black/80 cyber-border rounded p-4 font-mono text-xs max-h-96 overflow-y-auto">
              {logs.map((log, index) => (
                <p key={index} className="whitespace-pre-wrap">{log}</p>
              ))}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default SystemLogsModal;