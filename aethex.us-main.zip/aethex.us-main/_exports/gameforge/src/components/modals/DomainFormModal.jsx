import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Save, Link } from 'lucide-react';
import { Button } from '@/components/ui/button';

const DomainFormModal = ({ isOpen, onClose, onSave, domain }) => {
  const [formData, setFormData] = useState({
    url: '',
    status: 'active',
  });

  useEffect(() => {
    if (domain) {
      setFormData(domain);
    } else {
      setFormData({
        url: '',
        status: 'active',
      });
    }
  }, [domain, isOpen]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, y: -20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="cyber-card p-8 rounded-lg w-full max-w-lg relative"
            onClick={(e) => e.stopPropagation()}
          >
            <Button onClick={onClose} className="absolute top-4 right-4 cyber-button p-2" variant="ghost"><X className="w-4 h-4" /></Button>
            <h2 className="text-2xl font-bold terminal-glow tracking-wider uppercase mb-6">
              {domain ? '> EDIT_DOMAIN' : '> ADD_DOMAIN'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="relative">
                <Link className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-green-400/50" />
                <input name="url" value={formData.url} onChange={handleChange} placeholder="domain.tld" className="w-full bg-black/50 cyber-border rounded px-10 py-3 text-green-400 font-mono placeholder-green-400/50 focus:outline-none focus:ring-2 focus:ring-green-400/50" required />
              </div>
              <div className="relative">
                <select name="status" value={formData.status} onChange={handleChange} className="w-full appearance-none bg-black/50 cyber-border rounded px-4 py-3 text-green-400 font-mono placeholder-green-400/50 focus:outline-none focus:ring-2 focus:ring-green-400/50">
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>
              <div className="flex justify-end">
                <Button type="submit" className="cyber-button">
                  <Save className="w-4 h-4 mr-2" />
                  SAVE
                </Button>
              </div>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default DomainFormModal;