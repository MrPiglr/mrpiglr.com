import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Plus, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';

const CreateProjectModal = ({ isOpen, onClose, onSave, project }) => {
  const [loading, setLoading] = React.useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const formData = new FormData(e.target);
    const projectData = {
      title: formData.get('title'),
      description: formData.get('description'),
      engine: formData.get('engine'),
      status: formData.get('status'),
      priority: formData.get('priority'),
      progress: parseInt(formData.get('progress'), 10) || 0,
    };
    await onSave(projectData);
    setLoading(false);
  };
  
  const isEditing = !!project;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, y: -20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="cyber-card p-8 rounded-lg w-full max-w-lg relative"
            onClick={(e) => e.stopPropagation()}
          >
            <Button onClick={onClose} className="absolute top-4 right-4 cyber-button p-2" variant="ghost"><X className="w-4 h-4" /></Button>
            <h2 className="text-2xl font-bold terminal-glow tracking-wider uppercase mb-6">
              &gt; {isEditing ? 'EDIT_PROJECT' : 'CREATE_NEW_PROJECT'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm text-green-400/70 font-mono uppercase mb-2">Project Title</label>
                <input
                  name="title"
                  defaultValue={project?.title}
                  placeholder="e.g., CyberPunk RPG"
                  className="w-full bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono placeholder-green-400/50 focus:outline-none focus:ring-2 focus:ring-green-400/50"
                  required
                />
              </div>
              <div>
                <label className="block text-sm text-green-400/70 font-mono uppercase mb-2">Description</label>
                <textarea
                  name="description"
                  defaultValue={project?.description}
                  rows={3}
                  placeholder="A brief description of your project..."
                  className="w-full bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono placeholder-green-400/50 focus:outline-none focus:ring-2 focus:ring-green-400/50"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-green-400/70 font-mono uppercase mb-2">Game Engine</label>
                  <select name="engine" defaultValue={project?.engine || 'Unity'} className="w-full bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono focus:outline-none focus:ring-2 focus:ring-green-400/50">
                    <option>Unity</option>
                    <option>Unreal Engine</option>
                    <option>Godot</option>
                    <option>Roblox</option>
                    <option>Custom</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm text-green-400/70 font-mono uppercase mb-2">Status</label>
                  <select name="status" defaultValue={project?.status || 'planning'} className="w-full bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono focus:outline-none focus:ring-2 focus:ring-green-400/50">
                    <option value="planning">Planning</option>
                    <option value="active">Active</option>
                    <option value="paused">Paused</option>
                    <option value="completed">Completed</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm text-green-400/70 font-mono uppercase mb-2">Priority</label>
                  <select name="priority" defaultValue={project?.priority || 'medium'} className="w-full bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono focus:outline-none focus:ring-2 focus:ring-green-400/50">
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                  </select>
                </div>
                 <div>
                    <label className="block text-sm text-green-400/70 font-mono uppercase mb-2">Progress (%)</label>
                    <input
                      name="progress"
                      type="number"
                      defaultValue={project?.progress || 0}
                      min="0"
                      max="100"
                      className="w-full bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono placeholder-green-400/50 focus:outline-none focus:ring-2 focus:ring-green-400/50"
                    />
                </div>
              </div>
              <div className="flex justify-end pt-4">
                <Button type="submit" className="cyber-button" disabled={loading}>
                  {loading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Plus className="w-4 h-4 mr-2" />}
                  {isEditing ? 'SAVE_CHANGES' : 'CREATE_PROJECT'}
                </Button>
              </div>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default CreateProjectModal;