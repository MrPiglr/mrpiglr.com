import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { UserPlus, Mail, Eye, Crown, Shield, Star, Users, Loader2, Circle, Coffee, Moon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';
import { usePresence } from '@/context/PresenceContext';

const ProjectTeamModal = ({ projectId, onViewProfile, onOpenInviteTeam }) => {
  const { toast } = useToast();
  const [team, setTeam] = useState([]);
  const [loading, setLoading] = useState(true);
  const { teamMembers: allUsers, getStatusForUser } = usePresence();

  const fetchTeam = useCallback(async () => {
    if (!projectId) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('project_team_members')
        .select(`
          role,
          profiles:user_id (id, username, avatar_url, email)
        `)
        .eq('project_id', projectId);

      if (error) throw error;
      
      const enrichedTeam = data.map(member => ({
        ...member.profiles,
        project_role: member.role,
        status: getStatusForUser(member.profiles.id) || 'offline',
        avatar: member.profiles.username?.substring(0, 2).toUpperCase() || 'AG'
      }));

      setTeam(enrichedTeam);
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error', description: 'Could not fetch project team.' });
      console.error(error);
    } finally {
      setLoading(false);
    }
  }, [projectId, toast, getStatusForUser]);

  useEffect(() => {
    fetchTeam();
  }, [fetchTeam]);

  const getRoleIcon = (role) => {
    switch (role) {
      case 'owner': return <Crown className="w-4 h-4 text-yellow-400" />;
      case 'editor': return <Shield className="w-4 h-4 text-blue-400" />;
      case 'viewer': return <Star className="w-4 h-4 text-green-400" />;
      default: return <Users className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusInfo = (status) => {
    switch (status) {
      case 'online': return { color: 'bg-green-400', text: 'ONLINE' };
      case 'away': return { color: 'bg-yellow-400', text: 'AWAY' };
      case 'busy': return { color: 'bg-red-400', text: 'BUSY' };
      default: return { color: 'bg-gray-400', text: 'OFFLINE' };
    }
  };

  if (loading) {
    return <div className="flex justify-center items-center h-full"><Loader2 className="w-12 h-12 text-green-400 animate-spin" /></div>;
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h3 className="font-bold text-green-400 font-mono uppercase">&gt; PROJECT TEAM</h3>
        <Button onClick={onOpenInviteTeam} className="cyber-button" size="sm">
          <UserPlus className="w-4 h-4 mr-2" />
          INVITE
        </Button>
      </div>
      
      {team.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {team.map((member, index) => {
            const statusInfo = getStatusInfo(member.status);
            return(
              <motion.div
                key={member.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="cyber-card p-4 rounded-lg flex items-center justify-between hover:bg-green-400/5 transition-colors"
              >
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <div className="w-12 h-12 cyber-border rounded-full bg-green-400/20 flex items-center justify-center">
                      <span className="text-lg font-bold text-green-400 font-mono">{member.avatar}</span>
                    </div>
                    <div className={`absolute -bottom-1 -right-1 w-4 h-4 ${statusInfo.color} rounded-full border-2 border-black`}></div>
                  </div>
                  <div>
                    <h4 className="font-bold text-green-400">{member.username}</h4>
                    <p className="text-sm text-green-400/70 flex items-center space-x-2">
                      {getRoleIcon(member.project_role)}
                      <span className="capitalize">{member.project_role}</span>
                    </p>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button size="icon" variant="ghost" className="cyber-button" onClick={() => toast({ title: 'Messaging feature coming soon!' })}>
                    <Mail className="w-4 h-4" />
                  </Button>
                  <Button size="icon" variant="ghost" className="cyber-button" onClick={() => onViewProfile(member.id)}>
                    <Eye className="w-4 h-4" />
                  </Button>
                </div>
              </motion.div>
            )
          })}
        </div>
      ) : (
        <div className="text-center py-10 cyber-border rounded-lg">
          <Users className="w-12 h-12 text-green-400/50 mx-auto mb-4" />
          <h4 className="font-bold text-green-400">This project has no team members yet.</h4>
          <p className="text-sm text-green-400/70 mt-2">Invite members to start collaborating.</p>
        </div>
      )}
    </div>
  );
};

export default ProjectTeamModal;