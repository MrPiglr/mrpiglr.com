import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, UserPlus, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useActivity } from '@/hooks/useActivity.jsx';
import { supabase } from '@/lib/customSupabaseClient';

const InviteDeveloperModal = ({ isOpen, onClose }) => {
  const { toast } = useToast();
  const { addActivity } = useActivity();
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('contributor');
  const [projects, setProjects] = useState([]);
  const [selectedProjects, setSelectedProjects] = useState([]);
  const [projectsLoading, setProjectsLoading] = useState(true);

  useEffect(() => {
    if (isOpen) {
      const fetchProjects = async () => {
        setProjectsLoading(true);
        const { data, error } = await supabase.from('projects').select('id, title');
        if (error) {
          toast({ variant: 'destructive', title: 'Error fetching projects', description: error.message });
        } else {
          setProjects(data);
        }
        setProjectsLoading(false);
      };
      fetchProjects();
    }
  }, [isOpen, toast]);

  const handleProjectSelect = (e) => {
    const selectedOptions = Array.from(e.target.selectedOptions, option => option.value);
    setSelectedProjects(selectedOptions);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email) return;

    setLoading(true);
    
    const { data, error } = await supabase.functions.invoke('invite-user', {
      body: { 
        email, 
        role, 
        type: 'developer', 
        projectIds: selectedProjects 
      },
    });

    setLoading(false);

    if (error) {
      toast({
        variant: 'destructive',
        title: 'Error sending invitation',
        description: error.message,
      });
    } else {
      addActivity({ type: 'team', message: `Invited new developer: ${email}` });
      toast({
        title: '> INVITATION SENT',
        description: `An invitation has been sent to ${email}.`,
      });
      setEmail('');
      setRole('contributor');
      setSelectedProjects([]);
      onClose();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, y: -20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="cyber-card p-8 rounded-lg w-full max-w-md relative"
            onClick={(e) => e.stopPropagation()}
          >
            <Button onClick={onClose} className="absolute top-4 right-4 cyber-button p-2" variant="ghost"><X className="w-4 h-4" /></Button>
            <h2 className="text-2xl font-bold terminal-glow tracking-wider uppercase mb-6">&gt; INVITE_TEAM_MEMBER</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm text-green-400/70 font-mono uppercase mb-2">Email Address</label>
                <input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g., new.dev@aethex.biz"
                  className="w-full bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono placeholder-green-400/50 focus:outline-none focus:ring-2 focus:ring-green-400/50"
                  required
                  disabled={loading}
                />
              </div>
              <div>
                <label className="block text-sm text-green-400/70 font-mono uppercase mb-2">Role</label>
                <select
                  id="role"
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  className="w-full bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono focus:outline-none focus:ring-2 focus:ring-green-400/50"
                  disabled={loading}
                >
                  <option value="contributor">Contributor</option>
                  <option value="editor">Editor</option>
                  <option value="admin">Admin</option>
                </select>
              </div>
              <div>
                <label className="block text-sm text-green-400/70 font-mono uppercase mb-2">Add to Project(s)</label>
                {projectsLoading ? (
                  <div className="flex justify-center items-center h-32 bg-black/50 cyber-border rounded">
                    <Loader2 className="w-6 h-6 text-green-400 animate-spin" />
                  </div>
                ) : (
                  <select
                    id="projects"
                    multiple
                    value={selectedProjects}
                    onChange={handleProjectSelect}
                    className="w-full h-32 bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono focus:outline-none focus:ring-2 focus:ring-green-400/50"
                    disabled={loading}
                  >
                    {projects.map((project) => (
                      <option key={project.id} value={project.id}>{project.title}</option>
                    ))}
                  </select>
                )}
                <p className="text-xs text-green-400/60 mt-1">Hold Ctrl/Cmd to select multiple projects.</p>
              </div>
              <div className="flex justify-end">
                <Button type="submit" className="cyber-button" disabled={loading}>
                  {loading ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <UserPlus className="w-4 h-4 mr-2" />
                  )}
                  SEND_INVITE
                </Button>
              </div>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default InviteDeveloperModal;