import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ConfirmationModal = ({ isOpen, onClose, onConfirm, title, icon, children }) => {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, y: -20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="cyber-card p-8 rounded-lg w-full max-w-md relative text-center"
            onClick={(e) => e.stopPropagation()}
          >
            <Button onClick={onClose} className="absolute top-4 right-4 cyber-button p-2" variant="ghost"><X className="w-4 h-4" /></Button>
            {icon && <div className="mx-auto mb-4">{icon}</div>}
            <h2 className="text-2xl font-bold terminal-glow tracking-wider uppercase mb-4">
              {title}
            </h2>
            <div className="mb-6">{children}</div>
            <div className="flex justify-center space-x-4">
              <Button onClick={onClose} variant="outline" className="cyber-button w-32">CANCEL</Button>
              <Button onClick={onConfirm} variant="destructive" className="cyber-button w-32">CONFIRM</Button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default ConfirmationModal;