import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Upload, File, Trash2, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useActivity } from '@/hooks/useActivity.jsx';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/context/AuthContext';

const UploadAssetsModal = ({ isOpen, onClose, onAssetsUploaded }) => {
  const { toast } = useToast();
  const { addActivity } = useActivity();
  const { user } = useAuth();
  
  const [files, setFiles] = useState([]);
  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef(null);

  const fetchProjects = useCallback(async () => {
    if (!user) return;
    try {
      const { data, error } = await supabase
        .from('projects')
        .select('id, title')
        .eq('owner_id', user.id);
      if (error) throw error;
      setProjects(data);
      if (data.length > 0) {
        setSelectedProject(data[0].id);
      }
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error fetching projects', description: error.message });
    }
  }, [user, toast]);

  useEffect(() => {
    if (isOpen) {
      fetchProjects();
    }
  }, [isOpen, fetchProjects]);

  const handleFileChange = (e) => {
    if (e.target.files) {
      setFiles(prev => [...prev, ...Array.from(e.target.files)]);
    }
  };

  const handleBrowseClick = () => {
    fileInputRef.current?.click();
  };

  const removeFile = (fileName) => {
    setFiles(prev => prev.filter(file => file.name !== fileName));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (files.length === 0) {
      toast({ title: '> UPLOAD ERROR', description: 'No files selected for upload.', variant: 'destructive' });
      return;
    }
    if (!selectedProject) {
      toast({ title: '> UPLOAD ERROR', description: 'Please select a target project.', variant: 'destructive' });
      return;
    }

    setIsUploading(true);
    
    const uploadPromises = files.map(async (file) => {
      const filePath = `${selectedProject}/${Date.now()}_${file.name}`;
      
      const { error: uploadError } = await supabase.storage
        .from('assets')
        .upload(filePath, file);

      if (uploadError) {
        throw new Error(`Failed to upload ${file.name}: ${uploadError.message}`);
      }

      const { error: dbError } = await supabase
        .from('assets')
        .insert({
          project_id: selectedProject,
          user_id: user.id,
          name: file.name,
          path: filePath,
          file_type: file.type,
          size: file.size,
        });

      if (dbError) {
        throw new Error(`Failed to save ${file.name} to database: ${dbError.message}`);
      }
    });

    try {
      await Promise.all(uploadPromises);
      addActivity({ type: 'asset', message: `Uploaded ${files.length} new asset(s).` });
      toast({ title: '> UPLOAD COMPLETE', description: `${files.length} asset(s) have been successfully uploaded.` });
      setFiles([]);
      if (onAssetsUploaded) onAssetsUploaded();
      onClose();
    } catch (error) {
      toast({ variant: 'destructive', title: 'Upload Failed', description: error.message });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, y: -20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="cyber-card p-8 rounded-lg w-full max-w-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <Button onClick={onClose} className="absolute top-4 right-4 cyber-button p-2" variant="ghost" disabled={isUploading}><X className="w-4 h-4" /></Button>
            <h2 className="text-2xl font-bold terminal-glow tracking-wider uppercase mb-6">&gt; UPLOAD_ASSETS</h2>
            
            <div className="relative w-full h-48 cyber-border border-dashed flex flex-col items-center justify-center text-center p-4 rounded-lg bg-black/50 mb-6">
              <Upload className="w-8 h-8 text-green-400/70 mb-2" />
              <p className="text-green-400/70 font-mono">Drag & drop files here or <button type="button" onClick={handleBrowseClick} className="text-cyan-400 hover:underline">browse</button></p>
              <input type="file" multiple onChange={handleFileChange} ref={fileInputRef} className="hidden" />
            </div>

            {files.length > 0 && (
              <div className="space-y-2 max-h-48 overflow-y-auto mb-6 pr-2">
                {files.map((file, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-green-400/10 rounded">
                    <div className="flex items-center space-x-2 overflow-hidden">
                      <File className="w-4 h-4 text-green-400 flex-shrink-0" />
                      <span className="text-sm font-mono text-green-400 truncate">{file.name}</span>
                    </div>
                    <Button onClick={() => removeFile(file.name)} variant="ghost" size="sm" className="p-1 h-auto flex-shrink-0"><Trash2 className="w-4 h-4 text-red-400" /></Button>
                  </div>
                ))}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm text-green-400/70 font-mono uppercase mb-2">Target Project</label>
                <select 
                  value={selectedProject}
                  onChange={(e) => setSelectedProject(e.target.value)}
                  className="w-full bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono focus:outline-none focus:ring-2 focus:ring-green-400/50"
                  disabled={isUploading}
                >
                  {projects.length > 0 ? (
                    projects.map(p => <option key={p.id} value={p.id}>{p.title}</option>)
                  ) : (
                    <option>No projects found</option>
                  )}
                </select>
              </div>
              <div className="flex justify-end">
                <Button type="submit" className="cyber-button" disabled={isUploading || files.length === 0}>
                  {isUploading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Upload className="w-4 h-4 mr-2" />}
                  {isUploading ? 'UPLOADING...' : `UPLOAD ${files.length} FILE(S)`}
                </Button>
              </div>
            </form>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default UploadAssetsModal;