import React, { useState, useEffect, useContext } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  User, 
  Shield, 
  Bell, 
  Palette, 
  Globe,
  Save,
  RotateCcw,
  FileCog,
  Network
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useActivity } from '@/hooks/useActivity.jsx';
import ProfileSettings from '@/components/settings/ProfileSettings';
import SecuritySettings from '@/components/settings/SecuritySettings';
import NotificationSettings from '@/components/settings/NotificationSettings';
import AppearanceSettings from '@/components/settings/AppearanceSettings';
import IntegrationSettings from '@/components/settings/IntegrationSettings';
import ProjectSettings from '@/components/settings/ProjectSettings';
import DomainSettings from '@/components/settings/DomainSettings';
import { AppearanceContext } from '@/context/AppearanceContext';

const SettingsPage = ({ setIsLoading }) => {
  const { toast } = useToast();
  const { addActivity } = useActivity();
  const [activeSection, setActiveSection] = useState('profile');
  const { settings, updateSettings, resetSettings, initialSettings } = useContext(AppearanceContext);

  useEffect(() => {
    setIsLoading(false);
  }, [activeSection, setIsLoading]);

  const handleSave = () => {
    localStorage.setItem('gameforge_settings', JSON.stringify(settings));
    addActivity({ type: 'settings', message: 'Saved all settings changes' });
    toast({
      title: '> SETTINGS SAVED',
      description: 'All your changes have been successfully saved.',
    });
  };

  const handleReset = () => {
    resetSettings();
    addActivity({ type: 'settings', message: 'Reset all settings to default' });
    toast({
      title: '> SETTINGS RESET',
      description: 'All settings have been reset to their default values.',
      variant: 'destructive'
    });
  };

  const handleAction = (action, setting = '') => {
    addActivity({ type: 'settings', message: `Performed settings action: ${action} ${setting}` });
    toast({
      title: `> SETTINGS ACTION: ${action.toUpperCase()}`,
      description: `Looks like MrPiglr hasn't wired this up yet. Give him a nudge! 🐷`,
      variant: 'destructive'
    });
  };

  const sections = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'security', label: 'Security', icon: Shield },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'appearance', label: 'Appearance', icon: Palette },
    { id: 'integrations', label: 'Integrations', icon: Globe },
    { id: 'domains', label: 'Domains', icon: Network },
    { id: 'project', label: 'Project Settings', icon: FileCog },
  ];

  const renderContent = () => {
    switch (activeSection) {
      case 'profile': return <ProfileSettings settings={settings.profile} onChange={updateSettings} />;
      case 'security': return <SecuritySettings settings={settings.security} onChange={updateSettings} onAction={handleAction} />;
      case 'notifications': return <NotificationSettings settings={settings.notifications} onChange={updateSettings} />;
      case 'appearance': return <AppearanceSettings settings={settings.appearance} onChange={updateSettings} />;
      case 'integrations': return <IntegrationSettings settings={settings.integrations} onChange={updateSettings} onAction={handleAction} />;
      case 'domains': return <DomainSettings domains={settings.domains} setSettings={updateSettings} />;
      case 'project': return <ProjectSettings settings={settings.project} setSettings={updateSettings} />;
      default: return <ProfileSettings settings={settings.profile} onChange={updateSettings} />;
    }
  };

  return (
    <div className="space-y-6 cyber-card p-6 rounded-lg">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold terminal-glow tracking-wider uppercase">&gt; SETTINGS</h1>
          <p className="text-green-400/70 font-mono mt-2">Configure your GameForge environment and preferences</p>
        </div>
        <div className="flex space-x-2">
          <Button onClick={handleSave} className="cyber-button"><Save className="w-4 h-4 mr-2" />SAVE_CHANGES</Button>
          <Button onClick={handleReset} className="cyber-button" variant="outline"><RotateCcw className="w-4 h-4 mr-2" />RESET</Button>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.1 }} className="cyber-card p-4 rounded-lg h-fit">
          <nav className="space-y-2">
            {sections.map((section) => {
              const Icon = section.icon;
              return (
                <button key={section.id} onClick={() => setActiveSection(section.id)} className={`w-full flex items-center space-x-3 px-4 py-3 rounded cyber-button text-left transition-colors ${activeSection === section.id ? 'bg-green-400/20' : ''}`}>
                  <Icon className="w-4 h-4" />
                  <span className="text-sm font-mono uppercase">{section.label}</span>
                </button>
              );
            })}
          </nav>
        </motion.div>

        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.6, delay: 0.2 }} className="lg:col-span-3">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeSection}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {renderContent()}
            </motion.div>
          </AnimatePresence>
        </motion.div>
      </div>
    </div>
  );
};

export default SettingsPage;