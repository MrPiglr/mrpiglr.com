import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { UserPlus, User, Lock, Mail, Loader2, Home, LogIn } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useActivity } from '@/hooks/useActivity.jsx';
import { useAuth } from '@/context/AuthContext';

const Signup = ({ onSwitchToLogin, onSwitchToIntro, maintenanceMode = false }) => {
  const { addActivity } = useActivity();
  const { signUp } = useAuth();
  const [loading, setLoading] = useState(false);

  const handleSignup = async (e) => {
    e.preventDefault();
    setLoading(true);
    const email = e.target.elements.email.value;
    const password = e.target.elements.password.value;
    const username = e.target.elements.username.value;
    addActivity({ type: 'auth', message: `New user ${username} attempting to sign up.` });
    
    await signUp(email, password, username);
    // Don't setLoading(false) here, as successful signup will proceed to email confirmation.
    // The AuthProvider should handle setting loading state on error.
    setTimeout(() => setLoading(false), 5000);
  };

  if (maintenanceMode) {
    return (
       <motion.div
        key="signup-disabled"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        transition={{ duration: 0.3 }}
        className="cyber-card p-8 rounded-lg max-w-md mx-auto w-full text-center"
      >
        <h2 className="text-3xl font-bold terminal-glow tracking-wider uppercase mb-6">
          &gt; REGISTRATION OFFLINE
        </h2>
        <p className="text-green-400/80 mb-6">
            Account registration is temporarily disabled during system maintenance. Please try again later.
        </p>
        <Button onClick={onSwitchToLogin} className="w-full cyber-button text-lg py-3">
            <LogIn className="mr-2"/>
            BACK TO LOGIN
        </Button>
      </motion.div>
    )
  }

  return (
    <motion.div
      key="signup"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
      className="cyber-card p-8 rounded-lg max-w-md mx-auto w-full"
    >
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-3xl font-bold terminal-glow tracking-wider uppercase">
          &gt; CREATE ACCOUNT
        </h2>
        {onSwitchToIntro && (
          <Button variant="ghost" size="icon" onClick={onSwitchToIntro}>
            <Home className="w-5 h-5 text-green-400/70 hover:text-green-400"/>
          </Button>
        )}
      </div>
      <form onSubmit={handleSignup} className="space-y-6">
        <div className="relative">
          <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-green-400/50" />
          <input
            id="email"
            type="email"
            placeholder="EMAIL"
            className="w-full bg-black/50 cyber-border rounded px-10 py-3 text-green-400 font-mono placeholder-green-400/50 focus:outline-none focus:ring-2 focus:ring-green-400/50"
            required
          />
        </div>
        <div className="relative">
          <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-green-400/50" />
          <input
            id="username"
            type="text"
            placeholder="USERNAME"
            className="w-full bg-black/50 cyber-border rounded px-10 py-3 text-green-400 font-mono placeholder-green-400/50 focus:outline-none focus:ring-2 focus:ring-green-400/50"
            required
          />
        </div>
        <div className="relative">
          <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-green-400/50" />
          <input
            id="password"
            type="password"
            placeholder="PASSWORD"
            className="w-full bg-black/50 cyber-border rounded px-10 py-3 text-green-400 font-mono placeholder-green-400/50 focus:outline-none focus:ring-2 focus:ring-green-400/50"
            minLength="6"
            required
          />
        </div>
        <Button type="submit" className="w-full cyber-button text-lg py-3" disabled={loading}>
          {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UserPlus className="mr-2" />}
          {loading ? 'INITIALIZING...' : 'CREATE ACCOUNT'}
        </Button>
      </form>
      <p className="text-center text-sm text-green-400/70 font-mono mt-6">
        Already have an account?{' '}
        <button onClick={onSwitchToLogin} className="text-cyan-400 hover:underline terminal-glow">
          Log in
        </button>
      </p>
    </motion.div>
  );
};

export default Signup;