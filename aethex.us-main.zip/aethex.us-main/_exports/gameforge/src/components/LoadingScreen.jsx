import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Code } from 'lucide-react';

const LoadingScreen = () => {
  const [progress, setProgress] = useState(0);
  const [loadingText, setLoadingText] = useState('Initializing kernel...');

  const loadingSteps = [
    'Initializing kernel...',
    'Loading neural modules...',
    'Syncing with data stream...',
    'Establishing secure connection...',
    'Booting GameForge OS...',
    'Finalizing...'
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        const newProgress = prev + 1;
        if (newProgress >= 100) {
          clearInterval(interval);
          setLoadingText('System ready.');
          return 100;
        }
        
        const stepIndex = Math.floor((newProgress / 100) * (loadingSteps.length -1));
        setLoadingText(loadingSteps[stepIndex]);

        return newProgress;
      });
    }, 40);

    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="fixed inset-0 bg-black flex flex-col items-center justify-center font-mono z-50"
    >
      <div className="flex flex-col items-center justify-center">
        <motion.div
          className="w-24 h-24 cyber-border rounded-full bg-green-400/20 flex items-center justify-center pulse-green mb-8"
          animate={{
            scale: [1, 1.05, 1],
          }}
          transition={{
            duration: 2,
            ease: "easeInOut",
            repeat: Infinity,
          }}
        >
          <Code className="w-12 h-12 text-green-400 terminal-glow" />
        </motion.div>

        <div className="w-80">
          <div className="w-full bg-green-900/50 rounded-full h-1.5 mb-2 cyber-border">
            <motion.div
              className="bg-green-400 h-1.5 rounded-full"
              style={{boxShadow: '0 0 10px #00ff00'}}
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.1, ease: "linear" }}
            />
          </div>
          <motion.p 
            className="text-center text-sm text-green-400 terminal-glow"
            key={loadingText}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.2 }}
          >
            {loadingText}
          </motion.p>
        </div>

        <motion.div
          className="absolute bottom-8 text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1.5 }}
        >
          <h2
            className="text-lg text-green-300 tracking-widest"
          >
            Powered by AeThex OS
          </h2>
          <p className="text-xs text-green-400/70 mt-1">
            &copy; {new Date().getFullYear()} AETHEX.BIZ
          </p>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default LoadingScreen;