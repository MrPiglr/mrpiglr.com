import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/customSupabaseClient';
import LoadingScreen from '@/components/LoadingScreen';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import {
  Users, Play, Info, Book, ThumbsUp, ThumbsDown, Share2, Bookmark, Bell, Flag,
  ShoppingBag, Award, Music, Server, Calendar, Mic, Camera, Link as LinkIcon, Save, Tag, Activity,
  Laptop, Apple, Tablet, Smartphone, Box, Wifi, HardDrive
} from 'lucide-react';

const StatCard = ({ icon, label, value }) => (
  <div className="cyber-card p-4 flex flex-col items-center justify-center text-center">
    {icon}
    <span className="text-2xl font-bold terminal-glow mt-2">{value}</span>
    <span className="text-xs text-green-400/70 font-mono uppercase tracking-wider">{label}</span>
  </div>
);

const InfoPill = ({ icon, label, value }) => (
  <div className="flex items-center space-x-2 cyber-border text-sm px-3 py-1 rounded-full">
    {icon}
    <span className="text-green-400/80">{label}:</span>
    <span className="font-bold text-green-300">{value}</span>
  </div>
);

const PlatformIcon = ({ platform }) => {
  switch (platform.toLowerCase()) {
    case 'pc/windows': return <Laptop className="w-5 h-5" />;
    case 'mac': return <Apple className="w-5 h-5" />;
    case 'ios/ipados': return <Tablet className="w-5 h-5" />;
    case 'android': return <Smartphone className="w-5 h-5" />;
    case 'vr': return <Box className="w-5 h-5" />;
    default: return null;
  }
};

const GamesPage = () => {
  const { gameId } = useParams();
  const { toast } = useToast();
  const [game, setGame] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchGame = async () => {
      if (!gameId) {
        setLoading(false);
        return;
      }
      setLoading(true);
      const { data, error } = await supabase
        .from('games')
        .select('*')
        .eq('id', gameId)
        .single();
      
      if (error) {
        if (error.code !== 'PGRST116') { // Ignore "no rows found" error for the toast
          toast({ variant: 'destructive', title: 'Error', description: 'Could not fetch game data.' });
        }
        console.error(error);
      } else {
        setGame(data);
      }
      setLoading(false);
    };
    fetchGame();
  }, [gameId, toast]);

  const handleNotImplemented = (feature) => {
    toast({
      title: `> ${feature.toUpperCase()}`,
      description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  const ratingPercentage = game && (game.likes + game.dislikes > 0) ? Math.round((game.likes / (game.likes + game.dislikes)) * 100) : 0;

  if (loading) return <LoadingScreen />;
  if (!game) return <div className="text-center text-red-500">Game not found.</div>;

  return (
    <div className="min-h-screen bg-black text-green-400 font-mono p-4 sm:p-6 lg:p-8">
      <Helmet>
        <title>{game.title} - GameForge</title>
        <meta name="description" content={game.description} />
      </Helmet>
      
      <Link to="/" className="text-cyan-400 hover:underline terminal-glow mb-4 inline-block">&lt; Back to Dashboard</Link>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5 }}>
        <div className="relative rounded-lg overflow-hidden cyber-border mb-6">
          <img  className="w-full h-48 md:h-64 object-cover" alt={`${game.title} banner`} src={game.banner_url || "https://images.unsplash.com/photo-1692848544705-820a5b212d98"} />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-transparent"></div>
          <div className="absolute bottom-4 left-4 flex items-end space-x-4">
            <img  className="w-24 h-24 md:w-32 md:h-32 object-cover rounded-lg cyber-border" alt={`${game.title} cover`} src={game.image_url || "https://images.unsplash.com/photo-1659168081179-ca1bb96756ea"} />
            <div>
              <span className={`text-xs font-mono uppercase px-2 py-1 rounded cyber-border ${game.status === 'launched' ? 'text-green-400 border-green-400/30' : 'text-yellow-400 border-yellow-400/30'}`}>{game.status}</span>
              <h1 className="text-3xl md:text-5xl font-bold terminal-glow mt-1">{game.title}</h1>
              <p className="text-sm text-green-400/80">by <span className="text-cyan-400">AeThex Studios</span></p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <StatCard icon={<Users className="w-8 h-8 text-green-400"/>} label="Active" value={game.active_users.toLocaleString()} />
          <StatCard icon={<Activity className="w-8 h-8 text-cyan-400"/>} label="Visits" value={game.total_visits.toLocaleString()} />
          <StatCard icon={<ThumbsUp className="w-8 h-8 text-purple-400"/>} label="Rating" value={`${ratingPercentage}%`} />
          <StatCard icon={<Server className="w-8 h-8 text-yellow-400"/>} label="Servers" value="15" />
        </div>

        <div className="flex flex-wrap items-center gap-4 mb-6">
          <Button onClick={() => handleNotImplemented('Join Game')} className="cyber-button text-lg flex-grow sm:flex-grow-0"><Play className="mr-2"/>JOIN</Button>
          <Button onClick={() => handleNotImplemented('Start Party')} variant="outline" className="cyber-button flex-grow sm:flex-grow-0"><Users className="mr-2"/>PARTY</Button>
          <div className="flex items-center space-x-2">
            <Button onClick={() => handleNotImplemented('Like')} variant="outline" size="icon" className="cyber-button"><ThumbsUp/></Button>
            <Button onClick={() => handleNotImplemented('Dislike')} variant="outline" size="icon" className="cyber-button"><ThumbsDown/></Button>
          </div>
          <div className="flex-grow"></div>
          <div className="flex items-center space-x-2">
            <Button onClick={() => handleNotImplemented('Share')} variant="ghost" size="icon"><Share2/></Button>
            <Button onClick={() => handleNotImplemented('Save')} variant="ghost" size="icon"><Save/></Button>
            <Button onClick={() => handleNotImplemented('Subscribe')} variant="ghost" size="icon"><Bell/></Button>
            <Button onClick={() => handleNotImplemented('Report')} variant="ghost" size="icon"><Flag/></Button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="cyber-card p-6">
              <h2 className="text-xl font-bold terminal-glow uppercase mb-3">&gt; About</h2>
              <p className="text-sm text-green-400/80 leading-relaxed">{game.long_description}</p>
              <div className="flex flex-wrap gap-2 mt-4">
                {game.hashtags?.map(tag => <span key={tag} className="text-xs font-mono text-cyan-400">{tag}</span>)}
              </div>
            </div>
            
            {/* Tabs for more details */}
            <div className="cyber-card p-6">
                <h2 className="text-xl font-bold terminal-glow uppercase mb-3">&gt; Shop</h2>
                <p className="text-green-400/70 text-center py-8">Shop implementation coming soon.</p>
            </div>
            <div className="cyber-card p-6">
                <h2 className="text-xl font-bold terminal-glow uppercase mb-3">&gt; Servers</h2>
                <p className="text-green-400/70 text-center py-8">Server browser coming soon.</p>
            </div>
            <div className="cyber-card p-6">
                <h2 className="text-xl font-bold terminal-glow uppercase mb-3">&gt; Recommended</h2>
                <p className="text-green-400/70 text-center py-8">Recommendations coming soon.</p>
            </div>

          </div>
          <div className="space-y-6">
            <div className="cyber-card p-6">
              <h2 className="text-xl font-bold terminal-glow uppercase mb-3">&gt; Game Info</h2>
              <div className="space-y-3">
                <InfoPill icon={<Info className="w-4 h-4" />} label="Genre" value={`${game.genre} / ${game.subgenre}`} />
                <InfoPill icon={<Calendar className="w-4 h-4" />} label="Created" value={new Date(game.created_at).toLocaleDateString()} />
                <InfoPill icon={<Calendar className="w-4 h-4" />} label="Updated" value={new Date(game.updated_at).toLocaleDateString()} />
                <InfoPill icon={<Users className="w-4 h-4" />} label="Max Players" value={game.server_size} />
                <InfoPill icon={<Mic className="w-4 h-4" />} label="Voice Chat" value={game.voice_chat_enabled ? 'Enabled' : 'Disabled'} />
                <InfoPill icon={<Camera className="w-4 h-4" />} label="Camera" value={game.camera_enabled ? 'Enabled' : 'Disabled'} />
                <InfoPill icon={<HardDrive className="w-4 h-4" />} label="Memory" value={game.memory_requirements} />
                <div className="flex items-center space-x-2 pt-2">
                    {game.platforms?.map(p => <PlatformIcon key={p} platform={p} />)}
                </div>
              </div>
            </div>
            <div className="cyber-card p-6">
                <h2 className="text-xl font-bold terminal-glow uppercase mb-3">&gt; Badges</h2>
                <p className="text-green-400/70 text-center py-4">Badges list coming soon.</p>
            </div>
             <div className="cyber-card p-6">
                <h2 className="text-xl font-bold terminal-glow uppercase mb-3">&gt; Social Links</h2>
                <div className="flex space-x-4">
                  <a href={game.social_media_links?.twitter} target="_blank" rel="noreferrer" className="text-cyan-400 hover:text-green-400"><LinkIcon /></a>
                  <a href={game.social_media_links?.discord} target="_blank" rel="noreferrer" className="text-cyan-400 hover:text-green-400"><LinkIcon /></a>
                </div>
            </div>
          </div>
        </div>

      </motion.div>
    </div>
  );
};

export default GamesPage;