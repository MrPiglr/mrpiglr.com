import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Save, Loader2, AlertTriangle, Power, PowerOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const MaintenanceManager = ({ isOpen, onClose }) => {
  const { toast } = useToast();
  const [maintenanceStatus, setMaintenanceStatus] = useState({ enabled: false, message: '' });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (isOpen) {
      const fetchStatus = async () => {
        setLoading(true);
        try {
          const { data, error } = await supabase
            .from('system_settings')
            .select('value')
            .eq('key', 'maintenance_status')
            .single();
          
          if (error && error.code !== 'PGRST116') throw error;
          
          if (data) {
            setMaintenanceStatus(data.value);
          } else {
            setMaintenanceStatus({ enabled: false, message: "System is currently under maintenance. We'll be back shortly." });
          }
        } catch (error) {
          toast({ variant: 'destructive', title: 'Error fetching status', description: error.message });
        } finally {
          setLoading(false);
        }
      };
      fetchStatus();
    }
  }, [isOpen, toast]);

  const handleSave = async () => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from('system_settings')
        .upsert({ key: 'maintenance_status', value: maintenanceStatus }, { onConflict: 'key' });

      if (error) throw error;

      toast({
        title: '> MAINTENANCE MODE UPDATED',
        description: `System maintenance mode is now ${maintenanceStatus.enabled ? 'ENABLED' : 'DISABLED'}.`,
      });
      onClose();
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error saving status', description: error.message });
    } finally {
      setSaving(false);
    }
  };

  const toggleMaintenanceMode = () => {
    setMaintenanceStatus(prev => ({ ...prev, enabled: !prev.enabled }));
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, y: -20 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.9, y: 20 }}
            className="cyber-card p-8 rounded-lg w-full max-w-2xl relative"
            onClick={(e) => e.stopPropagation()}
          >
            <Button onClick={onClose} className="absolute top-4 right-4 cyber-button p-2" variant="ghost"><X className="w-4 h-4" /></Button>
            <h2 className="text-2xl font-bold terminal-glow tracking-wider uppercase mb-2">&gt; MAINTENANCE_CONTROL</h2>
            <p className="text-green-400/70 font-mono mb-6">Enable or disable system-wide maintenance mode.</p>
            
            {loading ? (
              <div className="flex justify-center items-center h-48">
                <Loader2 className="w-12 h-12 text-green-400 animate-spin" />
              </div>
            ) : (
              <div className="space-y-6">
                <div className={`cyber-card p-4 rounded-lg flex items-center justify-between ${maintenanceStatus.enabled ? 'border-yellow-400' : 'border-green-400'}`}>
                  <div>
                    <p className="font-mono text-lg font-bold uppercase">
                      System Status: <span className={maintenanceStatus.enabled ? 'text-yellow-400' : 'text-green-400'}>
                        {maintenanceStatus.enabled ? 'MAINTENANCE' : 'OPERATIONAL'}
                      </span>
                    </p>
                    <p className="text-xs font-mono text-green-400/70">
                      {maintenanceStatus.enabled ? 'Users will see the maintenance page.' : 'The application is live.'}
                    </p>
                  </div>
                  <Button
                    onClick={toggleMaintenanceMode}
                    className={`cyber-button ${maintenanceStatus.enabled ? 'bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400' : 'bg-green-500/20 hover:bg-green-500/30 text-green-400'}`}
                  >
                    {maintenanceStatus.enabled ? <PowerOff className="w-4 h-4 mr-2" /> : <Power className="w-4 h-4 mr-2" />}
                    {maintenanceStatus.enabled ? 'DISABLE' : 'ENABLE'}
                  </Button>
                </div>

                <div>
                  <label htmlFor="maintenance-message" className="text-sm font-mono text-green-400/80 mb-2 block">Maintenance Message:</label>
                  <textarea
                    id="maintenance-message"
                    value={maintenanceStatus.message}
                    onChange={(e) => setMaintenanceStatus(prev => ({ ...prev, message: e.target.value }))}
                    className="w-full bg-black/50 cyber-border rounded px-4 py-3 text-green-400 font-mono placeholder-green-400/50 focus:outline-none focus:ring-2 focus:ring-green-400/50 h-24"
                    placeholder="Enter the message to display to users..."
                  />
                </div>

                <div className="flex justify-between items-center mt-6">
                  <div className="flex items-center space-x-2 text-yellow-400">
                    <AlertTriangle className="w-4 h-4" />
                    <span className="text-xs font-mono">Changes will affect all non-admin users immediately.</span>
                  </div>
                  <Button onClick={handleSave} className="cyber-button" disabled={saving}>
                    {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
                    SAVE_CHANGES
                  </Button>
                </div>
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default MaintenanceManager;