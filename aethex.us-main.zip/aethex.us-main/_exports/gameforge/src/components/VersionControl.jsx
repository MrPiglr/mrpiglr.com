import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  GitBranch, 
  GitCommit, 
  GitMerge, 
  Plus,
  Eye,
  Copy,
  Trash2,
  ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const getBranchTypeColor = (type) => {
  switch (type) {
    case 'main': return 'text-green-400 border-green-400/30';
    case 'feature': return 'text-blue-400 border-blue-400/30';
    case 'bugfix': return 'text-red-400 border-red-400/30';
    case 'hotfix': return 'text-yellow-400 border-yellow-400/30';
    default: return 'text-gray-400 border-gray-400/30';
  }
};

const getPRStatusColor = (status) => {
  switch (status) {
    case 'open': return 'text-green-400 border-green-400/30';
    case 'review': return 'text-yellow-400 border-yellow-400/30';
    case 'approved': return 'text-blue-400 border-blue-400/30';
    case 'merged': return 'text-purple-400 border-purple-400/30';
    case 'closed': return 'text-red-400 border-red-400/30';
    default: return 'text-gray-400 border-gray-400/30';
  }
};

const CommitList = ({ commits, handleAction }) => (
  <div className="space-y-4">
    {commits.map((commit, index) => (
      <motion.div
        key={commit.id}
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.4, delay: index * 0.1 }}
        className="cyber-card p-4 rounded-lg hover:bg-green-400/5 transition-colors"
      >
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-3 mb-2">
              <div className="w-8 h-8 cyber-border rounded bg-green-400/20 flex items-center justify-center">
                <GitCommit className="w-4 h-4 text-green-400" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-green-400 font-mono">{commit.message}</h3>
                <div className="flex items-center space-x-4 text-xs text-green-400/70 font-mono">
                  <span>{commit.hash}</span>
                  <span>{commit.author}</span>
                  <span>{commit.timestamp}</span>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4 text-xs text-green-400/70 font-mono ml-11">
              <span className={`px-2 py-1 rounded cyber-border ${getBranchTypeColor('feature')}`}>{commit.branch}</span>
              <span>{commit.files} files</span>
              <span className="text-green-400">+{commit.additions}</span>
              <span className="text-red-400">-{commit.deletions}</span>
            </div>
          </div>
          <div className="flex space-x-2">
            <Button onClick={() => handleAction('View Commit', commit.hash)} className="cyber-button p-2" variant="ghost" size="sm"><Eye className="w-4 h-4" /></Button>
            <Button onClick={() => handleAction('Copy Hash', commit.hash)} className="cyber-button p-2" variant="ghost" size="sm"><Copy className="w-4 h-4" /></Button>
          </div>
        </div>
      </motion.div>
    ))}
  </div>
);

const BranchList = ({ branches, handleAction }) => (
  <div className="space-y-4">
    {branches.map((branch, index) => (
      <motion.div
        key={branch.id}
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.4, delay: index * 0.1 }}
        className="cyber-card p-4 rounded-lg hover:bg-green-400/5 transition-colors"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="w-8 h-8 cyber-border rounded bg-green-400/20 flex items-center justify-center">
              <GitBranch className="w-4 h-4 text-green-400" />
            </div>
            <div>
              <div className="flex items-center space-x-2 mb-1">
                <h3 className="text-sm font-bold text-green-400 font-mono">{branch.name}</h3>
                <span className={`text-xs font-mono px-2 py-1 rounded cyber-border ${getBranchTypeColor(branch.type)}`}>{branch.type}</span>
                {branch.protected && <span className="text-xs font-mono px-2 py-1 rounded cyber-border text-yellow-400 border-yellow-400/30">PROTECTED</span>}
              </div>
              <div className="flex items-center space-x-4 text-xs text-green-400/70 font-mono">
                <span>{branch.lastCommit}</span>
                <span>{branch.author}</span>
                <span>{branch.lastUpdate}</span>
                {branch.ahead > 0 && <span className="text-green-400">↑{branch.ahead}</span>}
                {branch.behind > 0 && <span className="text-red-400">↓{branch.behind}</span>}
              </div>
            </div>
          </div>
          <div className="flex space-x-2">
            <Button onClick={() => handleAction('Checkout Branch', branch.name)} className="cyber-button" size="sm">CHECKOUT</Button>
            <Button onClick={() => handleAction('Create PR', branch.name)} className="cyber-button" variant="outline" size="sm">PR</Button>
            {!branch.protected && <Button onClick={() => handleAction('Delete Branch', branch.name)} className="cyber-button p-2" variant="ghost" size="sm"><Trash2 className="w-4 h-4" /></Button>}
          </div>
        </div>
      </motion.div>
    ))}
  </div>
);

const PullRequestList = ({ pullRequests, handleAction }) => (
  <div className="space-y-4">
    {pullRequests.map((pr, index) => (
      <motion.div
        key={pr.id}
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ duration: 0.4, delay: index * 0.1 }}
        className="cyber-card p-4 rounded-lg hover:bg-green-400/5 transition-colors"
      >
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1">
            <div className="flex items-center space-x-3 mb-2">
              <div className="w-8 h-8 cyber-border rounded bg-green-400/20 flex items-center justify-center">
                <GitMerge className="w-4 h-4 text-green-400" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-green-400 font-mono">{pr.title}</h3>
                <p className="text-xs text-green-400/70 font-mono">{pr.description}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4 text-xs text-green-400/70 font-mono ml-11">
              <span>{pr.author}</span>
              <span>{pr.created}</span>
              <span className={`px-2 py-1 rounded cyber-border ${getPRStatusColor(pr.status)}`}>{pr.status.toUpperCase()}</span>
            </div>
          </div>
        </div>
        <div className="flex items-center justify-between ml-11">
          <div className="flex items-center space-x-4 text-xs text-green-400/70 font-mono">
            <span className="flex items-center space-x-1">
              <span>{pr.source}</span>
              <ArrowRight className="w-3 h-3" />
              <span>{pr.target}</span>
            </span>
            <span>{pr.commits} commits</span>
            <span>{pr.files} files</span>
            <span>{pr.reviews} reviews</span>
          </div>
          <div className="flex space-x-2">
            <Button onClick={() => handleAction('Review PR', pr.title)} className="cyber-button" size="sm">REVIEW</Button>
            {pr.status === 'approved' && <Button onClick={() => handleAction('Merge PR', pr.title)} className="cyber-button" variant="outline" size="sm">MERGE</Button>}
          </div>
        </div>
      </motion.div>
    ))}
  </div>
);

const VersionControl = ({ setIsLoading = () => {} }) => {
  const [activeTab, setActiveTab] = useState('commits');
  const { toast } = useToast();
  
  useEffect(() => {
    setIsLoading(false);
  }, [setIsLoading]);

  const [commits] = useState([
    { id: 1, hash: 'a7f3d2e', message: 'Updated player movement system with neural controls', author: 'MRPIGLR', timestamp: '2 hours ago', branch: 'feature/neural-controls', files: 12, additions: 45, deletions: 8 },
    { id: 2, hash: 'b9e1c4f', message: 'Added cyberpunk UI elements and animations', author: 'UI_CYBER', timestamp: '5 hours ago', branch: 'feature/ui-overhaul', files: 8, additions: 127, deletions: 23 },
    { id: 3, hash: 'c2d5a8b', message: 'Implemented quantum physics engine', author: 'CODE_PHANTOM', timestamp: '1 day ago', branch: 'feature/quantum-physics', files: 15, additions: 234, deletions: 67 },
    { id: 4, hash: 'd8f2b1c', message: 'Fixed audio synchronization issues', author: 'SOUND_MATRIX', timestamp: '2 days ago', branch: 'bugfix/audio-sync', files: 3, additions: 18, deletions: 12 }
  ]);

  const [branches] = useState([
    { id: 1, name: 'main', type: 'main', lastCommit: 'a7f3d2e', lastUpdate: '2 hours ago', author: 'MRPIGLR', ahead: 0, behind: 0, protected: true },
    { id: 2, name: 'feature/neural-controls', type: 'feature', lastCommit: 'a7f3d2e', lastUpdate: '2 hours ago', author: 'MRPIGLR', ahead: 3, behind: 0, protected: false },
    { id: 3, name: 'feature/ui-overhaul', type: 'feature', lastCommit: 'b9e1c4f', lastUpdate: '5 hours ago', author: 'UI_CYBER', ahead: 2, behind: 1, protected: false },
    { id: 4, name: 'feature/quantum-physics', type: 'feature', lastCommit: 'c2d5a8b', lastUpdate: '1 day ago', author: 'CODE_PHANTOM', ahead: 5, behind: 2, protected: false }
  ]);

  const [pullRequests] = useState([
    { id: 1, title: 'Neural Controls Integration', description: 'Implements advanced neural interface controls for player movement', author: 'MRPIGLR', source: 'feature/neural-controls', target: 'main', status: 'open', commits: 3, files: 12, created: '2 hours ago', reviews: 2 },
    { id: 2, title: 'UI Overhaul with Cyberpunk Theme', description: 'Complete redesign of user interface with cyberpunk aesthetics', author: 'UI_CYBER', source: 'feature/ui-overhaul', target: 'main', status: 'review', commits: 8, files: 25, created: '1 day ago', reviews: 1 },
    { id: 3, title: 'Quantum Physics Engine', description: 'Advanced physics simulation for quantum mechanics gameplay', author: 'CODE_PHANTOM', source: 'feature/quantum-physics', target: 'main', status: 'approved', commits: 15, files: 42, created: '3 days ago', reviews: 3 }
  ]);

  const handleAction = (action, item = '') => {
    toast({
      title: `> VC ACTION: ${action.toUpperCase()}`,
      description: `Looks like MrPiglr hasn't wired this up yet. Give him a nudge! 🐷`,
      variant: 'destructive',
    });
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'commits': return <CommitList commits={commits} handleAction={handleAction} />;
      case 'branches': return <BranchList branches={branches} handleAction={handleAction} />;
      case 'pulls': return <PullRequestList pullRequests={pullRequests} handleAction={handleAction} />;
      default: return null;
    }
  };

  return (
    <div className="space-y-6 cyber-card p-6 rounded-lg">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold terminal-glow tracking-wider uppercase">&gt; VERSION_CONTROL</h1>
          <p className="text-green-400/70 font-mono mt-2">Git integration with automated build pipelines and webhook support</p>
        </div>
        <div className="flex space-x-2">
          <Button onClick={() => handleAction('Create Branch')} className="cyber-button"><GitBranch className="w-4 h-4 mr-2" />NEW_BRANCH</Button>
          <Button onClick={() => handleAction('Create PR')} className="cyber-button" variant="outline"><GitMerge className="w-4 h-4 mr-2" />NEW_PR</Button>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.1 }} className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { label: 'Commits Today', value: '47', color: 'text-green-400' },
          { label: 'Active Branches', value: '12', color: 'text-cyan-400' },
          { label: 'Open PRs', value: '3', color: 'text-purple-400' },
          { label: 'Sync Status', value: 'LIVE', color: 'text-yellow-400' }
        ].map((stat, index) => (
          <div key={index} className="cyber-card p-4 rounded-lg text-center">
            <p className={`text-2xl font-bold font-mono ${stat.color}`}>{stat.value}</p>
            <p className="text-xs text-green-400/70 font-mono uppercase tracking-wider">{stat.label}</p>
          </div>
        ))}
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.2 }} className="cyber-card p-1 rounded-lg">
        <div className="flex space-x-1">
          {[
            { id: 'commits', label: 'Commits', icon: GitCommit },
            { id: 'branches', label: 'Branches', icon: GitBranch },
            { id: 'pulls', label: 'Pull Requests', icon: GitMerge }
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)} className={`flex-1 flex items-center justify-center space-x-2 px-4 py-3 rounded cyber-button transition-colors ${activeTab === tab.id ? 'bg-green-400/20' : ''}`}>
                <Icon className="w-4 h-4" />
                <span className="text-sm font-mono uppercase">{tab.label}</span>
              </button>
            );
          })}
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.3 }}>
        {renderContent()}
      </motion.div>
    </div>
  );
};

export default VersionControl;