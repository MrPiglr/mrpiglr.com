import React, { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Users, Shield, BarChart, Server, Terminal, Bell, Bug, Loader2, Wrench, UserPlus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import ManageUsersModal from '@/components/modals/admin/ManageUsersModal';
import SystemLogsModal from '@/components/modals/admin/SystemLogsModal';
import BroadcastMessageModal from '@/components/modals/admin/BroadcastMessageModal';
import ManagePermissionsModal from '@/components/modals/admin/ManagePermissionsModal';
import MaintenanceManager from '@/components/admin/MaintenanceManager';
import InviteDeveloperModal from '@/components/modals/InviteDeveloperModal';
import { useActivity } from '@/hooks/useActivity.jsx';
import { supabase } from '@/lib/customSupabaseClient';
import useDataFetching from '@/hooks/useDataFetching';

const fetchUsersFunction = async () => {
  const { data, error } = await supabase.from('profiles').select('*');
  if (error) throw error;
  return data;
};

const AdminPanel = () => {
  const { toast } = useToast();
  const { addActivity } = useActivity();
  const { data: users, loading, refetch } = useDataFetching(
    fetchUsersFunction, 
    false, 
    []
  );

  const [isManageUsersModalOpen, setManageUsersModalOpen] = useState(false);
  const [isSystemLogsModalOpen, setSystemLogsModalOpen] = useState(false);
  const [isBroadcastMessageModalOpen, setBroadcastMessageModalOpen] = useState(false);
  const [isManagePermissionsModalOpen, setManagePermissionsModalOpen] = useState(false);
  const [isMaintenanceManagerOpen, setMaintenanceManagerOpen] = useState(false);
  const [isInviteDeveloperModalOpen, setInviteDeveloperModalOpen] = useState(false);


  const handleAddUser = async (newUser) => {
    addActivity({ type: 'admin', message: `Attempting to add new user: ${newUser.username}` });
    toast({ title: '> USER ADDITION', description: `This feature is not fully implemented yet. Please invite users through the standard sign-up process.` });
  };

  const handleEditUser = async (updatedUser) => {
    try {
      const { error } = await supabase.from('profiles').update(updatedUser).eq('id', updatedUser.id);
      if (error) throw error;
      refetch();
      addActivity({ type: 'admin', message: `Updated user: ${updatedUser.username}` });
      toast({ title: '> USER UPDATED', description: `Details for ${updatedUser.username} have been updated.` });
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error updating user', description: error.message });
    }
  };
  
  const handleDeleteUser = async (userId) => {
    const userToDelete = users.find(u => u.id === userId);
    try {
      const { error } = await supabase.rpc('delete_user_by_admin', { target_user_id: userId });
      if (error) throw error;
      refetch();
      addActivity({ type: 'admin', message: `Deleted user: ${userToDelete?.username || 'Unknown'}` });
      toast({ title: '> USER DELETED', description: `${userToDelete?.username || 'User'} has been removed from the system.`, variant: 'destructive' });
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error deleting user', description: error.message });
    }
  };

  const handleAdminAction = (action) => {
    switch (action) {
      case 'Manage Users':
        setManageUsersModalOpen(true);
        break;
      case 'View System Logs':
        setSystemLogsModalOpen(true);
        break;
      case 'Broadcast Message':
        setBroadcastMessageModalOpen(true);
        break;
      case 'Manage Permissions':
        setManagePermissionsModalOpen(true);
        break;
      case 'Maintenance Mode':
        setMaintenanceManagerOpen(true);
        break;
      case 'Invite Developer':
        setInviteDeveloperModalOpen(true);
        break;
      default:
        toast({
          title: `> ADMIN ACTION: ${action.toUpperCase()}`,
          description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
        });
    }
  };

  const stats = [
    { label: 'Total Users', value: users?.length || 0, icon: Users, color: 'text-green-400' },
    { label: 'Active Projects', value: '24', icon: BarChart, color: 'text-cyan-400' },
    { label: 'Server Load', value: '34%', icon: Server, color: 'text-yellow-400' },
    { label: 'Open Tickets', value: '7', icon: Bug, color: 'text-red-400' },
  ];

  const actions = [
    { label: 'Manage Users', icon: Users, action: 'Manage Users' },
    { label: 'Invite Developer', icon: UserPlus, action: 'Invite Developer' },
    { label: 'System Logs', icon: Terminal, action: 'View System Logs' },
    { label: 'Broadcast Message', icon: Bell, action: 'Broadcast Message' },
    { label: 'Manage Permissions', icon: Shield, action: 'Manage Permissions' },
    { label: 'Maintenance Mode', icon: Wrench, action: 'Maintenance Mode' },
  ];

  if (loading) {
    return (
      <div className="flex justify-center items-center h-full">
        <Loader2 className="w-16 h-16 text-green-400 animate-spin" />
      </div>
    );
  }

  return (
    <>
      <div className="space-y-6 cyber-card p-6 rounded-lg">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h1 className="text-3xl font-bold terminal-glow tracking-wider uppercase">
            &gt; ADMIN_CONTROL_PANEL
          </h1>
          <p className="text-green-400/70 font-mono mt-2">
            System-wide management and monitoring interface
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {stats.map((stat, index) => (
            <div key={index} className="cyber-card p-6 rounded-lg">
              <div className="flex items-center justify-between mb-4">
                <p className="text-sm text-green-400/70 font-mono uppercase tracking-wider">{stat.label}</p>
                <stat.icon className={`w-6 h-6 ${stat.color}`} />
              </div>
              <p className={`text-4xl font-bold font-mono ${stat.color}`}>{stat.value}</p>
            </div>
          ))}
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="cyber-card p-6 rounded-lg"
          >
            <h2 className="text-xl font-bold text-green-400 font-mono uppercase tracking-wider mb-4">&gt; QUICK_ACTIONS</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {actions.map((action, index) => (
                <Button
                  key={index}
                  onClick={() => handleAdminAction(action.action)}
                  className="cyber-button p-4 flex items-center justify-start space-x-3"
                >
                  <action.icon className="w-5 h-5" />
                  <span className="font-mono">{action.label}</span>
                </Button>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="cyber-card p-6 rounded-lg"
          >
            <h2 className="text-xl font-bold text-green-400 font-mono uppercase tracking-wider mb-4">&gt; SYSTEM_HEALTH</h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="font-mono text-sm">API Status</span>
                <span className="font-mono text-sm status-online">OPERATIONAL</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-mono text-sm">Database</span>
                <span className="font-mono text-sm status-online">CONNECTED</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-mono text-sm">Cloud Storage</span>
                <span className="font-mono text-sm status-online">SYNCED</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-mono text-sm">Build Queue</span>
                <span className="font-mono text-sm text-yellow-400">3 PENDING</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
      <ManageUsersModal 
        isOpen={isManageUsersModalOpen} 
        onClose={() => setManageUsersModalOpen(false)}
        users={users || []}
        onAddUser={handleAddUser}
        onEditUser={handleEditUser}
        onDeleteUser={handleDeleteUser}
      />
      <SystemLogsModal isOpen={isSystemLogsModalOpen} onClose={() => setSystemLogsModalOpen(false)} />
      <BroadcastMessageModal isOpen={isBroadcastMessageModalOpen} onClose={() => setBroadcastMessageModalOpen(false)} />
      <ManagePermissionsModal isOpen={isManagePermissionsModalOpen} onClose={() => setManagePermissionsModalOpen(false)} users={users || []} />
      <MaintenanceManager isOpen={isMaintenanceManagerOpen} onClose={() => setMaintenanceManagerOpen(false)} />
      <InviteDeveloperModal isOpen={isInviteDeveloperModalOpen} onClose={() => setInviteDeveloperModalOpen(false)} />
    </>
  );
};

export default AdminPanel;