import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { supabase } from '@/lib/customSupabaseClient';
import LoadingScreen from '@/components/LoadingScreen';
import { useToast } from '@/components/ui/use-toast';
import { Users, ThumbsUp, Gamepad2 } from 'lucide-react';

const GameCard = ({ game }) => {
  const ratingPercentage = (game.likes + game.dislikes > 0) ? Math.round((game.likes / (game.likes + game.dislikes)) * 100) : 0;

  return (
    <Link to={`/games/${game.id}`}>
      <motion.div 
        className="cyber-card group relative overflow-hidden rounded-lg h-full flex flex-col"
        whileHover={{ y: -5, boxShadow: '0 0 25px rgba(0, 255, 135, 0.5)' }}
        transition={{ type: 'spring', stiffness: 300 }}
      >
        <div className="relative">
          <img className="w-full h-40 object-cover" alt={`${game.title} banner`} src={game.image_url || "https://images.unsplash.com/photo-1580236899421-7751b16a4d54"} />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent"></div>
          <span className={`absolute top-2 right-2 text-xs font-mono uppercase px-2 py-1 rounded cyber-border ${game.status === 'launched' ? 'text-green-400 border-green-400/30' : 'text-yellow-400 border-yellow-400/30'}`}>{game.status}</span>
        </div>
        <div className="p-4 flex flex-col flex-grow">
          <h3 className="text-lg font-bold terminal-glow truncate group-hover:text-cyan-400 transition-colors">{game.title}</h3>
          <p className="text-xs text-green-400/70 mb-2">{game.genre}</p>
          <p className="text-sm text-green-400/80 leading-relaxed line-clamp-2 flex-grow">{game.description}</p>
          <div className="mt-4 flex justify-between items-center text-xs font-mono">
            <div className="flex items-center space-x-2">
              <Users className="w-4 h-4 text-cyan-400"/>
              <span>{game.active_users.toLocaleString()}</span>
            </div>
            <div className="flex items-center space-x-2">
              <ThumbsUp className="w-4 h-4 text-purple-400"/>
              <span>{ratingPercentage}%</span>
            </div>
          </div>
        </div>
      </motion.div>
    </Link>
  );
};

const GamesListPage = () => {
  const { toast } = useToast();
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchGames = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('games')
        .select('*')
        .order('active_users', { ascending: false });
      
      if (error) {
        toast({ variant: 'destructive', title: 'Error', description: 'Could not fetch games list.' });
        console.error(error);
      } else {
        setGames(data);
      }
      setLoading(false);
    };
    fetchGames();
  }, [toast]);

  if (loading) return <LoadingScreen />;

  return (
    <div className="min-h-screen bg-black text-green-400 font-mono p-4 sm:p-6 lg:p-8">
      <Helmet>
        <title>Explore Games - GameForge</title>
        <meta name="description" content="Browse and discover a universe of games created on the GameForge platform." />
      </Helmet>
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }} 
        animate={{ opacity: 1, y: 0 }} 
        transition={{ duration: 0.5 }}
        className="max-w-screen-xl mx-auto"
      >
        <div className="flex items-center space-x-4 mb-8">
          <Gamepad2 className="w-10 h-10 text-cyan-400 terminal-glow" />
          <div>
            <h1 className="text-3xl md:text-5xl font-bold terminal-glow">Explore Experiences</h1>
            <p className="text-green-400/70">Discover games and worlds created by the community.</p>
          </div>
        </div>

        {games.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {games.map((game, index) => (
              <motion.div
                key={game.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
              >
                <GameCard game={game} />
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-20 cyber-card">
            <h2 className="text-2xl font-bold terminal-glow">No Games Found</h2>
            <p className="text-green-400/70 mt-2">The universe is quiet... for now. Check back soon for new experiences!</p>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default GamesListPage;