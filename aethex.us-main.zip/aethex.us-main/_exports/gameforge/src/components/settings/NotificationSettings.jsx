import React from 'react';

const NotificationSettings = ({ settings, onChange }) => {
  const handleToggle = (key) => {
    onChange('notifications', key, !settings[key]);
  };

  const notificationOptions = [
    { key: 'emailNotifications', label: 'Email Notifications', desc: 'Receive notifications via email' },
    { key: 'pushNotifications', label: 'Push Notifications', desc: 'Browser push notifications' },
    { key: 'commitNotifications', label: 'Commit Notifications', desc: 'Notify on new commits' },
    { key: 'prNotifications', label: 'Pull Request Notifications', desc: 'Notify on PR activities' },
    { key: 'buildNotifications', label: 'Build Notifications', desc: 'Notify on build status changes' },
    { key: 'teamNotifications', label: 'Team Notifications', desc: 'Notify on team activities' }
  ];

  return (
    <div className="space-y-6">
      <div className="cyber-card p-6 rounded-lg">
        <h3 className="text-lg font-bold text-green-400 font-mono uppercase mb-4">
          Notification Preferences
        </h3>
        <div className="space-y-4">
          {notificationOptions.map((item) => (
            <div key={item.key} className="flex items-center justify-between">
              <div>
                <p className="text-sm font-mono text-green-400">{item.label}</p>
                <p className="text-xs text-green-400/70 font-mono">{item.desc}</p>
              </div>
              <button
                onClick={() => handleToggle(item.key)}
                className={`w-12 h-6 rounded-full transition-colors ${
                  settings[item.key] ? 'bg-green-400' : 'bg-gray-600'
                }`}
              >
                <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings[item.key] ? 'translate-x-6' : 'translate-x-1'
                }`}></div>
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default NotificationSettings;