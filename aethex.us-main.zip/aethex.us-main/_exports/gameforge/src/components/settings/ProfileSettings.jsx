import React from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const ProfileSettings = ({ settings, onChange }) => {
  const { toast } = useToast();

  const handleChange = (e) => {
    onChange('profile', e.target.name, e.target.value);
  };

  const handleAvatarChange = () => {
    toast({
      title: `> ACTION: CHANGE AVATAR`,
      description: "Looks like MrPiglr hasn't wired this up yet. Give him a nudge! 🐷",
      variant: 'destructive'
    });
  };

  return (
    <div className="space-y-6">
      <div className="cyber-card p-6 rounded-lg">
        <h3 className="text-lg font-bold text-green-400 font-mono uppercase mb-4">
          Profile Information
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm text-green-400/70 font-mono uppercase mb-2">
              Username
            </label>
            <input
              type="text"
              name="username"
              value={settings.username}
              className="w-full bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono focus:outline-none focus:ring-2 focus:ring-green-400/50"
              readOnly
            />
          </div>
          <div>
            <label className="block text-sm text-green-400/70 font-mono uppercase mb-2">
              Email
            </label>
            <input
              type="email"
              name="email"
              value={settings.email}
              onChange={handleChange}
              className="w-full bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono focus:outline-none focus:ring-2 focus:ring-green-400/50"
            />
          </div>
          <div>
            <label className="block text-sm text-green-400/70 font-mono uppercase mb-2">
              Display Name
            </label>
            <input
              type="text"
              name="displayName"
              value={settings.displayName}
              onChange={handleChange}
              className="w-full bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono focus:outline-none focus:ring-2 focus:ring-green-400/50"
            />
          </div>
          <div>
            <label className="block text-sm text-green-400/70 font-mono uppercase mb-2">
              Avatar
            </label>
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 cyber-border rounded-full bg-green-400/20 flex items-center justify-center">
                <span className="text-lg font-bold text-green-400 font-mono">{settings.avatar}</span>
              </div>
              <Button
                onClick={handleAvatarChange}
                className="cyber-button"
                size="sm"
              >
                CHANGE
              </Button>
            </div>
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm text-green-400/70 font-mono uppercase mb-2">
              Bio
            </label>
            <textarea
              name="bio"
              value={settings.bio}
              onChange={handleChange}
              rows={3}
              className="w-full bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono focus:outline-none focus:ring-2 focus:ring-green-400/50"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileSettings;