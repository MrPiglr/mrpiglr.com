import React, { useContext } from 'react';
import useSound from 'use-sound';
import { AppearanceContext } from '@/context/AppearanceContext';

const AppearanceSettings = ({ settings, onChange }) => {
  const { appearance } = useContext(AppearanceContext);
  const [playToggle] = useSound('/sounds/toggle.mp3', { volume: 0.5, soundEnabled: appearance.soundEffects });
  const [playSelect] = useSound('/sounds/select.mp3', { volume: 0.5, soundEnabled: appearance.soundEffects });

  const handleToggle = (key) => {
    onChange('appearance', key, !settings[key]);
    playToggle();
  };

  const handleSelectChange = (e) => {
    onChange('appearance', e.target.name, e.target.value);
    playSelect();
  };

  const toggleOptions = [
    { key: 'animations', label: 'Animations', desc: 'Enable interface animations' },
    { key: 'soundEffects', label: 'Sound Effects', desc: 'Enable UI sound effects' },
    { key: 'terminalMode', label: 'Terminal Mode', desc: 'Enhanced terminal aesthetics' }
  ];

  return (
    <div className="space-y-6">
      <div className="cyber-card p-6 rounded-lg">
        <h3 className="text-lg font-bold text-green-400 font-mono uppercase mb-4">
          Appearance Settings
        </h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-mono text-green-400">Theme</p>
              <p className="text-xs text-green-400/70 font-mono">Visual theme preference</p>
            </div>
            <select
              name="theme"
              value={settings.theme}
              onChange={handleSelectChange}
              className="bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono focus:outline-none focus:ring-2 focus:ring-green-400/50"
            >
              <option value="cyberpunk">Cyberpunk</option>
              <option value="matrix">Matrix</option>
              <option value="neon">Neon</option>
              <option value="classic">Classic</option>
            </select>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-mono text-green-400">Font Size</p>
              <p className="text-xs text-green-400/70 font-mono">Interface font size</p>
            </div>
            <select
              name="fontSize"
              value={settings.fontSize}
              onChange={handleSelectChange}
              className="bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono focus:outline-none focus:ring-2 focus:ring-green-400/50"
            >
              <option value="small">Small</option>
              <option value="medium">Medium</option>
              <option value="large">Large</option>
            </select>
          </div>

          {toggleOptions.map((item) => (
            <div key={item.key} className="flex items-center justify-between">
              <div>
                <p className="text-sm font-mono text-green-400">{item.label}</p>
                <p className="text-xs text-green-400/70 font-mono">{item.desc}</p>
              </div>
              <button
                onClick={() => handleToggle(item.key)}
                className={`w-12 h-6 rounded-full transition-colors ${
                  settings[item.key] ? 'bg-green-400' : 'bg-gray-600'
                }`}
              >
                <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings[item.key] ? 'translate-x-6' : 'translate-x-1'
                }`}></div>
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AppearanceSettings;