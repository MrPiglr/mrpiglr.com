import React from 'react';
import { Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const IntegrationSettings = ({ settings, onChange, onAction }) => {
  const handleToggle = (key) => {
    onChange('integrations', key, !settings[key]);
  };

  const integrations = [
    { key: 'githubConnected', label: 'GitHub', desc: 'Connect your GitHub account', icon: '🐙' },
    { key: 'discordConnected', label: 'Discord', desc: 'Team communication integration', icon: '💬' },
    { key: 'slackConnected', label: 'Slack', desc: 'Workspace notifications', icon: '📱' },
    { key: 'webhooksEnabled', label: 'Webhooks', desc: 'Custom webhook endpoints', icon: '🔗' }
  ];

  return (
    <div className="space-y-6">
      <div className="cyber-card p-6 rounded-lg">
        <h3 className="text-lg font-bold text-green-400 font-mono uppercase mb-4">
          External Integrations
        </h3>
        <div className="space-y-4">
          {integrations.map((item) => (
            <div key={item.key} className="flex items-center justify-between p-4 cyber-border rounded">
              <div className="flex items-center space-x-3">
                <span className="text-2xl">{item.icon}</span>
                <div>
                  <p className="text-sm font-mono text-green-400">{item.label}</p>
                  <p className="text-xs text-green-400/70 font-mono">{item.desc}</p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                {settings[item.key] ? (
                  <span className="text-xs font-mono text-green-400 flex items-center space-x-1">
                    <Check className="w-3 h-3" />
                    <span>CONNECTED</span>
                  </span>
                ) : (
                  <span className="text-xs font-mono text-red-400 flex items-center space-x-1">
                    <X className="w-3 h-3" />
                    <span>DISCONNECTED</span>
                  </span>
                )}
                <Button
                  onClick={() => handleToggle(item.key)}
                  className="cyber-button"
                  size="sm"
                >
                  {settings[item.key] ? 'DISCONNECT' : 'CONNECT'}
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default IntegrationSettings;