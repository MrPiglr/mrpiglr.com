import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Link, Plus, Trash2, Edit, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import ConfirmationModal from '@/components/modals/ConfirmationModal';
import DomainFormModal from '@/components/modals/DomainFormModal';

const DomainSettings = ({ domains, setSettings }) => {
  const { toast } = useToast();
  const [isFormModalOpen, setFormModalOpen] = useState(false);
  const [isConfirmModalOpen, setConfirmModalOpen] = useState(false);
  const [editingDomain, setEditingDomain] = useState(null);
  const [deletingDomainId, setDeletingDomainId] = useState(null);

  const handleOpenFormModal = (domain = null) => {
    setEditingDomain(domain);
    setFormModalOpen(true);
  };

  const handleCloseFormModal = () => {
    setEditingDomain(null);
    setFormModalOpen(false);
  };

  const handleSaveDomain = (domainData) => {
    setSettings(prev => {
      const newDomains = editingDomain
        ? prev.domains.map(d => d.id === editingDomain.id ? { ...d, ...domainData } : d)
        : [...prev.domains, { ...domainData, id: Date.now() }];
      return { ...prev, domains: newDomains };
    });
    toast({
      title: `> DOMAIN ${editingDomain ? 'UPDATED' : 'ADDED'}`,
      description: `Domain ${domainData.url} has been saved.`,
    });
    handleCloseFormModal();
  };

  const openDeleteConfirm = (domainId) => {
    setDeletingDomainId(domainId);
    setConfirmModalOpen(true);
  };

  const confirmDelete = () => {
    setSettings(prev => ({
      ...prev,
      domains: prev.domains.filter(d => d.id !== deletingDomainId)
    }));
    toast({
      title: '> DOMAIN DELETED',
      description: 'The domain has been removed.',
      variant: 'destructive'
    });
    setConfirmModalOpen(false);
    setDeletingDomainId(null);
  };

  return (
    <>
      <div className="space-y-6">
        <div className="cyber-card p-6 rounded-lg">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-green-400 font-mono uppercase">
              Internal Domains
            </h3>
            <Button onClick={() => handleOpenFormModal()} className="cyber-button">
              <Plus className="w-4 h-4 mr-2" />
              ADD_DOMAIN
            </Button>
          </div>
          <p className="text-xs text-green-400/70 font-mono mb-4">
            Manage internal domains for cross-site communication and API endpoints.
          </p>
          <div className="space-y-3">
            {domains.map((domain, index) => (
              <motion.div
                key={domain.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="flex items-center justify-between p-4 cyber-border rounded"
              >
                <div className="flex items-center space-x-3">
                  <Link className="w-4 h-4 text-green-400/70" />
                  <div>
                    <p className="text-sm font-mono text-green-400">{domain.url}</p>
                    <p className={`text-xs font-mono uppercase ${domain.status === 'active' ? 'text-green-400' : 'text-yellow-400'}`}>
                      {domain.status}
                    </p>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button onClick={() => handleOpenFormModal(domain)} className="cyber-button p-2" variant="ghost" size="sm">
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button onClick={() => openDeleteConfirm(domain.id)} className="cyber-button p-2" variant="ghost" size="sm">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </motion.div>
            ))}
             {domains.length === 0 && (
                <div className="text-center py-8">
                    <Globe className="w-12 h-12 text-green-400/30 mx-auto mb-4" />
                    <p className="text-green-400/70 font-mono">NO_DOMAINS_CONFIGURED</p>
                </div>
            )}
          </div>
        </div>
      </div>
      <DomainFormModal
        isOpen={isFormModalOpen}
        onClose={handleCloseFormModal}
        onSave={handleSaveDomain}
        domain={editingDomain}
      />
      <ConfirmationModal
        isOpen={isConfirmModalOpen}
        onClose={() => setConfirmModalOpen(false)}
        onConfirm={confirmDelete}
        title="> CONFIRM DELETION"
        icon={<Trash2 className="w-12 h-12 text-red-400" />}
      >
        <p className="text-green-400/80 font-mono text-center">Are you sure you want to delete this domain?</p>
        <p className="text-yellow-400/80 font-mono text-sm text-center mt-2">This action cannot be undone.</p>
      </ConfirmationModal>
    </>
  );
};

export default DomainSettings;