import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Trash2, Edit, Terminal, Key } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import ConfirmationModal from '@/components/modals/ConfirmationModal';

const ProjectSettings = ({ settings, setSettings }) => {
  const { toast } = useToast();
  const [editingVar, setEditingVar] = useState(null);
  const [isConfirmModalOpen, setConfirmModalOpen] = useState(false);
  const [deletingVarId, setDeletingVarId] = useState(null);
  const [newVar, setNewVar] = useState({ key: '', value: '' });

  const handleProjectSettingChange = (key, value) => {
    setSettings(prev => ({ ...prev, project: { ...prev.project, [key]: value } }));
  };
  
  const handleSelectChange = (e) => {
    handleProjectSettingChange(e.target.name, e.target.value);
  };

  const handleToggle = (key) => {
    handleProjectSettingChange(key, !settings[key]);
  };
  
  const handleAddOrUpdateVar = () => {
    if (!newVar.key || !newVar.value) {
      toast({ title: 'ERROR', description: 'Key and Value cannot be empty.', variant: 'destructive' });
      return;
    }

    if (editingVar) {
      handleProjectSettingChange('envVars', settings.envVars.map(v => v.id === editingVar.id ? { ...v, ...newVar } : v));
      toast({ title: 'Variable Updated', description: `Variable ${newVar.key} has been updated.` });
      setEditingVar(null);
    } else {
      handleProjectSettingChange('envVars', [...settings.envVars, { ...newVar, id: Date.now() }]);
      toast({ title: 'Variable Added', description: `Variable ${newVar.key} has been added.` });
    }
    setNewVar({ key: '', value: '' });
  };
  
  const handleEditClick = (envVar) => {
    setEditingVar(envVar);
    setNewVar({ key: envVar.key, value: envVar.value });
  };
  
  const openDeleteConfirm = (varId) => {
    setDeletingVarId(varId);
    setConfirmModalOpen(true);
  };
  
  const confirmDelete = () => {
    handleProjectSettingChange('envVars', settings.envVars.filter(v => v.id !== deletingVarId));
    toast({ title: 'Variable Deleted', description: 'Environment variable has been removed.', variant: 'destructive' });
    setConfirmModalOpen(false);
    setDeletingVarId(null);
  };

  return (
    <>
      <div className="space-y-6">
        <div className="cyber-card p-6 rounded-lg">
          <h3 className="text-lg font-bold text-green-400 font-mono uppercase mb-4">
            Build & Deployment
          </h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-mono text-green-400">Default Build Command</p>
                <p className="text-xs text-green-400/70 font-mono">Command to run for production builds</p>
              </div>
              <select
                name="defaultBuildCommand"
                value={settings.defaultBuildCommand}
                onChange={handleSelectChange}
                className="bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono focus:outline-none focus:ring-2 focus:ring-green-400/50"
              >
                <option value="npm run build">npm run build</option>
                <option value="vite build">vite build</option>
                <option value="yarn build">yarn build</option>
              </select>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-mono text-green-400">Auto Deploy on Push</p>
                <p className="text-xs text-green-400/70 font-mono">Automatically deploy on main branch push</p>
              </div>
              <button onClick={() => handleToggle('autoDeploy')} className={`w-12 h-6 rounded-full transition-colors ${settings.autoDeploy ? 'bg-green-400' : 'bg-gray-600'}`}>
                <div className={`w-5 h-5 rounded-full bg-white transition-transform ${settings.autoDeploy ? 'translate-x-6' : 'translate-x-1'}`}></div>
              </button>
            </div>
             <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-mono text-green-400">Clean Target Directory</p>
                <p className="text-xs text-green-400/70 font-mono">Clear output folder before build</p>
              </div>
              <button onClick={() => handleToggle('cleanTargetDirectory')} className={`w-12 h-6 rounded-full transition-colors ${settings.cleanTargetDirectory ? 'bg-green-400' : 'bg-gray-600'}`}>
                <div className={`w-5 h-5 rounded-full bg-white transition-transform ${settings.cleanTargetDirectory ? 'translate-x-6' : 'translate-x-1'}`}></div>
              </button>
            </div>
          </div>
        </div>
        <div className="cyber-card p-6 rounded-lg">
          <h3 className="text-lg font-bold text-green-400 font-mono uppercase mb-4">
            Environment Variables
          </h3>
          <div className="space-y-3 mb-6">
            {settings.envVars.map((envVar, index) => (
              <motion.div key={envVar.id} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.4, delay: index * 0.1 }} className="flex items-center justify-between p-3 cyber-border rounded">
                <div className="flex items-center space-x-3">
                  <Key className="w-4 h-4 text-green-400/70" />
                  <div>
                    <p className="text-sm font-mono text-green-400">{envVar.key}</p>
                    <p className="text-xs font-mono text-green-400/70">••••••••••••</p>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button onClick={() => handleEditClick(envVar)} className="cyber-button p-2" variant="ghost" size="sm"><Edit className="w-4 h-4" /></Button>
                  <Button onClick={() => openDeleteConfirm(envVar.id)} className="cyber-button p-2" variant="ghost" size="sm"><Trash2 className="w-4 h-4" /></Button>
                </div>
              </motion.div>
            ))}
          </div>
          <div className="space-y-4">
            <h4 className="text-md font-bold text-green-400 font-mono uppercase">{editingVar ? 'Edit Variable' : 'Add New Variable'}</h4>
            <div className="flex flex-col md:flex-row gap-4">
                <input type="text" placeholder="KEY" value={newVar.key} onChange={(e) => setNewVar({...newVar, key: e.target.value})} className="flex-1 bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono focus:outline-none focus:ring-2 focus:ring-green-400/50" />
                <input type="text" placeholder="VALUE" value={newVar.value} onChange={(e) => setNewVar({...newVar, value: e.target.value})} className="flex-1 bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono focus:outline-none focus:ring-2 focus:ring-green-400/50" />
                <Button onClick={handleAddOrUpdateVar} className="cyber-button"><Plus className="w-4 h-4 mr-2" />{editingVar ? 'UPDATE' : 'ADD'}</Button>
            </div>
          </div>
        </div>
      </div>
       <ConfirmationModal
        isOpen={isConfirmModalOpen}
        onClose={() => setConfirmModalOpen(false)}
        onConfirm={confirmDelete}
        title="> CONFIRM DELETION"
        icon={<Trash2 className="w-12 h-12 text-red-400" />}
      >
        <p className="text-green-400/80 font-mono text-center">Are you sure you want to delete this environment variable?</p>
        <p className="text-yellow-400/80 font-mono text-sm text-center mt-2">This action cannot be undone and may break deployments.</p>
      </ConfirmationModal>
    </>
  );
};

export default ProjectSettings;