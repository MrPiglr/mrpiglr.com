import React from 'react';
import { Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';

const SecuritySettings = ({ settings, onChange, onAction }) => {
  const handleToggle = (key) => {
    onChange('security', key, !settings[key]);
  };

  const handleSelectChange = (e) => {
    onChange('security', e.target.name, e.target.value);
  };

  return (
    <div className="space-y-6">
      <div className="cyber-card p-6 rounded-lg">
        <h3 className="text-lg font-bold text-green-400 font-mono uppercase mb-4">
          Security Settings
        </h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-mono text-green-400">Two-Factor Authentication</p>
              <p className="text-xs text-green-400/70 font-mono">Add an extra layer of security</p>
            </div>
            <button
              onClick={() => handleToggle('twoFactorEnabled')}
              className={`w-12 h-6 rounded-full transition-colors ${
                settings.twoFactorEnabled ? 'bg-green-400' : 'bg-gray-600'
              }`}
            >
              <div className={`w-5 h-5 rounded-full bg-white transition-transform ${
                settings.twoFactorEnabled ? 'translate-x-6' : 'translate-x-1'
              }`}></div>
            </button>
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-mono text-green-400">Session Timeout</p>
              <p className="text-xs text-green-400/70 font-mono">Auto-logout after inactivity</p>
            </div>
            <select
              name="sessionTimeout"
              value={settings.sessionTimeout}
              onChange={handleSelectChange}
              className="bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono focus:outline-none focus:ring-2 focus:ring-green-400/50"
            >
              <option value={15}>15 minutes</option>
              <option value={30}>30 minutes</option>
              <option value={60}>1 hour</option>
              <option value={120}>2 hours</option>
            </select>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <div>
                <p className="text-sm font-mono text-green-400">API Key</p>
                <p className="text-xs text-green-400/70 font-mono">For external integrations</p>
              </div>
              <Button
                onClick={() => handleToggle('apiKeyVisible')}
                className="cyber-button p-2"
                variant="ghost"
              >
                {settings.apiKeyVisible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </Button>
            </div>
            <div className="flex space-x-2">
              <input
                type={settings.apiKeyVisible ? 'text' : 'password'}
                value={settings.apiKey}
                className="flex-1 bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono focus:outline-none focus:ring-2 focus:ring-green-400/50"
                readOnly
              />
              <Button
                onClick={() => onAction('Regenerate API Key')}
                className="cyber-button"
              >
                REGENERATE
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecuritySettings;