import React, { useState, useEffect, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Upload, Search, Filter, Grid, List, Loader2, Archive } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useActivity } from '@/hooks/useActivity.jsx';
import { supabase } from '@/lib/customSupabaseClient';
import AssetCard from '@/components/assets/AssetCard';
import AssetRow from '@/components/assets/AssetRow';
import { formatBytes } from '@/components/assets/assetUtils';
import useDataFetching from '@/hooks/useDataFetching';

const fetchAssetsFunction = async (user) => {
  const { data: projectIdsData, error: projectIdsError } = await supabase
    .from('project_team_members')
    .select('project_id')
    .eq('user_id', user.id);
  
  if (projectIdsError) {
    console.error("Error fetching project IDs for assets:", projectIdsError);
    throw projectIdsError;
  }
  
  const projectIds = projectIdsData.map(p => p.project_id);

  if(projectIds.length === 0) {
    return [];
  }

  const { data, error } = await supabase
    .from('assets')
    .select(`
      *,
      projects (title)
    `)
    .in('project_id', projectIds);
  
  if (error) {
    console.error("Error fetching assets:", error);
    throw error;
  }

  return data.map(asset => ({
    ...asset,
    project_title: asset.projects?.title
  }));
};

const AssetManager = ({ onOpenUploadAssets }) => {
  const { toast } = useToast();
  const { addActivity } = useActivity();
  const { data: assets, loading } = useDataFetching(fetchAssetsFunction);
  
  const [stats, setStats] = useState({ totalAssets: 0, storageUsed: 0 });
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [viewMode, setViewMode] = useState('grid');

  useEffect(() => {
    if (assets) {
      const totalAssets = assets.length;
      const storageUsed = assets.reduce((acc, asset) => acc + (asset.size || 0), 0);
      setStats({ totalAssets, storageUsed });
    }
  }, [assets]);

  const handleAction = (action, assetName = '') => {
    addActivity({ type: 'asset', message: `${action}: ${assetName}` });
    toast({
      title: `> ASSET ACTION: ${action.toUpperCase()}`,
      description: `Looks like MrPiglr hasn't wired this up yet. Give him a nudge! 🐷`,
    });
  };

  const filteredAssets = (assets || []).filter(asset => {
    const matchesSearch = asset.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (asset.tags && asset.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase())));
    const matchesFilter = filterType === 'all' || (asset.file_type && asset.file_type.startsWith(filterType));
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="space-y-6 cyber-card p-6 rounded-lg">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-3xl font-bold terminal-glow tracking-wider uppercase">
            &gt; ASSET_MANAGER
          </h1>
          <p className="text-green-400/70 font-mono mt-2">
            Secure cloud storage for game assets with version control and backup
          </p>
        </div>
        <Button 
          onClick={onOpenUploadAssets}
          className="cyber-button"
        >
          <Upload className="w-4 h-4 mr-2" />
          UPLOAD_ASSETS
        </Button>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
        className="cyber-card p-4 rounded-lg"
      >
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-green-400/50" />
            <input
              type="text"
              placeholder="SEARCH_ASSETS..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-black/50 cyber-border rounded px-10 py-2 text-green-400 font-mono placeholder-green-400/50 focus:outline-none focus:ring-2 focus:ring-green-400/50"
            />
          </div>
          <div className="flex space-x-2">
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono focus:outline-none focus:ring-2 focus:ring-green-400/50"
            >
              <option value="all">ALL_TYPES</option>
              <option value="image">IMAGES</option>
              <option value="audio">AUDIO</option>
              <option value="video">VIDEO</option>
              <option value="application">ARCHIVES/MODELS</option>
            </select>
            <Button 
              onClick={() => setViewMode(viewMode === 'grid' ? 'list' : 'grid')}
              className="cyber-button"
              variant="outline"
            >
              {viewMode === 'grid' ? <List className="w-4 h-4" /> : <Grid className="w-4 h-4" />}
            </Button>
            <Button 
              onClick={() => handleAction('Advanced Filters')}
              className="cyber-button"
              variant="outline"
            >
              <Filter className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="grid grid-cols-1 md:grid-cols-4 gap-4"
      >
        {[
          { label: 'Total Assets', value: stats.totalAssets, color: 'text-green-400' },
          { label: 'Storage Used', value: formatBytes(stats.storageUsed), color: 'text-cyan-400' },
          { label: 'Active Backups', value: '3', color: 'text-purple-400' },
          { label: 'Version History', value: '247', color: 'text-yellow-400' }
        ].map((stat, index) => (
          <div key={index} className="cyber-card p-4 rounded-lg text-center">
            <p className={`text-2xl font-bold font-mono ${stat.color}`}>{stat.value}</p>
            <p className="text-xs text-green-400/70 font-mono uppercase tracking-wider">{stat.label}</p>
          </div>
        ))}
      </motion.div>

      {loading ? (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="w-16 h-16 text-green-400 animate-spin" />
        </div>
      ) : viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAssets.map((asset, index) => (
            <AssetCard key={asset.id} asset={asset} index={index} handleAction={handleAction} />
          ))}
        </div>
      ) : (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="cyber-card rounded-lg overflow-hidden"
        >
          <div className="p-4 border-b border-green-400/20">
            <div className="grid grid-cols-6 gap-4 text-xs text-green-400/70 font-mono uppercase tracking-wider">
              <span>Name</span>
              <span>Type</span>
              <span>Size</span>
              <span>Project</span>
              <span>Modified</span>
              <span>Actions</span>
            </div>
          </div>
          <div className="divide-y divide-green-400/10">
            {filteredAssets.map((asset, index) => (
              <AssetRow key={asset.id} asset={asset} index={index} handleAction={handleAction} />
            ))}
          </div>
        </motion.div>
      )}

      {!loading && filteredAssets.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6 }}
          className="cyber-card p-12 rounded-lg text-center"
        >
          <Archive className="w-16 h-16 text-green-400/50 mx-auto mb-4" />
          <h3 className="text-lg font-bold text-green-400 font-mono uppercase mb-2">
            NO_ASSETS_FOUND
          </h3>
          <p className="text-green-400/70 font-mono mb-6">
            There are no assets in the projects you are a part of.
          </p>
          <Button 
            onClick={onOpenUploadAssets}
            className="cyber-button"
          >
            <Upload className="w-4 h-4 mr-2" />
            UPLOAD_ASSETS
          </Button>
        </motion.div>
      )}
    </div>
  );
};

export default AssetManager;