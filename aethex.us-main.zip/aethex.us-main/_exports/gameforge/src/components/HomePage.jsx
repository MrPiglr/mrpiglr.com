import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Code, LogIn, UserPlus, AlertTriangle } from 'lucide-react';
import Login from '@/components/auth/Login';
import Signup from '@/components/auth/Signup';
import { Button } from '@/components/ui/button';

const HomePage = ({ maintenanceMode = false }) => {
  const [activeView, setActiveView] = useState(maintenanceMode ? 'login' : 'intro'); // intro, login, signup
  const [matrixChars, setMatrixChars] = useState([]);

  React.useEffect(() => {
    const chars = Array.from({ length: 100 }, (_, i) => ({
      id: i,
      char: String.fromCharCode(0x30A0 + Math.random() * 96),
      x: Math.random() * 100,
      y: Math.random() * -100,
      delay: Math.random() * 10
    }));
    setMatrixChars(chars);
  }, []);

  const IntroView = () => (
    <motion.div
      key="intro"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.5, ease: 'easeInOut' }}
      className="text-center flex flex-col items-center"
    >
      <motion.div 
        className="w-24 h-24 cyber-border rounded-full bg-green-400/20 flex items-center justify-center pulse-green mb-8"
        whileHover={{ scale: 1.1, rotate: 10 }}
        transition={{ type: 'spring', stiffness: 300 }}
      >
        <Code className="w-12 h-12 text-green-400" />
      </motion.div>
      <h1 className="text-5xl md:text-7xl font-bold terminal-glow tracking-wider uppercase mb-4">GAMEFORGE</h1>
      <p className="text-xl text-green-400/80 font-mono mb-8 max-w-2xl mx-auto typing-effect">
        Powered by AeThex OS
      </p>
      <div className="flex space-x-4">
        <Button onClick={() => setActiveView('login')} className="cyber-button text-lg px-8 py-4">
          <LogIn className="mr-2" />
          LOGIN
        </Button>
        <Button onClick={() => setActiveView('signup')} className="cyber-button text-lg px-8 py-4" variant="outline">
          <UserPlus className="mr-2" />
          SIGN UP
        </Button>
      </div>
    </motion.div>
  );

  return (
    <div className="min-h-screen bg-black text-green-400 relative overflow-hidden font-mono flex items-center justify-center p-4">
       <div className="matrix-bg fixed inset-0 pointer-events-none z-0">
        {matrixChars.map((char) => (
          <div
            key={char.id}
            className="data-stream absolute text-xs"
            style={{ left: `${char.x}%`, top: `${char.y}vh`, animationDelay: `${char.delay}s` }}
          >
            {char.char}
          </div>
        ))}
      </div>
      <div className="scan-line fixed top-0 left-0 w-full h-1 z-20"></div>
      <div className="fixed inset-0 grid-pattern opacity-20 pointer-events-none z-0"></div>

      <div className="relative z-10 w-full max-w-4xl">
        {maintenanceMode && activeView !== 'intro' && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="cyber-card bg-yellow-900/30 border-yellow-400 text-yellow-300 p-4 rounded-lg mb-6 flex items-center space-x-3"
          >
            <AlertTriangle className="w-5 h-5 text-yellow-400" />
            <span className="font-mono text-sm">System is in maintenance mode. Only administrators can log in.</span>
          </motion.div>
        )}
        <AnimatePresence mode="wait">
          {activeView === 'intro' && <IntroView />}
          {activeView === 'login' && <Login onSwitchToSignup={() => setActiveView('signup')} onSwitchToIntro={() => setActiveView('intro')} maintenanceMode={maintenanceMode} />}
          {activeView === 'signup' && <Signup onSwitchToLogin={() => setActiveView('login')} onSwitchToIntro={() => setActiveView('intro')} maintenanceMode={maintenanceMode}/>}
        </AnimatePresence>
      </div>

       <motion.footer 
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.5, ease: "easeOut" }}
        className="absolute bottom-4 text-xs"
      >
        <div className="flex items-center space-x-2">
          <span className="text-green-400/70 font-mono">&copy; {new Date().getFullYear()} GameForge by</span>
          <motion.a href="https://aethex.biz" target="_blank" rel="noopener noreferrer" className="text-green-400 hover:text-cyan-400 transition-colors font-mono terminal-glow" whileHover={{ scale: 1.05 }}>AETHEX.BIZ</motion.a>
        </div>
      </motion.footer>
    </div>
  );
};

export default HomePage;