import React, { useState, useEffect, useCallback, useContext } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Monitor, 
  GitBranch, 
  Users, 
  Settings as SettingsIcon, 
  Activity,
  Database,
  Code,
  FileText,
  User,
  LogOut,
  LayoutDashboard,
  ShieldCheck,
  Menu,
  Trophy,
  Coffee,
  Circle,
  Moon,
  Loader2,
  Gamepad2
} from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
} from "@/components/ui/dropdown-menu";
import Dashboard from '@/components/Dashboard';
import ProjectManager from '@/components/ProjectManager';
import AssetManager from '@/components/AssetManager';
import UsersManager from '@/components/UsersManager';
import VersionControl from '@/components/VersionControl';
import SettingsPage from '@/components/Settings';
import ProfilePage from '@/components/ProfilePage';
import AdminPanel from '@/components/AdminPanel';
import PageTransitionWrapper from '@/components/PageTransitionWrapper';
import { useActivity } from '@/hooks/useActivity.jsx';
import UploadAssetsModal from '@/components/modals/UploadAssetsModal';
import CreateProjectModal from '@/components/modals/CreateProjectModal';
import { AppearanceContext } from '@/context/AppearanceContext';
import { useAuth } from '@/context/AuthContext';
import { AchievementsContext } from '@/context/AchievementsContext';
import { usePresence } from '@/context/PresenceContext';
import LoadingScreen from '@/components/LoadingScreen';
import { Link, useNavigate } from 'react-router-dom';

const MainApp = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [viewedProfileId, setViewedProfileId] = useState(null);
  const [isPageLoading, setIsPageLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [matrixChars, setMatrixChars] = useState([]);
  const { addActivity } = useActivity();
  const { toast } = useToast();
  const navigate = useNavigate();
  
  const { appearance } = useContext(AppearanceContext);
  const { profile, logout, loading: authLoading, isOwnerOrAdmin } = useAuth();
  const { unlockAchievement } = useContext(AchievementsContext);
  const { onlineCount, userStatus, setUserStatus, isSubscribed } = usePresence();

  const [isUploadAssetsModalOpen, setUploadAssetsModalOpen] = useState(false);
  const [isCreateProjectModalOpen, setCreateProjectModalOpen] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const chars = Array.from({ length: 50 }, (_, i) => ({
      id: i,
      char: String.fromCharCode(0x30A0 + Math.random() * 96),
      x: Math.random() * 100,
      delay: Math.random() * 10
    }));
    setMatrixChars(chars);
  }, []);
  
  useEffect(() => {
    const currentHour = new Date().getHours();
    if (currentHour >= 2 && currentHour < 5) {
      unlockAchievement('night_owl');
    }
  }, [unlockAchievement]);

  const formatTime = (date) => date.toLocaleTimeString('en-US', { hour12: false, timeZone: 'UTC' });

  const handleTabChange = useCallback((tab, profileId = null) => {
    if (tab === 'games') {
      navigate('/games');
      return;
    }
    
    if (tab !== activeTab || profileId !== viewedProfileId) {
      setActiveTab(tab);
      setViewedProfileId(profileId);
      addActivity({ type: 'navigation', message: `Navigated to ${tab} module` });
      if (tab === 'admin' && isOwnerOrAdmin) {
        unlockAchievement('admin_power');
      }
    }
  }, [activeTab, viewedProfileId, addActivity, unlockAchievement, isOwnerOrAdmin, navigate]);

  const handleLogoutClick = () => {
    addActivity({ type: 'auth', message: 'User logged out' });
    logout();
  };
  
  const handleProjectCreated = () => {
    unlockAchievement('first_project');
    setCreateProjectModalOpen(false);
  };
  
  const handleAssetsUploaded = () => {
    unlockAchievement('first_asset');
    setUploadAssetsModalOpen(false);
  }
  
  const renderActiveComponent = () => {
    const props = {
      onOpenCreateProject: () => setCreateProjectModalOpen(true),
      onOpenUploadAssets: () => setUploadAssetsModalOpen(true),
      setIsLoading: setIsPageLoading,
      onViewProfile: (profileId) => handleTabChange('profile', profileId),
    };
    switch (activeTab) {
      case 'dashboard': return <Dashboard {...props} />;
      case 'projects': return <ProjectManager {...props} />;
      case 'assets': return <AssetManager {...props} />;
      case 'users': return <UsersManager {...props} />;
      case 'version': return <VersionControl {...props} />;
      case 'settings': return <SettingsPage {...props} />;
      case 'profile': return <ProfilePage {...props} profileId={viewedProfileId} />;
      case 'admin': return isOwnerOrAdmin ? <AdminPanel {...props} /> : <Dashboard {...props} />;
      default: return <Dashboard {...props} />;
    }
  };
  
  const mainAppClasses = `
    min-h-screen bg-black text-green-400 relative overflow-hidden font-mono flex flex-col
    theme-${appearance.theme}
    font-size-${appearance.fontSize}
  `;

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Monitor },
    { id: 'projects', label: 'Projects', icon: FileText },
    { id: 'assets', label: 'Assets', icon: Database },
    { id: 'users', label: 'Users', icon: Users },
    { id: 'version', label: 'Version', icon: GitBranch },
    { id: 'games', label: 'Games', icon: Gamepad2 },
  ];

  const statusOptions = {
    online: { icon: Circle, color: 'text-green-400', label: 'Online' },
    away: { icon: Coffee, color: 'text-yellow-400', label: 'Away' },
    busy: { icon: Moon, color: 'text-red-400', label: 'Busy' },
    offline: { icon: Circle, color: 'text-gray-400', label: 'Offline' },
  };

  const CurrentStatusIcon = statusOptions[userStatus]?.icon || Circle;
  const currentStatusColor = statusOptions[userStatus]?.color || 'text-gray-400';

  if (authLoading || !profile) {
    return <LoadingScreen />;
  }

  return (
    <div className={mainAppClasses} data-animations-enabled={appearance.animations}>
      <div className="matrix-bg fixed inset-0 pointer-events-none z-0">
        {matrixChars.map((char) => (
          <div
            key={char.id}
            className="data-stream absolute text-xs"
            style={{ left: `${char.x}%`, animationDelay: `${char.delay}s` }}
          >
            {char.char}
          </div>
        ))}
      </div>
      <div className="scan-line fixed top-0 left-0 w-full h-1 z-20"></div>
      <div className="fixed inset-0 grid-pattern opacity-20 pointer-events-none z-0"></div>

      <motion.header 
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="cyber-border bg-black/80 backdrop-blur-md p-4 sticky top-0 z-20"
      >
        <div className="max-w-screen-xl mx-auto flex items-center justify-between">
          <motion.div className="flex items-center space-x-3" whileHover={{ scale: 1.05 }}>
            <Link to="/" className="flex items-center space-x-3">
              <div className="w-10 h-10 cyber-border rounded bg-green-400/20 flex items-center justify-center pulse-green">
                <Code className="w-6 h-6 text-green-400" />
              </div>
              <div>
                <h1 className="text-xl md:text-2xl font-bold terminal-glow tracking-wider">GAMEFORGE</h1>
                <p className="text-xs text-green-400/70 uppercase tracking-widest hidden sm:block">Neural Dev Toolkit</p>
              </div>
            </Link>
          </motion.div>

          <nav className="hidden lg:flex space-x-1">
            {navItems.map((tab) => {
              const Icon = tab.icon;
              return (
                <motion.button
                  key={tab.id}
                  onClick={() => handleTabChange(tab.id)}
                  className={`px-4 py-2 rounded cyber-button flex items-center space-x-2 relative ${activeTab === tab.id ? 'bg-green-400/20' : ''}`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-sm font-mono uppercase">{tab.label}</span>
                  {activeTab === tab.id && <motion.div className="absolute bottom-0 left-0 right-0 h-0.5 bg-green-400" layoutId="underline" />}
                </motion.button>
              );
            })}
          </nav>

          <div className="flex items-center space-x-2 md:space-x-4">
            <div className="text-right hidden md:block">
              <div className="text-xs text-green-400/70 uppercase tracking-wider">UTC: {formatTime(currentTime)}</div>
              <div className="text-xs text-cyan-400 uppercase tracking-wider">NEURAL_LINK: ACTIVE</div>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <motion.button className="cyber-button px-3 py-1 rounded flex items-center space-x-2" whileHover={{ scale: 1.05 }} disabled={!isSubscribed}>
                  {!isSubscribed ? <Loader2 className="w-3 h-3 animate-spin" /> : <CurrentStatusIcon className={`w-3 h-3 ${currentStatusColor}`} />}
                  <span className="text-sm font-mono uppercase hidden sm:inline">{profile?.username || 'USER'}</span>
                </motion.button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuGroup>
                  <DropdownMenuItem onClick={() => handleTabChange('dashboard')}>
                    <LayoutDashboard className="mr-2 h-4 w-4" />
                    <span>Dashboard</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleTabChange('profile')}>
                    <User className="mr-2 h-4 w-4" />
                    <span>Profile</span>
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleTabChange('settings')}>
                    <SettingsIcon className="mr-2 h-4 w-4" />
                    <span>Settings</span>
                  </DropdownMenuItem>
                </DropdownMenuGroup>
                <DropdownMenuSeparator />
                <DropdownMenuLabel>Set Status</DropdownMenuLabel>
                 <DropdownMenuRadioGroup value={userStatus} onValueChange={setUserStatus} disabled={!isSubscribed}>
                  {Object.entries(statusOptions).filter(([key]) => key !== 'offline').map(([key, { icon: Icon, color, label }]) => (
                    <DropdownMenuRadioItem key={key} value={key}>
                      <Icon className={`mr-2 h-4 w-4 ${color}`} />
                      <span>{label}</span>
                    </DropdownMenuRadioItem>
                  ))}
                </DropdownMenuRadioGroup>
                {isOwnerOrAdmin && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuGroup>
                      <DropdownMenuItem onClick={() => handleTabChange('admin')}>
                        <ShieldCheck className="mr-2 h-4 w-4" />
                        <span>Admin Panel</span>
                      </DropdownMenuItem>
                    </DropdownMenuGroup>
                  </>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogoutClick}>
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <div className="lg:hidden">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <motion.button className="cyber-button p-2 rounded" whileHover={{ scale: 1.05 }}>
                    <Menu className="w-5 h-5" />
                  </motion.button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56">
                  <DropdownMenuLabel>Navigation</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  {navItems.map((item) => {
                    const Icon = item.icon;
                    return (
                      <DropdownMenuItem key={item.id} onClick={() => handleTabChange(item.id)}>
                        <Icon className="mr-2 h-4 w-4" />
                        <span>{item.label}</span>
                      </DropdownMenuItem>
                    );
                  })}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </motion.header>

      <main className="flex-grow max-w-screen-xl w-full mx-auto p-4 sm:p-6 relative z-10 flex items-center justify-center">
        <AnimatePresence mode="wait">
          <PageTransitionWrapper key={`${activeTab}-${viewedProfileId}`}>
            {renderActiveComponent()}
          </PageTransitionWrapper>
        </AnimatePresence>
      </main>

      <motion.footer 
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.5, ease: "easeOut" }}
        className="cyber-border bg-black/80 backdrop-blur-md p-3 mt-auto z-20"
      >
        <div className="max-w-screen-xl mx-auto flex flex-col sm:flex-row items-center justify-between text-xs gap-2 sm:gap-0">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Activity className="w-4 h-4 text-green-400" />
              <span className="font-mono status-online">SYSTEM_STATUS: ONLINE</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full bg-green-400 pulse-green`}></div>
              <span className="font-mono uppercase status-online">{onlineCount} ONLINE</span>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <span className="text-green-400/70 font-mono">&copy; {new Date().getFullYear()} GameForge by</span>
            <motion.a href="https://aethex.biz" target="_blank" rel="noopener noreferrer" className="text-green-400 hover:text-cyan-400 transition-colors font-mono terminal-glow" whileHover={{ scale: 1.05 }}>AETHEX.BIZ</motion.a>
          </div>
        </div>
      </motion.footer>
      <CreateProjectModal isOpen={isCreateProjectModalOpen} onClose={() => setCreateProjectModalOpen(false)} onSave={handleProjectCreated} />
      <UploadAssetsModal isOpen={isUploadAssetsModalOpen} onClose={() => setUploadAssetsModalOpen(false)} onAssetsUploaded={handleAssetsUploaded}/>
    </div>
  );
};
export default MainApp;