import React, { useContext, useState, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import { User, Mail, Shield, Code, Gamepad2, Calendar, Award, Clock, Copy, Check, Fingerprint, Trophy, Zap, Star, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { AchievementsContext } from '@/context/AchievementsContext';
import { supabase } from '@/lib/customSupabaseClient';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

const AeThexPassport = ({ user, isCopied, handleCopy }) => (
  <motion.div 
    className="cyber-card p-6 rounded-lg bg-gradient-to-br from-green-400/5 to-cyan-400/5 relative overflow-hidden"
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.6, delay: 0.3 }}
  >
    <div className="absolute inset-0 grid-pattern opacity-10"></div>
    <div className="relative z-10">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold text-green-400 font-mono uppercase">&gt; AETHEX PASSPORT</h3>
        <Fingerprint className="w-6 h-6 text-cyan-400 terminal-glow" />
      </div>
      <div className="flex items-center space-x-4">
        <div className="w-16 h-16 cyber-border rounded-full bg-green-400/20 flex items-center justify-center flex-shrink-0">
          <span className="text-2xl font-bold text-green-400 font-mono">{user.avatar}</span>
        </div>
        <div className="flex-grow min-w-0">
          <p className="text-xl font-bold text-green-400 font-mono uppercase">{user.displayName}</p>
          <div className="flex items-center space-x-2 mt-1">
            <p className="text-sm text-cyan-400 font-mono truncate">{user.passportId}</p>
            <Button variant="ghost" size="icon" className="w-8 h-8 flex-shrink-0" onClick={handleCopy}>
              {isCopied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4 text-cyan-400" />}
            </Button>
          </div>
        </div>
      </div>
    </div>
  </motion.div>
);

const AchievementsDisplay = ({ achievements, unlockedAchievements }) => {
  const getRarityColor = (rarity) => {
    switch (rarity) {
      case 'Common': return 'border-gray-500 text-gray-400';
      case 'Rare': return 'border-blue-500 text-blue-400';
      case 'Epic': return 'border-purple-500 text-purple-400';
      case 'Legendary': return 'border-yellow-500 text-yellow-400';
      default: return 'border-gray-600';
    }
  };

  const getIcon = (iconName) => {
    switch(iconName) {
      case 'Trophy': return <Trophy />;
      case 'Zap': return <Zap />;
      case 'Star': return <Star />;
      case 'Shield': return <Shield />;
      default: return <Award />;
    }
  };

  return (
    <div className="cyber-card p-6 rounded-lg">
      <h3 className="text-lg font-bold text-green-400 font-mono uppercase mb-4">&gt; ACHIEVEMENTS</h3>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        <TooltipProvider>
          {achievements.map((ach) => {
            const isUnlocked = unlockedAchievements.has(ach.id);
            return (
              <Tooltip key={ach.id}>
                <TooltipTrigger asChild>
                  <motion.div
                    className={`p-4 rounded text-center cyber-border flex flex-col items-center justify-center aspect-square transition-all duration-300 ${isUnlocked ? getRarityColor(ach.rarity) : 'border-gray-700 opacity-40'}`}
                    whileHover={{ scale: 1.05, backgroundColor: 'rgba(56, 229, 77, 0.05)' }}
                  >
                    <div className={`text-4xl mb-2 ${isUnlocked ? 'terminal-glow' : ''}`}>
                      {getIcon(ach.icon)}
                    </div>
                    <p className="text-xs font-mono uppercase truncate">{ach.name}</p>
                  </motion.div>
                </TooltipTrigger>
                <TooltipContent className="cyber-tooltip">
                  <p className="font-bold font-mono text-green-400">{ach.name} ({ach.rarity})</p>
                  <p className="text-sm text-green-400/80">{ach.description}</p>
                  {!isUnlocked && <p className="text-xs text-red-400/80 font-mono mt-1">LOCKED</p>}
                </TooltipContent>
              </Tooltip>
            );
          })}
        </TooltipProvider>
      </div>
    </div>
  );
};


const ProfilePage = ({ setIsLoading, profileId }) => {
  const { profile: ownProfile } = useAuth();
  const { toast } = useToast();
  const { achievements, unlockedAchievements } = useContext(AchievementsContext);
  const [isCopied, setIsCopied] = useState(false);
  const [viewedProfile, setViewedProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProfile = async () => {
      setLoading(true);
      let profileData = null;
      if (profileId) {
        const { data, error } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', profileId)
          .single();
        if (error) {
          toast({ variant: 'destructive', title: 'Error', description: 'Could not fetch profile.' });
        } else {
          profileData = data;
        }
      } else {
        profileData = ownProfile;
      }
      setViewedProfile(profileData);
      setLoading(false);
      if (setIsLoading) setIsLoading(false);
    };

    fetchProfile();
  }, [profileId, ownProfile, toast, setIsLoading]);

  const user = useMemo(() => {
    if (!viewedProfile) return null;
    const joinDate = viewedProfile?.created_at ? new Date(viewedProfile.created_at).toISOString().split('T')[0] : '2023-01-15';
    
    return {
      id: viewedProfile.id,
      name: viewedProfile.username || 'AGENT',
      displayName: viewedProfile.username || 'Agent',
      email: viewedProfile?.email || 'agent@aethex.biz',
      passportId: viewedProfile.aethex_passport_id || 'N/A',
      role: viewedProfile.role || 'Member',
      avatar: viewedProfile.username?.substring(0, 2).toUpperCase() || 'AG',
      joinDate,
      lastActive: 'Now',
      bio: viewedProfile.bio || 'A mysterious agent of GameForge, operating in the shadows of cyberspace.',
      skills: viewedProfile.skills || ['Stealth', 'Hacking', 'Data Analysis'],
      projects: ['Project Chimera', 'Operation Ghost', 'Neural Grid'],
    };
  }, [viewedProfile]);

  const handleCopy = () => {
    if (user?.passportId) {
      navigator.clipboard.writeText(user.passportId);
      setIsCopied(true);
      toast({
        title: '> PASSPORT ID COPIED',
        description: 'Your AeThex Passport ID is now in your clipboard.',
      });
      setTimeout(() => setIsCopied(false), 2000);
    }
  };

  if (loading) {
    return <div className="flex justify-center items-center h-full"><Loader2 className="w-16 h-16 text-green-400 animate-spin" /></div>;
  }

  if (!user) {
    return <div>Error loading profile.</div>;
  }

  const isOwnProfile = user.id === ownProfile.id;

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-3xl font-bold terminal-glow tracking-wider uppercase">
            &gt; USER_PROFILE
          </h1>
          <p className="text-green-400/70 font-mono mt-2">
            Viewing personal information and activity for {user.name}
          </p>
        </div>
        {isOwnProfile && <Button className="cyber-button">EDIT_PROFILE</Button>}
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="lg:col-span-1 space-y-6"
        >
          <div className="cyber-card p-6 rounded-lg text-center">
            <div className="relative w-32 h-32 mx-auto mb-4">
              <div className="w-full h-full cyber-border rounded-full bg-green-400/20 flex items-center justify-center">
                <span className="text-5xl font-bold text-green-400 font-mono">{user.avatar}</span>
              </div>
              <div className="absolute -bottom-1 -right-1 w-8 h-8 bg-green-400 rounded-full border-4 border-black flex items-center justify-center pulse-green">
                <Shield className="w-4 h-4 text-black" />
              </div>
            </div>
            <h2 className="text-2xl font-bold text-green-400 font-mono uppercase">{user.displayName}</h2>
            <p className="text-green-400/70 font-mono">@{user.name}</p>
            <p className="text-sm text-cyan-400 font-mono mt-2">{user.role}</p>
          </div>

          <AeThexPassport user={user} isCopied={isCopied} handleCopy={handleCopy} />

          <div className="cyber-card p-6 rounded-lg">
            <h3 className="text-lg font-bold text-green-400 font-mono uppercase mb-4">&gt; CONTACT_INFO</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3"><Mail className="w-4 h-4 text-green-400/70" /><span className="text-sm text-green-400 font-mono">{user.email}</span></div>
              <div className="flex items-center space-x-3"><Calendar className="w-4 h-4 text-green-400/70" /><span className="text-sm text-green-400 font-mono">Joined: {user.joinDate}</span></div>
              <div className="flex items-center space-x-3"><Clock className="w-4 h-4 text-green-400/70" /><span className="text-sm text-green-400 font-mono">Last Active: {user.lastActive}</span></div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="lg:col-span-2 space-y-6"
        >
          <div className="cyber-card p-6 rounded-lg">
            <h3 className="text-lg font-bold text-green-400 font-mono uppercase mb-4">&gt; BIO</h3>
            <p className="text-sm text-green-400/80 font-mono leading-relaxed">{user.bio}</p>
          </div>

          <div className="cyber-card p-6 rounded-lg">
            <h3 className="text-lg font-bold text-green-400 font-mono uppercase mb-4">&gt; SKILLS</h3>
            <div className="flex flex-wrap gap-2">
              {user.skills.map((skill, index) => (
                <span key={index} className="text-xs font-mono px-3 py-1 rounded cyber-border text-purple-400 border-purple-400/30 flex items-center space-x-2">
                  <Code className="w-3 h-3" />
                  <span>{skill}</span>
                </span>
              ))}
            </div>
          </div>
          
           <AchievementsDisplay achievements={achievements} unlockedAchievements={unlockedAchievements} />

          <div className="cyber-card p-6 rounded-lg">
            <h3 className="text-lg font-bold text-green-400 font-mono uppercase mb-4">&gt; ACTIVE_PROJECTS</h3>
            <div className="flex flex-wrap gap-2">
              {user.projects.map((project, index) => (
                <span key={index} className="text-xs font-mono px-3 py-1 rounded cyber-border text-cyan-400 border-cyan-400/30 flex items-center space-x-2">
                  <Gamepad2 className="w-3 h-3" />
                  <span>{project}</span>
                </span>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default ProfilePage;