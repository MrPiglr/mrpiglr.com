import React from 'react';
import { motion } from 'framer-motion';
import { Eye, Download, Copy, MoreVertical } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { getFileIcon, formatBytes, getTypeColor } from '@/components/assets/assetUtils';

const AssetCard = ({ asset, index, handleAction }) => (
  <motion.div
    key={asset.id}
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.6, delay: index * 0.1 }}
    className="cyber-card p-4 rounded-lg hover:bg-green-400/5 transition-colors group"
  >
    <div className="flex items-center justify-between mb-3">
      <div className="flex items-center space-x-3">
        <div className="w-12 h-12 cyber-border rounded bg-black/50 flex items-center justify-center">
          {getFileIcon(asset.file_type)}
        </div>
        <div>
          <h3 className="text-sm font-bold text-green-400 font-mono truncate">
            {asset.name}
          </h3>
          <p className="text-xs text-green-400/70 font-mono">{formatBytes(asset.size)}</p>
        </div>
      </div>
      <Button
        onClick={() => handleAction('Asset Options', asset.name)}
        className="cyber-button p-2 opacity-0 group-hover:opacity-100 transition-opacity"
        variant="ghost"
      >
        <MoreVertical className="w-4 h-4" />
      </Button>
    </div>
    <div className="space-y-2 mb-4">
      <div className="flex justify-between">
        <span className="text-xs text-green-400/70 font-mono">Project:</span>
        <span className="text-xs text-green-400 font-mono">{asset.project_title || 'N/A'}</span>
      </div>
      <div className="flex justify-between">
        <span className="text-xs text-green-400/70 font-mono">Version:</span>
        <span className="text-xs text-green-400 font-mono">v{asset.version}</span>
      </div>
      <div className="flex justify-between">
        <span className="text-xs text-green-400/70 font-mono">Modified:</span>
        <span className="text-xs text-green-400 font-mono">{new Date(asset.created_at).toLocaleDateString()}</span>
      </div>
    </div>
    <div className="flex flex-wrap gap-1 mb-4">
      {(asset.tags || []).map((tag, tagIndex) => (
        <span
          key={tagIndex}
          className={`text-xs font-mono px-2 py-1 rounded cyber-border ${getTypeColor(asset.file_type)}`}
        >
          {tag}
        </span>
      ))}
    </div>
    <div className="flex space-x-2">
      <Button
        onClick={() => handleAction('Preview Asset', asset.name)}
        className="cyber-button flex-1"
        size="sm"
      >
        <Eye className="w-4 h-4 mr-1" />
        VIEW
      </Button>
      <Button
        onClick={() => handleAction('Download Asset', asset.name)}
        className="cyber-button"
        variant="outline"
        size="sm"
      >
        <Download className="w-4 h-4" />
      </Button>
      <Button
        onClick={() => handleAction('Copy Asset', asset.name)}
        className="cyber-button"
        variant="outline"
        size="sm"
      >
        <Copy className="w-4 h-4" />
      </Button>
    </div>
  </motion.div>
);

export default AssetCard;