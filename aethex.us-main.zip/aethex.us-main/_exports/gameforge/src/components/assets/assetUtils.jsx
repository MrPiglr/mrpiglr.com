import React from 'react';
import { File, Image, Music, Video, Archive } from 'lucide-react';

export const getFileIcon = (type) => {
  if (!type) return <File className="w-6 h-6 text-gray-400" />;
  if (type.startsWith('image')) return <Image className="w-6 h-6 text-blue-400" />;
  if (type.startsWith('audio')) return <Music className="w-6 h-6 text-purple-400" />;
  if (type.startsWith('video')) return <Video className="w-6 h-6 text-red-400" />;
  if (type.includes('zip') || type.includes('archive')) return <Archive className="w-6 h-6 text-green-400" />;
  return <File className="w-6 h-6 text-gray-400" />;
};

export const getTypeColor = (type) => {
  if (!type) return 'text-gray-400 border-gray-400/30';
  if (type.startsWith('image')) return 'text-blue-400 border-blue-400/30';
  if (type.startsWith('audio')) return 'text-purple-400 border-purple-400/30';
  if (type.startsWith('video')) return 'text-red-400 border-red-400/30';
  if (type.includes('zip') || type.includes('archive')) return 'text-green-400 border-green-400/30';
  return 'text-gray-400 border-gray-400/30';
};

export const formatBytes = (bytes, decimals = 2) => {
  if (!bytes || bytes === 0) return '0 Bytes';
  const k = 1024;
  const dm = decimals < 0 ? 0 : decimals;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
};