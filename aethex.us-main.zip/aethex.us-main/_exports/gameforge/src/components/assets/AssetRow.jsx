import React from 'react';
import { motion } from 'framer-motion';
import { Eye, Download, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { getFileIcon, formatBytes, getTypeColor } from '@/components/assets/assetUtils';

const AssetRow = ({ asset, index, handleAction }) => (
  <motion.div
    key={asset.id}
    initial={{ opacity: 0, x: -20 }}
    animate={{ opacity: 1, x: 0 }}
    transition={{ duration: 0.4, delay: index * 0.05 }}
    className="p-4 hover:bg-green-400/5 transition-colors"
  >
    <div className="grid grid-cols-6 gap-4 items-center">
      <div className="flex items-center space-x-3">
        {getFileIcon(asset.file_type)}
        <span className="text-sm text-green-400 font-mono truncate">{asset.name}</span>
      </div>
      <span className={`text-sm font-mono uppercase ${getTypeColor(asset.file_type).split(' ')[0]}`}>
        {asset.file_type || 'unknown'}
      </span>
      <span className="text-sm text-green-400/70 font-mono">{formatBytes(asset.size)}</span>
      <span className="text-sm text-green-400/70 font-mono">{asset.project_title || 'N/A'}</span>
      <span className="text-sm text-green-400/70 font-mono">{new Date(asset.created_at).toLocaleDateString()}</span>
      <div className="flex space-x-1">
        <Button
          onClick={() => handleAction('Preview Asset', asset.name)}
          className="cyber-button p-1"
          size="sm"
        >
          <Eye className="w-3 h-3" />
        </Button>
        <Button
          onClick={() => handleAction('Download Asset', asset.name)}
          className="cyber-button p-1"
          variant="outline"
          size="sm"
        >
          <Download className="w-3 h-3" />
        </Button>
        <Button
          onClick={() => handleAction('Delete Asset', asset.name)}
          className="cyber-button p-1"
          variant="outline"
          size="sm"
        >
          <Trash2 className="w-3 h-3" />
        </Button>
      </div>
    </div>
  </motion.div>
);

export default AssetRow;