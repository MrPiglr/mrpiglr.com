import React from 'react';
import { motion } from 'framer-motion';
import { Loader2, FileText, Users, Database, GitBranch, ArrowRight, Upload, UserPlus, FolderPlus } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import useDataFetching from '@/hooks/useDataFetching.js';
import { supabase } from '@/lib/customSupabaseClient';

const fetchDashboardData = async (user) => {
  if (!user) return null;

  const { data: projectIdsData, error: projectIdsError } = await supabase
    .from('project_team_members')
    .select('project_id')
    .eq('user_id', user.id);

  if (projectIdsError) {
    console.error('Error fetching project IDs:', projectIdsError);
    throw projectIdsError;
  }

  const projectIds = projectIdsData.map(p => p.project_id);
  
  let projectsCount = 0;
  let teamMembersCount = 0;
  let assetsCount = 0;

  if (projectIds.length > 0) {
    const { count: pc, error: projectsError } = await supabase
      .from('projects')
      .select('id', { count: 'exact', head: true })
      .in('id', projectIds);
    if (projectsError) console.error('Error fetching projects count:', projectsError);
    projectsCount = pc || 0;

    const { data: teamData, error: teamMembersError } = await supabase
      .from('project_team_members')
      .select('user_id', { count: 'exact' })
      .in('project_id', projectIds);
    if (teamMembersError) console.error('Error fetching team members count:', teamMembersError);
    teamMembersCount = teamData?.length || 0;

    const { count: ac, error: assetsError } = await supabase
      .from('assets')
      .select('id', { count: 'exact', head: true })
      .in('project_id', projectIds);
    if (assetsError) console.error('Error fetching assets count:', assetsError);
    assetsCount = ac || 0;
  }

  return {
    projectsCount,
    teamMembersCount,
    assetsCount,
  };
};

const StatCard = ({ icon, label, value, color }) => (
  <motion.div
    className="cyber-border-bottom p-4 flex items-center space-x-4 bg-black/50"
    whileHover={{ scale: 1.05, boxShadow: `0 0 15px ${color}` }}
  >
    <div className={`p-3 rounded-full cyber-border`} style={{ borderColor: color, color: color }}>
      {icon}
    </div>
    <div>
      <p className="text-sm text-green-400/70 uppercase tracking-wider">{label}</p>
      <p className="text-2xl font-bold terminal-glow">{value}</p>
    </div>
  </motion.div>
);

const ActionButton = ({ icon, label, onClick }) => (
  <Button
    variant="ghost"
    className="w-full justify-start space-x-3 text-lg cyber-button"
    onClick={onClick}
  >
    {icon}
    <span>{label}</span>
    <ArrowRight className="ml-auto w-5 h-5" />
  </Button>
);

const Dashboard = ({ onOpenCreateProject, onOpenUploadAssets, onOpenInviteTeam }) => {
  const { profile } = useAuth();
  const { data, loading, error } = useDataFetching(fetchDashboardData, false, []);
  
  if (loading) {
    return (
      <div className="flex items-center justify-center w-full h-full">
        <Loader2 className="w-16 h-16 text-green-400 animate-spin" />
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="flex items-center justify-center w-full h-full text-red-500">
        Error loading dashboard data. Please try again later.
      </div>
    );
  }

  const quickActions = [
    { icon: <FolderPlus className="w-6 h-6" />, label: "Create New Project", onClick: onOpenCreateProject },
    { icon: <Upload className="w-6 h-6" />, label: "Upload Assets", onClick: onOpenUploadAssets },
    { icon: <UserPlus className="w-6 h-6" />, label: "Invite Team Member", onClick: onOpenInviteTeam },
  ];

  return (
    <div className="w-full">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <h1 className="text-4xl font-bold terminal-glow mb-2">Welcome back, {profile?.username}.</h1>
        <p className="text-lg text-green-400/80 mb-8">System status: All modules operational. Ready for deployment.</p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard icon={<FileText />} label="Projects" value={data?.projectsCount || 0} color="#00ffff" />
        <StatCard icon={<Users />} label="Team Members" value={data?.teamMembersCount || 0} color="#ff00ff" />
        <StatCard icon={<Database />} label="Total Assets" value={data?.assetsCount || 0} color="#ffff00" />
        <StatCard icon={<GitBranch />} label="Active Branches" value="0" color="#ff4500" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <motion.div 
          className="lg:col-span-2 cyber-border bg-black/50 p-6"
          initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: 0.2 }}
        >
          <h2 className="text-2xl font-bold terminal-glow mb-4">Recent Activity</h2>
          {/* Placeholder for recent activity feed */}
          <div className="text-center py-10 text-green-400/60">
            <p>//TODO: Activity Feed Implementation</p>
            <p>Awaiting data stream from neural link...</p>
          </div>
        </motion.div>
        
        <motion.div 
          className="cyber-border bg-black/50 p-6"
          initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: 0.4 }}
        >
          <h2 className="text-2xl font-bold terminal-glow mb-4">Quick Actions</h2>
          <div className="space-y-4">
            {quickActions.map(action => <ActionButton key={action.label} {...action} />)}
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Dashboard;