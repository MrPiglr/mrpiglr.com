import React from 'react';
import { motion } from 'framer-motion';
import { 
  MoreVertical,
  Folder,
  GitBranch,
  Users,
  Clock,
  Code,
  Trash2,
  Edit
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const getStatusColor = (status) => {
  switch (status) {
    case 'active': return 'text-green-400 border-green-400/30';
    case 'paused': return 'text-yellow-400 border-yellow-400/30';
    case 'planning': return 'text-blue-400 border-blue-400/30';
    default: return 'text-gray-400 border-gray-400/30';
  }
};

const getPriorityColor = (priority) => {
  switch (priority) {
    case 'high': return 'text-red-400 border-red-400/30';
    case 'medium': return 'text-yellow-400 border-yellow-400/30';
    case 'low': return 'text-green-400 border-green-400/30';
    default: return 'text-gray-400 border-gray-400/30';
  }
};

const ProjectCard = ({ project, index, onEdit, onDelete, onViewProject, onViewRepo, onViewTeam }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="cyber-card p-6 rounded-lg hover:bg-green-400/5 transition-colors group"
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center space-x-3 mb-2">
            <h3 className="text-lg font-bold text-green-400 font-mono uppercase">
              {project.title}
            </h3>
            <span className={`text-xs font-mono uppercase px-2 py-1 rounded cyber-border ${getStatusColor(project.status)}`}>
              {project.status}
            </span>
            <span className={`text-xs font-mono uppercase px-2 py-1 rounded cyber-border ${getPriorityColor(project.priority)}`}>
              {project.priority || 'medium'}
            </span>
          </div>
          <p className="text-sm text-green-400/70 font-mono mb-3">
            {project.description}
          </p>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button className="cyber-button p-2" variant="ghost">
              <MoreVertical className="w-4 h-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-48">
            <DropdownMenuItem onClick={() => onEdit(project)}>
              <Edit className="mr-2 h-4 w-4" />
              <span>Edit</span>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onDelete(project.id)} className="text-red-400 focus:text-red-400">
              <Trash2 className="mr-2 h-4 w-4" />
              <span>Delete</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="mb-4">
        <div className="flex justify-between items-center mb-2">
          <span className="text-xs text-green-400/70 font-mono uppercase">Progress</span>
          <span className="text-xs text-green-400 font-mono">{project.progress || 0}%</span>
        </div>
        <div className="w-full bg-green-900/30 rounded-full h-2">
          <motion.div 
            className="bg-green-400 h-2 rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${project.progress || 0}%` }}
            transition={{ duration: 1, delay: index * 0.1 }}
          ></motion.div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-4">
        <div className="flex items-center space-x-2"><Users className="w-4 h-4 text-green-400/70" /><span className="text-sm text-green-400/70 font-mono">Team:</span><span className="text-sm text-green-400 font-mono">{project.team}</span></div>
        <div className="flex items-center space-x-2"><Code className="w-4 h-4 text-green-400/70" /><span className="text-sm text-green-400/70 font-mono">Engine:</span><span className="text-sm text-green-400 font-mono">{project.engine || 'N/A'}</span></div>
        <div className="flex items-center space-x-2"><Clock className="w-4 h-4 text-green-400/70" /><span className="text-sm text-green-400/70 font-mono">Updated:</span><span className="text-sm text-green-400/70 font-mono">{project.lastUpdate}</span></div>
        <div className="flex items-center space-x-2"><GitBranch className="w-4 h-4 text-green-400/70" /><span className="text-sm text-green-400/70 font-mono">Branches:</span><span className="text-sm text-green-400 font-mono">3</span></div>
      </div>

      <div className="flex space-x-2">
        <Button onClick={() => onViewProject(project)} className="cyber-button flex-1" size="sm"><Folder className="w-4 h-4 mr-2" />OPEN</Button>
        <Button onClick={() => onViewRepo(project)} className="cyber-button flex-1" variant="outline" size="sm"><GitBranch className="w-4 h-4 mr-2" />REPO</Button>
        <Button onClick={() => onViewTeam(project)} className="cyber-button flex-1" variant="outline" size="sm"><Users className="w-4 h-4 mr-2" />TEAM</Button>
      </div>
    </motion.div>
  );
};

export default ProjectCard;