import React from 'react';
import { motion } from 'framer-motion';
import { Search, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const ProjectFilters = ({ searchTerm, setSearchTerm, filterStatus, setFilterStatus }) => {
  const { toast } = useToast();

  const handleAction = (action) => {
    toast({
      title: `> PROJECT ACTION: ${action.toUpperCase()}`,
      description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.1 }}
      className="cyber-card p-4 rounded-lg"
    >
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-green-400/50" />
          <input
            type="text"
            placeholder="SEARCH_PROJECTS..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-black/50 cyber-border rounded px-10 py-2 text-green-400 font-mono placeholder-green-400/50 focus:outline-none focus:ring-2 focus:ring-green-400/50"
          />
        </div>
        <div className="flex space-x-2">
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono focus:outline-none focus:ring-2 focus:ring-green-400/50"
          >
            <option value="all">ALL_STATUS</option>
            <option value="active">ACTIVE</option>
            <option value="paused">PAUSED</option>
            <option value="planning">PLANNING</option>
          </select>
          <Button 
            onClick={() => handleAction('Advanced Filters')}
            className="cyber-button"
            variant="outline"
          >
            <Filter className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </motion.div>
  );
};

export default ProjectFilters;