import React from 'react';
import { motion } from 'framer-motion';
import { Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';

const ProjectHeader = ({ onNewProject }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="flex items-center justify-between"
    >
      <div>
        <h1 className="text-3xl font-bold terminal-glow tracking-wider uppercase">
          &gt; PROJECT_MANAGER
        </h1>
        <p className="text-green-400/70 font-mono mt-2">
          Manage game development projects with version control and team collaboration
        </p>
      </div>
      <Button 
        onClick={onNewProject}
        className="cyber-button"
      >
        <Plus className="w-4 h-4 mr-2" />
        NEW_PROJECT
      </Button>
    </motion.div>
  );
};

export default ProjectHeader;