import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Plus, Loader2, Folder } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useActivity } from '@/hooks/useActivity.jsx';
import ConfirmationModal from '@/components/modals/ConfirmationModal';
import CreateProjectModal from '@/components/modals/CreateProjectModal';
import ProjectDetailModal from '@/components/modals/ProjectDetailModal';
import ProjectTeamModal from '@/components/modals/ProjectTeamModal';
import { supabase } from '@/lib/customSupabaseClient';
import useDataFetching from '@/hooks/useDataFetching';
import { useAuth } from '@/context/AuthContext';
import ProjectHeader from '@/components/projects/ProjectHeader';
import ProjectFilters from '@/components/projects/ProjectFilters';
import ProjectCard from '@/components/projects/ProjectCard';

const fetchProjectsFunction = async (user) => {
  const { data, error } = await supabase
    .from('projects')
    .select(`
      *,
      project_team_members!inner(user_id)
    `)
    .eq('project_team_members.user_id', user.id);
    
  if (error) throw error;
  
  const projectsWithCounts = await Promise.all(data.map(async (project) => {
    const { count, error: countError } = await supabase
      .from('project_team_members')
      .select('user_id', { count: 'exact', head: true })
      .eq('project_id', project.id);
    
    if (countError) {
      console.error('Error fetching team count for project', project.id, countError);
      return { ...project, team: 1, lastUpdate: new Date(project.updated_at).toLocaleString() };
    }
    
    return { ...project, team: count || 1, lastUpdate: new Date(project.updated_at).toLocaleString() };
  }));

  return projectsWithCounts;
};

const ProjectManager = () => {
  const { toast } = useToast();
  const { addActivity } = useActivity();
  const { user } = useAuth();
  const { data: projects, loading, refetch } = useDataFetching(
    fetchProjectsFunction, 
    false, 
    []
  );

  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');

  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [isConfirmModalOpen, setConfirmModalOpen] = useState(false);
  const [editingProject, setEditingProject] = useState(null);
  const [deletingProjectId, setDeletingProjectId] = useState(null);
  
  const [selectedProject, setSelectedProject] = useState(null);
  const [isDetailModalOpen, setDetailModalOpen] = useState(false);
  const [isTeamModalOpen, setTeamModalOpen] = useState(false);

  useEffect(() => {
    const channel = supabase.channel('public:projects')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'projects' }, () => refetch())
      .subscribe();
    
    const teamChannel = supabase.channel('public:project_team_members')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'project_team_members' }, () => refetch())
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
      supabase.removeChannel(teamChannel);
    };
  }, [refetch]);

  const handleCreateOrUpdateProject = async (projectData) => {
    if (!user) {
      toast({ variant: 'destructive', title: 'Authentication Error', description: 'User not found.' });
      return;
    }
    try {
      if (editingProject) {
        const { data, error } = await supabase
          .from('projects')
          .update({ ...projectData, updated_at: new Date() })
          .eq('id', editingProject.id)
          .select()
          .single();
        if (error) throw error;
        addActivity({ type: 'project', message: `Updated project: ${data.title}` });
        toast({ title: '> PROJECT UPDATED', description: `Project ${data.title} details have been saved.` });
      } else {
        const { data, error } = await supabase
          .from('projects')
          .insert({ ...projectData, owner_id: user.id, user_id: user.id })
          .select()
          .single();
        if (error) throw error;
        
        await supabase.from('project_team_members').insert({ project_id: data.id, user_id: user.id, role: 'owner' });

        addActivity({ type: 'project', message: `Created new project: ${data.title}` });
        toast({ title: '> PROJECT CREATED', description: `New project ${data.title} has been initialized.` });
      }
      refetch();
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error saving project', description: error.message });
    }
    setEditingProject(null);
    setCreateModalOpen(false);
  };
  
  const handleEdit = (project) => {
    setEditingProject(project);
    setCreateModalOpen(true);
  };

  const openDeleteConfirm = (projectId) => {
    setDeletingProjectId(projectId);
    setConfirmModalOpen(true);
  };
  
  const confirmDelete = async () => {
    const projectToDelete = projects.find(p => p.id === deletingProjectId);
    try {
      await supabase.from('project_team_members').delete().eq('project_id', deletingProjectId);
      const { error } = await supabase.from('projects').delete().eq('id', deletingProjectId);
      if (error) throw error;
      addActivity({ type: 'project', message: `Deleted project: ${projectToDelete.title}` });
      toast({ title: '> PROJECT DELETED', description: `Project ${projectToDelete.title} has been deleted.`, variant: 'destructive' });
      refetch();
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error deleting project', description: error.message });
    }
    setConfirmModalOpen(false);
    setDeletingProjectId(null);
  };

  const handleViewProject = (project) => {
    setSelectedProject(project);
    setDetailModalOpen(true);
    addActivity({ type: 'project', message: `Viewed project details: ${project.title}` });
  };

  const handleViewRepo = (project) => {
    addActivity({ type: 'project', message: `Viewed repository for: ${project.title}` });
    if (project.github_url) {
      window.open(project.github_url, '_blank', 'noopener,noreferrer');
    } else {
      toast({
        variant: 'destructive',
        title: 'Repository Not Found',
        description: 'No GitHub repository URL is linked to this project.',
      });
    }
  };

  const handleViewTeam = (project) => {
    setSelectedProject(project);
    setTeamModalOpen(true);
    addActivity({ type: 'project', message: `Viewed team for: ${project.title}` });
  };

  const filteredProjects = useMemo(() => (projects || []).filter(project => {
    const matchesSearch = project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (project.description && project.description.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesFilter = filterStatus === 'all' || project.status === filterStatus;
    return matchesSearch && matchesFilter;
  }), [projects, searchTerm, filterStatus]);

  return (
    <>
      <div className="space-y-6 cyber-card p-6 rounded-lg">
        <ProjectHeader onNewProject={() => { setEditingProject(null); setCreateModalOpen(true); }} />
        <ProjectFilters 
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          filterStatus={filterStatus}
          setFilterStatus={setFilterStatus}
        />

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="w-16 h-16 text-green-400 animate-spin" />
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {filteredProjects.map((project, index) => (
                <ProjectCard
                  key={project.id}
                  project={project}
                  index={index}
                  onEdit={handleEdit}
                  onDelete={openDeleteConfirm}
                  onViewProject={handleViewProject}
                  onViewRepo={handleViewRepo}
                  onViewTeam={handleViewTeam}
                />
              ))}
            </div>

            {filteredProjects.length === 0 && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.6 }}
                className="cyber-card p-12 rounded-lg text-center"
              >
                <Folder className="w-16 h-16 text-green-400/50 mx-auto mb-4" />
                <h3 className="text-lg font-bold text-green-400 font-mono uppercase mb-2">NO_PROJECTS_FOUND</h3>
                <p className="text-green-400/70 font-mono mb-6">No projects match your current search criteria</p>
                <Button onClick={() => { setEditingProject(null); setCreateModalOpen(true); }} className="cyber-button"><Plus className="w-4 h-4 mr-2" />CREATE_PROJECT</Button>
              </motion.div>
            )}
          </>
        )}
      </div>
      <CreateProjectModal
        isOpen={isCreateModalOpen}
        onClose={() => { setCreateModalOpen(false); setEditingProject(null); }}
        onSave={handleCreateOrUpdateProject}
        project={editingProject}
      />
      <ConfirmationModal
        isOpen={isConfirmModalOpen}
        onClose={() => setConfirmModalOpen(false)}
        onConfirm={confirmDelete}
        title="> CONFIRM_DELETION"
      >
        <p className="text-green-400/80 font-mono text-center">Are you sure you want to delete this project?</p>
        <p className="text-yellow-400/80 font-mono text-sm text-center mt-2">This action cannot be undone.</p>
      </ConfirmationModal>
      <ProjectDetailModal 
        isOpen={isDetailModalOpen}
        onClose={() => setDetailModalOpen(false)}
        project={selectedProject}
      />
      <ProjectTeamModal
        isOpen={isTeamModalOpen}
        onClose={() => setTeamModalOpen(false)}
        project={selectedProject}
      />
    </>
  );
};

export default ProjectManager;