import React from 'react';
import { motion } from 'framer-motion';
import { Wrench, Code } from 'lucide-react';

const MaintenancePage = ({ message }) => {
  return (
    <div className="min-h-screen bg-black text-green-400 font-mono flex flex-col items-center justify-center p-4 relative overflow-hidden">
      <div className="fixed inset-0 grid-pattern opacity-20 pointer-events-none z-0"></div>
      <div className="scan-line fixed top-0 left-0 w-full h-1 z-20"></div>
      
      <motion.div
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="relative z-10 flex flex-col items-center text-center"
      >
        <div className="w-24 h-24 cyber-border rounded-full bg-green-400/10 flex items-center justify-center mb-8 pulse-green">
          <Wrench className="w-12 h-12 text-green-400" />
        </div>
        
        <h1 className="text-4xl md:text-5xl font-bold terminal-glow tracking-wider uppercase mb-4">
          &gt; SYSTEM_MAINTENANCE
        </h1>
        
        <p className="text-lg text-green-400/80 max-w-2xl mb-8 font-mono">
          {message || "Our systems are currently undergoing scheduled maintenance to improve performance and security. We'll be back online shortly."}
        </p>

        <div className="flex items-center space-x-3 mb-8">
          <div className="w-10 h-10 cyber-border rounded bg-green-400/20 flex items-center justify-center">
            <Code className="w-6 h-6 text-green-400" />
          </div>
          <div>
            <h2 className="text-xl font-bold terminal-glow tracking-wider">GAMEFORGE</h2>
            <p className="text-xs text-green-400/70 uppercase tracking-widest">Neural Dev Toolkit</p>
          </div>
        </div>

        <p className="text-xs text-green-400/60 font-mono">
          &copy; {new Date().getFullYear()} GameForge by AETHEX.BIZ
        </p>
      </motion.div>
    </div>
  );
};

export default MaintenancePage;