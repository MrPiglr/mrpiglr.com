import React, { useState, useMemo, useContext } from 'react';
import { motion } from 'framer-motion';
import { 
  UserPlus, 
  Search, 
  Filter, 
  MoreVertical,
  Mail,
  Clock,
  Shield,
  Star,
  Activity,
  Users,
  Crown,
  Code,
  Palette,
  Music,
  Gamepad2,
  Calendar,
  Loader2,
  Circle,
  Coffee,
  Moon,
  UserCog,
  Eye,
  Award,
  BarChart,
  Slash,
  Trash2,
  UserX
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useActivity } from '@/hooks/useActivity.jsx';
import { usePresence } from '@/context/PresenceContext';
import { useAuth } from '@/context/AuthContext';
import MessageUserModal from '@/components/modals/MessageUserModal';
import ManagePermissionsModal from '@/components/modals/admin/ManagePermissionsModal';
import ConfirmationModal from '@/components/modals/ConfirmationModal';
import InviteUserModal from '@/components/modals/InviteUserModal';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuGroup,
} from "@/components/ui/dropdown-menu";

const UsersManager = ({ onViewProfile }) => {
  const { toast } = useToast();
  const { addActivity } = useActivity();
  const { teamMembers: allUsers, onlineCount, loading } = usePresence();
  const { profile: currentUserProfile } = useAuth();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState('all');
  const [isMessageModalOpen, setMessageModalOpen] = useState(false);
  const [isPermissionsModalOpen, setPermissionsModalOpen] = useState(false);
  const [isInviteUserModalOpen, setInviteUserModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState(null);
  const [isConfirmModalOpen, setConfirmModalOpen] = useState(false);
  const [confirmModalContent, setConfirmModalContent] = useState({ title: '', onConfirm: () => {} });

  const isOwnerOrAdmin = currentUserProfile?.role === 'admin' || currentUserProfile?.role === 'owner';

  const handleMessageUser = (user) => {
    setSelectedUser(user);
    setMessageModalOpen(true);
    addActivity({ type: 'team', message: `Initiated message with ${user.username}` });
  };

  const handleViewProfile = (userId) => {
    onViewProfile(userId);
  };

  const handleManagePermissions = (user) => {
    if (isOwnerOrAdmin) {
      setSelectedUser(user);
      setPermissionsModalOpen(true);
      addActivity({ type: 'team', message: `Managing permissions for ${user.username}` });
    } else {
      toast({
        variant: 'destructive',
        title: 'ACCESS DENIED',
        description: 'You do not have permission to manage roles.',
      });
    }
  };
  
  const handleAdminAction = (action, user) => {
    addActivity({ type: 'admin', message: `${action} on user ${user.username}` });
    toast({
      title: `> ADMIN ACTION: ${action.toUpperCase()}`,
      description: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  const handleSuspendUser = (user) => {
    setConfirmModalContent({
        title: `> CONFIRM SUSPENSION`,
        onConfirm: () => {
            handleAdminAction('Suspend User', user);
            setConfirmModalOpen(false);
        },
        children: <p className="text-green-400/80 font-mono text-center">Are you sure you want to suspend {user.username}?</p>
    });
    setConfirmModalOpen(true);
  };

  const handleDeleteUser = (user) => {
    setConfirmModalContent({
        title: `> CONFIRM DELETION`,
        icon: <UserX className="w-12 h-12 text-red-400" />,
        onConfirm: () => {
            handleAdminAction('Delete User', user);
            setConfirmModalOpen(false);
        },
        children: (
            <>
                <p className="text-green-400/80 font-mono text-center">Are you sure you want to delete {user.username}?</p>
                <p className="text-yellow-400/80 font-mono text-sm text-center mt-2">This action is irreversible.</p>
            </>
        )
    });
    setConfirmModalOpen(true);
  };

  const getStatusInfo = (status) => {
    switch (status) {
      case 'online': return { color: 'bg-green-400', text: 'ONLINE', icon: <Circle className="w-4 h-4 text-green-400" /> };
      case 'away': return { color: 'bg-yellow-400', text: 'AWAY', icon: <Coffee className="w-4 h-4 text-yellow-400" /> };
      case 'busy': return { color: 'bg-red-400', text: 'BUSY', icon: <Moon className="w-4 h-4 text-red-400" /> };
      default: return { color: 'bg-gray-400', text: 'OFFLINE', icon: <Circle className="w-4 h-4 text-gray-400" /> };
    }
  };

  const getRoleIcon = (role) => {
    if (!role) return <Users className="w-4 h-4" />;
    if (role.toLowerCase().includes('developer')) return <Code className="w-4 h-4" />;
    if (role.toLowerCase().includes('artist')) return <Palette className="w-4 h-4" />;
    if (role.toLowerCase().includes('audio')) return <Music className="w-4 h-4" />;
    if (role.toLowerCase().includes('designer')) return <Gamepad2 className="w-4 h-4" />;
    return <Users className="w-4 h-4" />;
  };

  const getPermissionIcon = (permission) => {
    switch (permission) {
      case 'owner': return <Crown className="w-4 h-4 text-yellow-400" />;
      case 'oversee': return <Crown className="w-4 h-4 text-yellow-400" />;
      case 'admin': return <Shield className="w-4 h-4 text-blue-400" />;
      case 'editor': return <Star className="w-4 h-4 text-green-400" />;
      case 'member': return <Users className="w-4 h-4 text-gray-400" />;
      default: return <Users className="w-4 h-4 text-gray-400" />;
    }
  };

  const filteredUsers = useMemo(() => allUsers.filter(user => {
    const matchesSearch = user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         (user.role && user.role.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesFilter = filterRole === 'all' || (user.role && user.role.toLowerCase().includes(filterRole.toLowerCase()));
    return matchesSearch && matchesFilter;
  }), [allUsers, searchTerm, filterRole]);

  return (
    <>
    <div className="space-y-6 cyber-card p-6 rounded-lg">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-3xl font-bold terminal-glow tracking-wider uppercase">
            &gt; USERS
          </h1>
          <p className="text-green-400/70 font-mono mt-2">
            Browse all users on the platform.
          </p>
        </div>
        <Button 
          onClick={() => setInviteUserModalOpen(true)}
          className="cyber-button"
        >
          <UserPlus className="w-4 h-4 mr-2" />
          INVITE_USER
        </Button>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
        className="cyber-card p-4 rounded-lg"
      >
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-green-400/50" />
            <input
              type="text"
              placeholder="SEARCH_USERS..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-black/50 cyber-border rounded px-10 py-2 text-green-400 font-mono placeholder-green-400/50 focus:outline-none focus:ring-2 focus:ring-green-400/50"
            />
          </div>
          <div className="flex space-x-2">
            <select
              value={filterRole}
              onChange={(e) => setFilterRole(e.target.value)}
              className="bg-black/50 cyber-border rounded px-4 py-2 text-green-400 font-mono focus:outline-none focus:ring-2 focus:ring-green-400/50"
            >
              <option value="all">ALL_ROLES</option>
              <option value="owner">Owner</option>
              <option value="oversee">Oversee</option>
              <option value="admin">Admin</option>
              <option value="editor">Editor</option>
              <option value="member">Member</option>
            </select>
            <Button 
              onClick={() => handleAdminAction('Advanced Filters')}
              className="cyber-button"
              variant="outline"
            >
              <Filter className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="grid grid-cols-1 md:grid-cols-4 gap-4"
      >
        {[
          { label: 'Total Users', value: allUsers.length, color: 'text-green-400' },
          { label: 'Online Now', value: onlineCount, color: 'text-cyan-400' },
          { label: 'Avg Projects', value: '2.1', color: 'text-purple-400' },
          { label: 'New This Week', value: '12', color: 'text-yellow-400' }
        ].map((stat, index) => (
          <div key={index} className="cyber-card p-4 rounded-lg text-center">
            <p className={`text-2xl font-bold font-mono ${stat.color}`}>{stat.value}</p>
            <p className="text-xs text-green-400/70 font-mono uppercase tracking-wider">{stat.label}</p>
          </div>
        ))}
      </motion.div>

        {loading ? (
        <div className="flex justify-center items-center h-64">
          <Loader2 className="w-16 h-16 text-green-400 animate-spin" />
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {filteredUsers.map((user, index) => {
              const statusInfo = getStatusInfo(user.status);
              const isSelf = user.id === currentUserProfile.id;
              
              return (
              <motion.div
                key={user.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="cyber-card p-6 rounded-lg hover:bg-green-400/5 transition-colors group flex flex-col"
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-4">
                    <div className="relative">
                      <div className="w-12 h-12 cyber-border rounded-full bg-green-400/20 flex items-center justify-center">
                        <span className="text-lg font-bold text-green-400 font-mono">{user.avatar}</span>
                      </div>
                      <div className={`absolute -bottom-1 -right-1 w-4 h-4 ${statusInfo.color} rounded-full border-2 border-black`}></div>
                    </div>
                    <div>
                      <div className="flex items-center space-x-2 mb-1"><h3 className="text-lg font-bold text-green-400 font-mono uppercase">{user.username}</h3>{getPermissionIcon(user.role)}</div>
                      <div className="flex items-center space-x-2"><span className="text-sm text-green-400/70 font-mono capitalize">{user.role || 'Member'}</span></div>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button className="cyber-button p-2 opacity-0 group-hover:opacity-100 transition-opacity" variant="ghost">
                        <MoreVertical className="w-4 h-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      {(isOwnerOrAdmin && !isSelf) ? (
                        <>
                          <DropdownMenuLabel>Admin Actions</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => handleManagePermissions(user)}>
                            <UserCog className="mr-2 h-4 w-4" /> Manage Permissions
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleAdminAction('Add Loyalty Points', user)}>
                            <Award className="mr-2 h-4 w-4" /> Add Loyalty Points
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleAdminAction('View Activity Log', user)}>
                            <BarChart className="mr-2 h-4 w-4" /> View Activity
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-yellow-400 focus:text-yellow-300" onClick={() => handleSuspendUser(user)}>
                            <Slash className="mr-2 h-4 w-4" /> Suspend User
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-red-400 focus:text-red-300" onClick={() => handleDeleteUser(user)}>
                            <Trash2 className="mr-2 h-4 w-4" /> Delete User
                          </DropdownMenuItem>
                        </>
                      ) : (
                        <>
                          <DropdownMenuLabel>User Snapshot</DropdownMenuLabel>
                          <DropdownMenuSeparator />
                          <DropdownMenuGroup className="px-2 text-xs font-mono text-green-400/80 space-y-1">
                            <p>Loyalty: {user.loyalty_points || 0} pts</p>
                            <p>XP: {user.total_xp || 0}</p>
                            <p>Level: {user.level || 1}</p>
                          </DropdownMenuGroup>
                        </>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
                
                <div className="flex-grow space-y-3 mb-4">
                  <div className="flex items-center space-x-2"><Mail className="w-4 h-4 text-green-400/70" /><span className="text-sm text-green-400/70 font-mono">{user.email}</span></div>
                  <div className="flex items-center space-x-2"><Activity className="w-4 h-4 text-green-400/70" /><span className="text-sm text-green-400/70 font-mono">Status:</span><span className={`text-sm font-mono uppercase ${statusInfo.color.replace('bg-', 'text-')}`}>{statusInfo.text}</span></div>
                  <div className="flex items-center space-x-2"><Clock className="w-4 h-4 text-green-400/70" /><span className="text-sm text-green-400/70 font-mono">Last Active:</span><span className="text-sm text-green-400 font-mono">{new Date(user.last_seen).toLocaleString()}</span></div>
                </div>

                <div className="mt-auto flex space-x-2">
                  <Button onClick={() => handleMessageUser(user)} className="cyber-button flex-1" size="sm" disabled={isSelf}><Mail className="w-4 h-4 mr-2" />MESSAGE</Button>
                  <Button onClick={() => handleViewProfile(user.id)} className="cyber-button flex-1" variant="outline" size="sm"><Eye className="w-4 h-4 mr-2" />PROFILE</Button>
                </div>
              </motion.div>
            )})}
          </div>

          {filteredUsers.length === 0 && !loading && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.6 }} className="cyber-card p-12 rounded-lg text-center">
              <Users className="w-16 h-16 text-green-400/50 mx-auto mb-4" />
              <h3 className="text-lg font-bold text-green-400 font-mono uppercase mb-2">NO_USERS_FOUND</h3>
              <p className="text-green-400/70 font-mono mb-6">No users match your current search criteria</p>
              <Button onClick={() => setInviteUserModalOpen(true)} className="cyber-button"><UserPlus className="w-4 h-4 mr-2" />INVITE_USER</Button>
            </motion.div>
          )}
        </>
      )}
    </div>
    {selectedUser && (
      <>
        <MessageUserModal
          isOpen={isMessageModalOpen}
          onClose={() => setMessageModalOpen(false)}
          recipient={selectedUser}
        />
        <ManagePermissionsModal
          isOpen={isPermissionsModalOpen}
          onClose={() => setPermissionsModalOpen(false)}
          user={selectedUser}
        />
      </>
    )}
     <ConfirmationModal
        isOpen={isConfirmModalOpen}
        onClose={() => setConfirmModalOpen(false)}
        onConfirm={confirmModalContent.onConfirm}
        title={confirmModalContent.title}
        icon={confirmModalContent.icon}
      >
        {confirmModalContent.children}
      </ConfirmationModal>
      <InviteUserModal isOpen={isInviteUserModalOpen} onClose={() => setInviteUserModalOpen(false)} />
    </>
  );
};

export default UsersManager;