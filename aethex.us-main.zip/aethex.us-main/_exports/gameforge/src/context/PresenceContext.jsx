import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/components/ui/use-toast';

const PresenceContext = createContext(undefined);

export const PresenceProvider = ({ children }) => {
  const { user, profile } = useAuth();
  const { toast } = useToast();
  const channelRef = useRef(null);

  const [userStatus, setUserStatusState] = useState('online');
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [teamMembers, setTeamMembers] = useState([]);
  const [onlineCount, setOnlineCount] = useState(0);
  const [loading, setLoading] = useState(true);

  const fetchTeamMembers = useCallback(async () => {
    const { data, error } = await supabase.from('profiles').select('*');
    if (error) {
      console.error('Error fetching team members:', error);
      toast({ variant: 'destructive', title: 'Error', description: 'Could not fetch team members.' });
      return [];
    }
    return data;
  }, [toast]);

  const updateMemberStatuses = useCallback((allMembers, presences) => {
    const statusOrder = { online: 0, away: 1, busy: 2, offline: 3 };

    const membersWithStatus = allMembers.map(member => {
      const presenceArray = presences[member.id];
      const presence = presenceArray ? presenceArray[0] : null;
      const liveStatus = presence?.status || member.status || 'offline';
      return {
        ...member,
        status: liveStatus,
        last_seen: presence?.last_seen || member.updated_at,
        avatar: member.username.substring(0, 2).toUpperCase(),
        joinDate: new Date(member.created_at).toLocaleDateString(),
        permissions: member.role,
      };
    }).sort((a, b) => statusOrder[a.status] - statusOrder[b.status]);
    
    const currentOnlineCount = Object.values(presences).filter(p => p[0]?.status && p[0].status !== 'offline').length;
    
    setTeamMembers(membersWithStatus);
    setOnlineCount(currentOnlineCount);
  }, []);

  const setUserStatus = useCallback(async (status) => {
    if (channelRef.current && user && profile && isSubscribed) {
      setUserStatusState(status);
      await channelRef.current.track({
        status,
        user_id: user.id,
        username: profile.username,
        last_seen: new Date().toISOString(),
      });
      await supabase
        .from('profiles')
        .update({ status: status, updated_at: new Date().toISOString() })
        .eq('id', user.id);
    }
  }, [user, profile, isSubscribed]);

  useEffect(() => {
    if (!user || !profile) return;

    let initialMembers = [];

    const initialize = async () => {
      setLoading(true);
      initialMembers = await fetchTeamMembers();
      
      if (channelRef.current) {
        await channelRef.current.unsubscribe();
      }

      channelRef.current = supabase.channel('presence:global', {
        config: {
          presence: {
            key: user.id,
          },
        },
      });

      const handleSync = () => {
        if (channelRef.current) {
          const presences = channelRef.current.presenceState();
          updateMemberStatuses(initialMembers, presences);
        }
      };

      const handlePostgresChanges = async () => {
        initialMembers = await fetchTeamMembers();
        handleSync();
      };
      
      channelRef.current
        .on('presence', { event: 'sync' }, handleSync)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'profiles' }, handlePostgresChanges)
        .subscribe(async (status) => {
          if (status === 'SUBSCRIBED') {
            setIsSubscribed(true);
            const initialStatus = profile.status || 'online';
            setUserStatusState(initialStatus);
            await channelRef.current.track({
              status: initialStatus,
              user_id: user.id,
              username: profile.username,
              last_seen: new Date().toISOString(),
            });
            handleSync(); 
            setLoading(false);
          } else {
            setIsSubscribed(false);
          }
        });
    };

    initialize();

    return () => {
      if (channelRef.current) {
        channelRef.current.unsubscribe();
        channelRef.current = null;
      }
    };
  }, [user, profile, fetchTeamMembers, updateMemberStatuses]);

  const value = {
    isSubscribed,
    userStatus,
    setUserStatus,
    teamMembers,
    onlineCount,
    loading,
  };

  return (
    <PresenceContext.Provider value={value}>
      {children}
    </PresenceContext.Provider>
  );
};

export const usePresence = () => {
  const context = useContext(PresenceContext);
  if (context === undefined) {
    throw new Error('usePresence must be used within a PresenceProvider');
  }
  return context;
};