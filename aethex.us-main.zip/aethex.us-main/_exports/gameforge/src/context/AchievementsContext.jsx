import React, { createContext, useState, useEffect, useCallback, useContext } from 'react';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/customSupabaseClient';

export const AchievementsContext = createContext(null);

const initialAchievements = [
    { text_id: 'first_login', name: 'System Online', description: 'Log in for the first time.', rarity: 'Common', icon: 'Zap' },
    { text_id: 'first_project', name: 'Architect', description: 'Create your first project.', rarity: 'Common', icon: 'Trophy' },
    { text_id: 'first_asset', name: 'Collector', description: 'Upload your first asset.', rarity: 'Common', icon: 'Star' },
    { text_id: 'team_invite', name: 'Collaborator', description: 'Invite a team member.', rarity: 'Rare', icon: 'Trophy' },
    { text_id: 'admin_power', name: 'System Admin', description: 'Access the admin panel.', rarity: 'Epic', icon: 'Shield' },
    { text_id: 'night_owl', name: 'Night Owl', description: 'Log in between 2 AM and 5 AM.', rarity: 'Rare', icon: 'Star' },
    { text_id: 'dev_god', name: 'Dev God', description: 'Unlock all other achievements.', rarity: 'Legendary', icon: 'Trophy' },
];

export const AchievementsProvider = ({ children }) => {
  const { user, profile } = useAuth();
  const { toast } = useToast();
  const [unlockedAchievements, setUnlockedAchievements] = useState(new Set());
  const [allAchievements, setAllAchievements] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchAchievementsList = useCallback(async () => {
    try {
        const { data, error } = await supabase.from('achievements').select('id, name, description, rarity:name, icon');
        if (error) throw error;
        const achievementsWithTextId = data.map(dbAch => {
            const initialAch = initialAchievements.find(ia => ia.name === dbAch.name);
            return { ...dbAch, id: dbAch.id, text_id: initialAch?.text_id || dbAch.name.toLowerCase().replace(/\s+/g, '_') };
        });

        setAllAchievements(achievementsWithTextId);
    } catch (error) {
        console.error("Error fetching achievements list:", error);
    }
  }, []);

  const fetchUserAchievements = useCallback(async () => {
    if (!profile?.aethex_passport_id || allAchievements.length === 0) {
        setLoading(false);
        return;
    }
    setLoading(true);
    try {
        const { data, error } = await supabase
            .from('user_achievements')
            .select('achievement_id')
            .eq('user_id', profile.aethex_passport_id);

        if (error) throw error;
        
        const unlockedIds = new Set(data.map(ach => ach.achievement_id));
        setUnlockedAchievements(unlockedIds);

        const firstLoginAchievement = allAchievements.find(a => a.text_id === 'first_login');
        if (firstLoginAchievement && !unlockedIds.has(firstLoginAchievement.id)) {
            unlockAchievement('first_login', true);
        }

    } catch (error) {
        console.error("Error fetching user achievements:", error);
    } finally {
        setLoading(false);
    }
  }, [profile, allAchievements]);

  useEffect(() => {
    fetchAchievementsList();
  }, [fetchAchievementsList]);
  
  useEffect(() => {
    if (allAchievements.length > 0) {
      fetchUserAchievements();
    }
  }, [allAchievements, fetchUserAchievements]);

  useEffect(() => {
    if (!profile?.aethex_passport_id) return;

    const channel = supabase.channel(`public:user_achievements:user_id=eq.${profile.aethex_passport_id}`)
      .on('postgres_changes', { 
        event: 'INSERT', 
        schema: 'public', 
        table: 'user_achievements',
        filter: `user_id=eq.${profile.aethex_passport_id}`
      }, (payload) => {
        const newAchievementId = payload.new.achievement_id;
        setUnlockedAchievements(prev => {
            if (prev.has(newAchievementId)) return prev;
            const newSet = new Set(prev);
            newSet.add(newAchievementId);
            return newSet;
        });
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };

  }, [profile?.aethex_passport_id]);
  
  const unlockAchievement = useCallback(async (achievementTextId, silent = false) => {
    if (!profile?.aethex_passport_id || allAchievements.length === 0) return;

    const achievement = allAchievements.find(a => a.text_id === achievementTextId);
    if (!achievement || unlockedAchievements.has(achievement.id)) return;

    try {
        const { error } = await supabase
            .from('user_achievements')
            .insert({ user_id: profile.aethex_passport_id, achievement_id: achievement.id, site_id: 'gameforge' });

        if (error && error.code !== '23505') throw error;

        // The real-time subscription will handle adding the achievement to the state
        // But we can add it here for immediate feedback before the event arrives
        setUnlockedAchievements(prev => {
            if (prev.has(achievement.id)) return prev;
            const newUnlocked = new Set(prev);
            newUnlocked.add(achievement.id);
            
            if (!silent) {
                toast({
                  title: `> ACHIEVEMENT UNLOCKED: ${achievement.name}`,
                  description: achievement.description,
                });
            }
            
            const devGodAchievement = allAchievements.find(a => a.text_id === 'dev_god');
            const allButDevGod = allAchievements.filter(a => a.text_id !== 'dev_god');
            
            if (devGodAchievement) {
                 const allOtherUnlocked = allButDevGod.every(ach => newUnlocked.has(ach.id));
                 if (allOtherUnlocked && !newUnlocked.has(devGodAchievement.id)) {
                    setTimeout(() => unlockAchievement('dev_god'), 1000);
                 }
            }

            return newUnlocked;
        });

    } catch(error) {
        if (error.code !== '23505') { // 23505 is unique_violation, which we can ignore
          console.error("Failed to unlock achievement:", error);
        }
    }
  }, [profile, toast, unlockedAchievements, allAchievements]);

  const value = {
    achievements: allAchievements,
    unlockedAchievements,
    unlockAchievement,
    loading,
  };

  return (
    <AchievementsContext.Provider value={value}>
      {children}
    </AchievementsContext.Provider>
  );
};