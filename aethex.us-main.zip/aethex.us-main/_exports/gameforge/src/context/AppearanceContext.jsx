import React, { createContext, useState, useEffect } from 'react';

const initialSettings = {
  profile: { username: 'MRPIGLR', email: 'mrpiglr@aethex.biz', displayName: 'Mr. Piglr', bio: 'Lead Developer at GameForge - Neural Game Development Specialist', avatar: 'MP' },
  security: { twoFactorEnabled: true, sessionTimeout: 30, apiKeyVisible: false, apiKey: 'gf_live_sk_1234567890abcdef' },
  notifications: { emailNotifications: true, pushNotifications: true, commitNotifications: true, prNotifications: true, buildNotifications: false, teamNotifications: true },
  appearance: { theme: 'cyberpunk', fontSize: 'medium', animations: true, soundEffects: true, terminalMode: true },
  integrations: { githubConnected: false, discordConnected: true, slackConnected: false, webhooksEnabled: true },
  domains: [
    { id: 1, url: 'api.gameforge.internal', status: 'active' },
    { id: 2, url: 'assets.gameforge.internal', status: 'active' },
    { id: 3, url: 'auth.gameforge.internal', status: 'inactive' },
  ],
  project: {
    defaultBuildCommand: 'npm run build',
    autoDeploy: true,
    cleanTargetDirectory: false,
    envVars: [
      { id: 1, key: 'API_URL', value: 'https://api.gameforge.dev/v1' },
      { id: 2, key: 'ASSET_CDN', value: 'https://cdn.gameforge.assets' }
    ]
  }
};

export const AppearanceContext = createContext();

export const AppearanceProvider = ({ children }) => {
  const [settings, setSettings] = useState(() => {
    try {
      const savedSettings = localStorage.getItem('gameforge_settings');
      if (savedSettings) {
        const parsed = JSON.parse(savedSettings);
        // Deep merge to ensure all keys from initialSettings are present
        const mergedSettings = { ...initialSettings };
        for (const section in parsed) {
          if (typeof parsed[section] === 'object' && parsed[section] !== null && !Array.isArray(parsed[section])) {
            mergedSettings[section] = { ...initialSettings[section], ...parsed[section] };
          } else {
            mergedSettings[section] = parsed[section];
          }
        }
        return mergedSettings;
      }
      return initialSettings;
    } catch (error) {
      return initialSettings;
    }
  });

  useEffect(() => {
    localStorage.setItem('gameforge_settings', JSON.stringify(settings));
  }, [settings]);

  const updateSettings = (section, key, value) => {
    setSettings(prev => {
        if (typeof key === 'object') {
             return { ...prev, [section]: key };
        }
        return {
            ...prev,
            [section]: { ...prev[section], [key]: value }
        }
    });
  };
  
  const resetSettings = () => {
    setSettings(initialSettings);
  }

  const value = {
    settings,
    appearance: settings.appearance,
    updateSettings,
    resetSettings,
    initialSettings
  };

  return (
    <AppearanceContext.Provider value={value}>
      {children}
    </AppearanceContext.Provider>
  );
};