import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';

const AuthContext = createContext(undefined);

export const AuthProvider = ({ children }) => {
  const { toast } = useToast();

  const [session, setSession] = useState(null);
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = useCallback(async (currentUser) => {
    if (!currentUser) return null;
    try {
      const { data, error, status } = await supabase
        .from('profiles')
        .select(`*`)
        .eq('id', currentUser.id)
        .single();

      if (error && status !== 406) throw error;
      return data || null;
    } catch (error) {
      console.error('Error fetching profile:', error);
      return null;
    }
  }, []);

  const handleSignOut = useCallback(() => {
    setProfile(null);
    setUser(null);
    setSession(null);
    toast({
        title: '> CONNECTION TERMINATED',
        description: 'You have been successfully logged out.',
    });
  }, [toast]);


  useEffect(() => {
    const initializeSession = async () => {
      const { data: { session: currentSession }, error } = await supabase.auth.getSession();

      if (error) {
        console.error("Error getting session:", error);
      } else if (currentSession) {
        const currentUser = currentSession.user;
        const userProfile = await fetchProfile(currentUser);
        setSession(currentSession);
        setUser(currentUser);
        setProfile(userProfile);
      }
      setLoading(false);
    };

    initializeSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, newSession) => {
        if (event === 'SIGNED_OUT') {
           handleSignOut();
           return;
        }

        if (newSession) {
          const currentUser = newSession.user;
          const userProfile = await fetchProfile(currentUser);
          setSession(newSession);
          setUser(currentUser);
          setProfile(userProfile);
          if (event === 'SIGNED_IN') {
            toast({
              title: '> ACCESS GRANTED',
              description: `Welcome back, ${userProfile?.username || 'agent'}. Neural link established.`,
            });
          }
        }
      }
    );

    return () => {
      subscription.unsubscribe();
    };
  }, [fetchProfile, handleSignOut, toast]);

  const signUp = useCallback(async (email, password, username) => {
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: { data: { username } },
      });
      if (error) throw error;
      if (data.user && !data.session) {
        toast({
          title: '> ACCOUNT INITIALIZED',
          description: `Welcome, ${username}. Please check your email to verify your account.`,
        });
      }
      return { data, error };
    } catch (error) {
      let description = "An unknown error occurred during sign up.";
      if (error.message.includes("User already registered")) {
        description = "This email address is already in use.";
      } else if (error.message.includes('duplicate key value violates unique constraint "profiles_username_key"')) {
        description = "This username is already taken.";
      } else {
        description = error.message;
      }
      toast({ variant: "destructive", title: "Sign up Failed", description });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  const signIn = useCallback(async (email, password) => {
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      toast({
        variant: "destructive",
        title: "Sign in Failed",
        description: error.message || "Something went wrong",
      });
    }
    setLoading(false);
    return { error };
  }, [toast]);

  const logout = useCallback(async () => {
    await supabase.auth.signOut();
  }, []);

  const value = {
    user,
    profile,
    session,
    loading,
    isAuthenticated: !!user && !!profile,
    isOwnerOrAdmin: profile?.role === 'admin' || profile?.role === 'owner' || profile?.role === 'oversee',
    signUp,
    signIn,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};