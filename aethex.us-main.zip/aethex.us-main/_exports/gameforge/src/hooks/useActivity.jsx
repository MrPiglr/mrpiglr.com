import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';

const ActivityContext = createContext();

const initialActivities = [
  { id: 1, type: 'system', message: 'GameForge systems initialized.', timestamp: new Date(Date.now() - 60000).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }), user: 'SYSTEM' },
  { id: 2, type: 'build', message: 'Build pipeline completed successfully', timestamp: new Date(Date.now() - 3600000).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }), user: 'SYSTEM' },
];

export const ActivityProvider = ({ children }) => {
  const { profile } = useAuth();
  const [activities, setActivities] = useState(initialActivities);

  useEffect(() => {
    try {
      const savedActivities = localStorage.getItem('gameforge_activities');
      if (savedActivities) {
        setActivities(JSON.parse(savedActivities));
      }
    } catch (error) {
      console.error("Failed to parse activities from localStorage", error);
      setActivities(initialActivities);
    }
  }, []);

  const addActivity = useCallback((newActivity) => {
    const activity = {
      id: Date.now(),
      user: profile?.username || 'SYSTEM',
      timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      ...newActivity,
    };

    setActivities(prevActivities => {
      const updatedActivities = [activity, ...prevActivities].slice(0, 20);
      localStorage.setItem('gameforge_activities', JSON.stringify(updatedActivities));
      return updatedActivities;
    });
  }, [profile?.username]);

  const value = { activities, addActivity };

  return (
    <ActivityContext.Provider value={value}>
      {children}
    </ActivityContext.Provider>
  );
};

export const useActivity = () => {
  const context = useContext(ActivityContext);
  if (context === undefined) {
    throw new Error('useActivity must be used within an ActivityProvider');
  }
  return context;
};