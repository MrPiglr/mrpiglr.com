import { useState, useEffect, useCallback, useRef } from 'react';
import { useAuth } from '@/context/AuthContext';

const useDataFetching = (fetchFunction, skipAuthCheck = false, dependencies = []) => {
  const { user, loading: authLoading } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  const isMounted = useRef(true);

  useEffect(() => {
    isMounted.current = true;
    return () => {
      isMounted.current = false;
    };
  }, []);
  
  const memoizedFetchFunction = useCallback(fetchFunction, dependencies);

  const fetchData = useCallback(async () => {
    if (!skipAuthCheck && !user) {
      if (isMounted.current) setLoading(false);
      return;
    }
    
    if (isMounted.current) {
      setLoading(true);
      setError(null);
    }

    try {
      const result = await memoizedFetchFunction(user);
      if (isMounted.current) {
        setData(result);
      }
    } catch (err) {
      console.error("Error in useDataFetching:", err);
      if (isMounted.current) {
        setError(err);
        setData(null);
      }
    } finally {
      if (isMounted.current) {
        setLoading(false);
      }
    }
  }, [user, skipAuthCheck, memoizedFetchFunction]);

  useEffect(() => {
    const canFetch = skipAuthCheck || !authLoading;
    if (canFetch) {
        fetchData();
    }
  }, [user?.id, authLoading, fetchData, skipAuthCheck]);

  return { data, loading, error, refetch: fetchData };
};

export default useDataFetching;