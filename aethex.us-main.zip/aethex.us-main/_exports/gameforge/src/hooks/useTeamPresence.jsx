import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';

export const useTeamPresence = () => {
  const { toast } = useToast();
  const [teamMembers, setTeamMembers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [onlineCount, setOnlineCount] = useState(0);

  const channelRef = useRef(null);

  const fetchTeamMembers = useCallback(async () => {
    const { data, error } = await supabase.from('profiles').select('*');
    if (error) {
      console.error('Error fetching team members:', error);
      toast({ variant: "destructive", title: "Error", description: "Could not fetch team members." });
      return [];
    }
    return data;
  }, [toast]);

  const updateMemberStatuses = useCallback((allMembers, presences) => {
    const statusOrder = { online: 0, away: 1, busy: 2, offline: 3 };

    const membersWithStatus = allMembers.map(member => {
      const presenceArray = presences[member.id];
      const presence = presenceArray ? presenceArray[0] : null;
      const liveStatus = presence?.status || member.status || 'offline';
      return {
        ...member,
        status: liveStatus,
        last_seen: presence?.last_seen || member.updated_at,
        avatar: member.username.substring(0, 2).toUpperCase(),
        joinDate: new Date(member.created_at).toLocaleDateString(),
        permissions: member.role,
      };
    }).sort((a, b) => statusOrder[a.status] - statusOrder[b.status]);
    
    const currentOnlineCount = Object.values(presences).filter(p => p[0]?.status === 'online').length;
    
    setTeamMembers(membersWithStatus);
    setOnlineCount(currentOnlineCount);
  }, []);

  useEffect(() => {
    const initialize = async () => {
      setLoading(true);
      const initialMembers = await fetchTeamMembers();

      if (channelRef.current) {
        await channelRef.current.unsubscribe();
      }

      channelRef.current = supabase.channel('team-presence');

      const handleSync = () => {
        if (channelRef.current) {
          const presences = channelRef.current.presenceState();
          updateMemberStatuses(initialMembers, presences);
        }
      };

      const handlePostgresChanges = async (payload) => {
        const updatedMembers = await fetchTeamMembers();
        if (channelRef.current) {
          const presences = channelRef.current.presenceState();
          updateMemberStatuses(updatedMembers, presences);
        }
      };

      channelRef.current
        .on('presence', { event: 'sync' }, handleSync)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'profiles' }, handlePostgresChanges)
        .subscribe(status => {
          if (status === 'SUBSCRIBED') {
            const presences = channelRef.current.presenceState();
            updateMemberStatuses(initialMembers, presences);
            setLoading(false);
          }
        });
    };

    initialize();

    return () => {
      if (channelRef.current) {
        channelRef.current.unsubscribe();
        channelRef.current = null;
      }
    };
  }, [fetchTeamMembers, updateMemberStatuses]);

  return { teamMembers, onlineCount, loading };
};