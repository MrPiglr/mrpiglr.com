import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Routes, Route } from 'react-router-dom';
import HomePage from '@/components/HomePage';
import MainApp from '@/components/MainApp';
import LoadingScreen from '@/components/LoadingScreen';
import { Toaster } from '@/components/ui/toaster';
import { ActivityProvider } from '@/hooks/useActivity.jsx';
import { AppearanceProvider } from '@/context/AppearanceContext';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { AchievementsProvider } from '@/context/AchievementsContext';
import { PresenceProvider } from '@/context/PresenceContext';
import { supabase } from '@/lib/customSupabaseClient';
import MaintenancePage from '@/components/MaintenancePage';
import GamesListPage from '@/components/GamesListPage';
import GamesPage from '@/components/GamesPage';

const AppContent = () => {
  const { isAuthenticated, loading: authLoading, profile } = useAuth();
  const [maintenanceStatus, setMaintenanceStatus] = useState({ enabled: false, message: '' });
  const [checkingMaintenance, setCheckingMaintenance] = useState(true);

  useEffect(() => {
    const fetchAndSubscribe = async () => {
      setCheckingMaintenance(true);
      try {
        const { data, error } = await supabase
          .from('system_settings')
          .select('value')
          .eq('key', 'maintenance_status')
          .single();

        if (error && error.code !== 'PGRST116') throw error;
        
        if (data) {
          setMaintenanceStatus(data.value);
        }
      } catch (error) {
        console.error("Error fetching initial maintenance status:", error);
      } finally {
        setCheckingMaintenance(false);
      }

      const channel = supabase.channel('system-settings-channel')
        .on('postgres_changes', {
          event: '*',
          schema: 'public',
          table: 'system_settings',
          filter: 'key=eq.maintenance_status'
        }, (payload) => {
          if (payload.new && payload.new.value) {
            setMaintenanceStatus(payload.new.value);
          } else {
             // If the row is deleted or value is null, default to off
            setMaintenanceStatus({ enabled: false, message: '' });
          }
        })
        .subscribe((status, err) => {
          if (status === 'SUBSCRIBED') {
            // Subscription is ready, no longer need the initial loading state
            setCheckingMaintenance(false); 
          }
           if (err) {
            console.error("Realtime subscription error:", err);
            setCheckingMaintenance(false);
          }
        });

      return () => {
        supabase.removeChannel(channel);
      };
    };
    
    fetchAndSubscribe();
    
  }, []);

  if (authLoading || checkingMaintenance) {
    return <LoadingScreen />;
  }
  
  const isAdmin = profile?.role === 'admin' || profile?.role === 'owner' || profile?.role === 'oversee';

  if (maintenanceStatus.enabled && !isAdmin) {
     if (!isAuthenticated) {
        return <MaintenancePage message={maintenanceStatus.message} />;
    }
    return <MaintenancePage message={maintenanceStatus.message} />;
  }
  
  if (!isAuthenticated) {
    return (
      <Routes>
        <Route path="*" element={<HomePage />} />
      </Routes>
    );
  }

  return (
    <PresenceProvider>
      <Routes>
        <Route path="/games" element={<GamesListPage />} />
        <Route path="/games/:gameId" element={<GamesPage />} />
        <Route path="*" element={<MainApp />} />
      </Routes>
    </PresenceProvider>
  );
};

function App() {
  return (
    <AppearanceProvider>
      <AuthProvider>
        <AchievementsProvider>
          <ActivityProvider>
            <AppContent />
            <Toaster />
          </ActivityProvider>
        </AchievementsProvider>
      </AuthProvider>
    </AppearanceProvider>
  );
}

export default App;