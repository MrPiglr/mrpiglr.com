import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'framer-motion';
import { Toaster } from '@/components/ui/toaster';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useSiteId } from '@/contexts/SiteIdContext';
import LoadingScreen from '@/components/LoadingScreen';
import AuthModal from '@/components/AuthModal';
import { Route, Routes, useLocation } from 'react-router-dom';
import HomePage from '@/pages/HomePage';
import MyEventsPage from '@/pages/MyEventsPage';
import MyAchievementsPage from '@/pages/MyAchievementsPage';
import PageLayout from '@/components/PageLayout';
import PassportModal from '@/components/PassportModal';
import AdminLayout from '@/pages/admin/AdminLayout';
import AdminDashboardPage from '@/pages/admin/AdminDashboardPage';
import AdminEventsPage from '@/pages/admin/AdminEventsPage';
import AdminUsersPage from '@/pages/admin/AdminUsersPage';
import ProtectedRoute from '@/components/ProtectedRoute';
import ContactPage from '@/pages/ContactPage';
import FaqPage from '@/pages/FaqPage';
import BlogPage from '@/pages/BlogPage';
import AboutPage from '@/pages/AboutPage';
import SponsorsPage from '@/pages/SponsorsPage';
import DeveloperResourcesPage from '@/pages/DeveloperResourcesPage';
import MaintenancePage from '@/pages/MaintenancePage';

function App() {
  const { loading: authLoading, user } = useAuth();
  const { loading: siteLoading, siteConfig } = useSiteId();
  const [initialLoading, setInitialLoading] = useState(true);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showPassportModal, setShowPassportModal] = useState(false);
  const location = useLocation();

  useEffect(() => {
    if (!authLoading && !siteLoading) {
      const timer = setTimeout(() => {
        setInitialLoading(false);
      }, 2500);
      return () => clearTimeout(timer);
    }
  }, [authLoading, siteLoading]);

  const [isAppReady, setIsAppReady] = useState(false);
  useEffect(() => {
    if (!initialLoading) {
      setIsAppReady(true);
    }
  }, [initialLoading]);

  if (!isAppReady) {
    return <LoadingScreen />;
  }

  if (siteConfig?.maintenance_mode) {
    return <MaintenancePage config={siteConfig} />;
  }

  const handleAuthClick = () => setShowAuthModal(true);
  const handlePassportClick = () => {
    if (user) {
      setShowPassportModal(true);
    } else {
      setShowAuthModal(true);
    }
  };

  return (
    <>
      <AnimatePresence mode="wait">
        <Routes location={location} key={location.pathname}>
          <Route element={<PageLayout onAuthClick={handleAuthClick} onPassportClick={handlePassportClick} />}>
            <Route path="/" element={<HomePage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/sponsors" element={<SponsorsPage />} />
            <Route path="/resources" element={<DeveloperResourcesPage />} />
            <Route path="/my-events" element={<ProtectedRoute><MyEventsPage /></ProtectedRoute>} />
            <Route path="/my-achievements" element={<ProtectedRoute><MyAchievementsPage /></ProtectedRoute>} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/faq" element={<FaqPage />} />
            <Route path="/blog" element={<BlogPage />} />
          </Route>
          
          <Route path="/admin" element={
            <ProtectedRoute adminOnly>
              <AdminLayout />
            </ProtectedRoute>
          }>
            <Route index element={<AdminDashboardPage />} />
            <Route path="events" element={<AdminEventsPage />} />
            <Route path="users" element={<AdminUsersPage />} />
          </Route>

        </Routes>
      </AnimatePresence>

      <AnimatePresence>
        {showAuthModal && <AuthModal onClose={() => setShowAuthModal(false)} />}
      </AnimatePresence>
      
      <AnimatePresence>
        {showPassportModal && <PassportModal onClose={() => setShowPassportModal(false)} />}
      </AnimatePresence>
      
      <Toaster />
    </>
  );
}

export default App;