import React, { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';

const AuthContext = createContext(undefined);

export const AuthProvider = ({ children }) => {
  const { toast } = useToast();

  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);

  const signOut = useCallback(async (options = { showToast: true }) => {
    const { error } = await supabase.auth.signOut();
    setUser(null);
    setProfile(null);
    setSession(null);

    if (error) {
      if (options.showToast) {
        toast({
          variant: "destructive",
          title: "Sign out Failed",
          description: error.message || "Something went wrong",
        });
      }
    }
    return { error };
  }, [toast]);

  const fetchProfile = useCallback(async (userId) => {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();
    
    if (error) {
      console.error("Error fetching profile:", error.message);
      setProfile(null);
    } else {
      setProfile(data);
    }
    return data;
  }, []);

  const handleSession = useCallback(async (currentSession) => {
    setSession(currentSession);
    const currentUser = currentSession?.user ?? null;
    setUser(currentUser);

    if (currentUser) {
      await fetchProfile(currentUser.id);
    } else {
      setProfile(null);
    }
    setLoading(false);
  }, [fetchProfile]);

  useEffect(() => {
    const getInitialSession = async () => {
      try {
        const { data: { session: initialSession }, error } = await supabase.auth.getSession();
        if (error) throw error;
        await handleSession(initialSession);
      } catch (error) {
        console.error("Error getting initial session:", error);
        if (error.message.includes("Invalid Refresh Token")) {
          await signOut({ showToast: false });
        }
        setLoading(false);
      }
    };

    getInitialSession();

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, newSession) => {
        if (event === 'SIGNED_IN') {
          await handleSession(newSession);
        } else if (event === 'SIGNED_OUT') {
          await handleSession(null);
        } else if (event === 'TOKEN_REFRESHED') {
          await handleSession(newSession);
        } else if (event === 'USER_UPDATED') {
          if (newSession?.user) {
            await fetchProfile(newSession.user.id);
          }
        } else if (event === 'PASSWORD_RECOVERY') {
          // Handled on the password recovery page
        }
      }
    );

    return () => {
      subscription.unsubscribe();
    };
  }, [handleSession, fetchProfile, signOut]);

  const signUp = useCallback(async (email, password, options) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options,
    });

    if (error) {
      toast({
        variant: "destructive",
        title: "Sign up Failed",
        description: error.message || "Something went wrong",
      });
    } else {
        toast({
            variant: "success",
            title: "Sign up successful!",
            description: "Please check your email to verify your account.",
        });
        if (data.user) {
          await fetchProfile(data.user.id);
        }
    }

    return { error };
  }, [toast, fetchProfile]);

  const signIn = useCallback(async (email, password) => {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      toast({
        variant: "destructive",
        title: "Sign in Failed",
        description: error.message || "Something went wrong",
      });
    } else if (data.user) {
      await handleSession(data.session);
    }

    return { error };
  }, [toast, handleSession]);

  const value = useMemo(() => ({
    user,
    profile,
    session,
    loading,
    signUp,
    signIn,
    signOut,
    fetchProfile,
  }), [user, profile, session, loading, signUp, signIn, signOut, fetchProfile]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};