import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from './SupabaseAuthContext';

const SiteIdContext = createContext({
  siteId: null,
  siteConfig: null,
  loading: true,
  error: null,
});

export const useSiteId = () => useContext(SiteIdContext);

export const SiteIdProvider = ({ children }) => {
  const { user, loading: authLoading } = useAuth();
  const [siteId, setSiteId] = useState(null);
  const [siteConfig, setSiteConfig] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const initializeSite = async () => {
      setLoading(true);
      setError(null);

      if (authLoading) return;

      const siteName = "AeThex Events";
      const siteUuid = "034e6198-8d0b-4207-ab77-b1575f27ec14";
      const ownerId = user?.id;

      try {
        if (!ownerId) {
          const { data: publicConfig, error: publicConfigError } = await supabase
            .from('site_config')
            .select('*')
            .eq('site_id', siteUuid)
            .single();

          if (publicConfigError && publicConfigError.code !== 'PGRST116') {
             throw publicConfigError;
          }
          if (publicConfig) {
            setSiteId(siteUuid);
            setSiteConfig(publicConfig);
          } else {
             setError(new Error("Site not found and user not logged in to initialize."));
          }
        } else {
          const { data, error: rpcError } = await supabase.rpc('initialize_site_and_get_identity', {
            p_site_name: siteName,
            p_owner_id: ownerId,
          });

          if (rpcError) throw rpcError;
          
          const newSiteId = data;
          setSiteId(newSiteId);

          const { data: configData, error: configError } = await supabase
            .from('site_config')
            .select('*')
            .eq('site_id', newSiteId)
            .single();

          if (configError) throw configError;

          setSiteConfig(configData);
        }
      } catch (e) {
        console.error("Error initializing site:", e);
        setError(e);
      } finally {
        setLoading(false);
      }
    };

    initializeSite();
  }, [user, authLoading]);

  const value = useMemo(() => ({
    siteId,
    siteConfig,
    loading,
    error,
  }), [siteId, siteConfig, loading, error]);

  return (
    <SiteIdContext.Provider value={value}>
      {children}
    </SiteIdContext.Provider>
  );
};