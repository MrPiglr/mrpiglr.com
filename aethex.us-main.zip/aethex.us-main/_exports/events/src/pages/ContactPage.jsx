import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Mail, MessageSquare, Send, User } from 'lucide-react';
import { Link } from 'react-router-dom';

const ContactPage = () => {
    const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
    const [loading, setLoading] = useState(false);
    const { toast } = useToast();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);

        const { error } = await supabase
            .from('contact_submissions')
            .insert([formData]);

        setLoading(false);

        if (error) {
            toast({
                variant: 'destructive',
                title: 'Submission Failed',
                description: `There was an error: ${error.message}`,
            });
        } else {
            toast({
                variant: 'success',
                title: 'Message Sent!',
                description: 'Thanks for reaching out. We will get back to you shortly.',
            });
            setFormData({ name: '', email: '', subject: '', message: '' });
        }
    };

    return (
        <>
            <Helmet>
                <title>Contact Us - AeThex Events</title>
                <meta name="description" content="Get in touch with the AeThex Events team. We're here to answer your questions about our events, sponsorship, or any other inquiries." />
            </Helmet>
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5 }}
                className="max-w-3xl mx-auto"
            >
                <div className="text-center mb-12">
                    <h1 className="text-4xl md:text-5xl font-bold text-white tracking-tight">Get in Touch</h1>
                    <p className="mt-4 text-lg text-gray-300">
                        Have a question or a comment? Drop us a line below.
                    </p>
                </div>
                <div className="bg-gray-950/50 border border-gray-800 rounded-2xl p-8 backdrop-blur-lg">
                    <form onSubmit={handleSubmit} className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-2">
                                <Label htmlFor="name">Full Name</Label>
                                <div className="relative">
                                    <User className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                                    <Input id="name" name="name" type="text" value={formData.name} onChange={handleChange} required className="pl-10" />
                                </div>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor="email">Email Address</Label>
                                <div className="relative">
                                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                                    <Input id="email" name="email" type="email" value={formData.email} onChange={handleChange} required className="pl-10" />
                                </div>
                            </div>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="subject">Subject</Label>
                            <div className="relative">
                                <MessageSquare className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                                <Input id="subject" name="subject" type="text" value={formData.subject} onChange={handleChange} required className="pl-10" />
                            </div>
                        </div>
                        <div className="space-y-2">
                            <Label htmlFor="message">Message</Label>
                            <Textarea id="message" name="message" value={formData.message} onChange={handleChange} required rows={5} />
                        </div>
                        <div>
                            <Button type="submit" disabled={loading} className="w-full text-lg py-6">
                                {loading ? (
                                    <>
                                        <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Sending...
                                    </>
                                ) : (
                                    <>
                                        <Send className="mr-2 h-5 w-5" /> Send Message
                                    </>
                                )}
                            </Button>
                        </div>
                    </form>
                </div>
                <p className="text-center text-gray-500 text-sm mt-8">
                    Looking for answers to common questions? Check out our <Link to="/faq" className="text-primary hover:underline">FAQ Page</Link>.
                </p>
            </motion.div>
        </>
    );
};

export default ContactPage;