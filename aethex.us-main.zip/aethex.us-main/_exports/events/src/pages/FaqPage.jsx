import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/customSupabaseClient';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Loader2 } from 'lucide-react';

const FaqPage = () => {
    const [faqs, setFaqs] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchFaqs = async () => {
            setLoading(true);
            const { data, error } = await supabase
                .from('faqs')
                .select('*')
                .order('display_order', { ascending: true });

            if (error) {
                console.error('Error fetching FAQs:', error);
            } else {
                setFaqs(data);
            }
            setLoading(false);
        };

        fetchFaqs();
    }, []);

    return (
        <>
            <Helmet>
                <title>Frequently Asked Questions - AeThex Events</title>
                <meta name="description" content="Find answers to common questions about AeThex events, registration, ticketing, and participation." />
            </Helmet>
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5 }}
                className="max-w-4xl mx-auto"
            >
                <div className="text-center mb-12">
                    <h1 className="text-4xl md:text-5xl font-bold text-white tracking-tight">Frequently Asked Questions</h1>
                    <p className="mt-4 text-lg text-gray-300">
                        Can't find the answer you're looking for? Feel free to <a href="/contact" className="text-primary hover:underline">contact us</a>.
                    </p>
                </div>

                {loading ? (
                    <div className="flex justify-center items-center h-64">
                        <Loader2 className="h-12 w-12 text-primary animate-spin" />
                    </div>
                ) : (
                    <Accordion type="single" collapsible className="w-full bg-gray-950/50 border border-gray-800 rounded-2xl p-4 md:p-8 backdrop-blur-lg">
                        {faqs.length > 0 ? faqs.map(faq => (
                             <AccordionItem key={faq.id} value={`item-${faq.id}`}>
                                <AccordionTrigger className="text-lg hover:no-underline">{faq.question}</AccordionTrigger>
                                <AccordionContent className="prose prose-invert max-w-none prose-p:text-gray-300">
                                    <p>{faq.answer}</p>
                                </AccordionContent>
                            </AccordionItem>
                        )) : (
                           <div className="text-center py-10 text-gray-400">
                                No FAQs have been added yet. Please check back later.
                           </div>
                        )}
                    </Accordion>
                )}
            </motion.div>
        </>
    );
};

export default FaqPage;