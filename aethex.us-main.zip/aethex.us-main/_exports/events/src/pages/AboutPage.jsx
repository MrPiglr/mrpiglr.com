import React from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Target, Zap, Users, Code, Lightbulb } from 'lucide-react';
import PageHeader from '@/components/PageHeader';

const FeatureCard = ({ icon, title, children, delay }) => (
  <motion.div
    variants={{
      hidden: { opacity: 0, y: 50 },
      visible: { opacity: 1, y: 0, transition: { delay, duration: 0.5, ease: 'easeOut' } },
    }}
  >
    <Card className="h-full text-center bg-card/50 backdrop-blur-sm border-white/10 hover:border-primary/50 transition-all duration-300 hover:shadow-primary/10">
      <CardHeader>
        <div className="mx-auto bg-primary/10 text-primary rounded-full h-16 w-16 flex items-center justify-center mb-4 ring-4 ring-primary/10 group-hover:ring-primary/20 transition-all">
          {icon}
        </div>
        <CardTitle className="text-xl font-bold">{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground">{children}</p>
      </CardContent>
    </Card>
  </motion.div>
);

const SectionWrapper = ({ children, className = '' }) => (
  <motion.section
    className={`py-16 sm:py-24 ${className}`}
    initial="hidden"
    whileInView="visible"
    viewport={{ once: true, amount: 0.2 }}
    transition={{ staggerChildren: 0.2 }}
  >
    {children}
  </motion.section>
);


const AboutPage = () => {
  return (
    <>
      <Helmet>
        <title>About AeThex Events</title>
        <meta name="description" content="Learn about the mission of AeThex Events: to foster innovation, connection, and growth within the global tech community." />
      </Helmet>

      <PageHeader
        title="About Us"
        subtitle="Fostering Innovation, Connection, and Growth"
      />

      <SectionWrapper>
        <div className="grid md:grid-cols-2 gap-16 items-center">
            <motion.div
                variants={{ hidden: { opacity: 0, x: -50 }, visible: { opacity: 1, x: 0, transition: { duration: 0.6 }}}}
            >
                <div className="relative">
                    <div className="absolute -inset-2 bg-gradient-to-br from-primary to-secondary rounded-2xl opacity-20 blur-xl"></div>
                    <img 
                        className="relative w-full rounded-2xl shadow-2xl"
                        alt="Team of diverse developers collaborating around a table with laptops"
                     src="https://images.unsplash.com/photo-1651009188116-bb5f80eaf6aa" />
                </div>
            </motion.div>
            <motion.div
                 variants={{ hidden: { opacity: 0, x: 50 }, visible: { opacity: 1, x: 0, transition: { duration: 0.6, delay: 0.2 }}}}
            >
                <div className="flex items-center gap-3 mb-4">
                    <Target className="w-8 h-8 text-primary" />
                    <h2 className="text-3xl md:text-4xl font-bold text-white tracking-tight">Our Mission</h2>
                </div>
                <div className="prose prose-invert max-w-none prose-p:text-gray-300 prose-p:text-lg">
                    <p>
                        At AeThex Events, our mission is to create unparalleled experiences that empower the global technology community. We believe that true innovation happens at the intersection of brilliant minds and groundbreaking ideas.
                    </p>
                    <p>
                        We are dedicated to building a vibrant ecosystem where developers, designers, and visionaries can connect, learn, and grow together. Through our meticulously curated conferences, workshops, and networking sessions, we aim to spark creativity, accelerate careers, and shape the future of technology.
                    </p>
                </div>
            </motion.div>
        </div>
      </SectionWrapper>
      
      <SectionWrapper className="bg-card/20 rounded-2xl">
        <motion.div 
          className="text-center mb-16"
          variants={{
            hidden: { opacity: 0, y: 20 },
            visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
          }}
        >
          <h2 className="text-4xl md:text-5xl font-bold text-white tracking-tight">Why Attend?</h2>
          <p className="mt-4 text-lg text-gray-400 max-w-3xl mx-auto">
            Our events are more than just talks. They are immersive experiences designed to accelerate your growth and expand your network.
          </p>
        </motion.div>
        <div className="grid md:grid-cols-3 gap-8">
          <FeatureCard icon={<Zap className="w-8 h-8" />} title="Cutting-Edge Content" delay={0.1}>
            Learn from industry experts at the forefront of technology, sharing insights you won't find anywhere else.
          </FeatureCard>
          <FeatureCard icon={<Users className="w-8 h-8" />} title="Elite Networking" delay={0.2}>
            Connect with peers, mentors, and future collaborators who share your passion for innovation.
          </FeatureCard>
          <FeatureCard icon={<Code className="w-8 h-8" />} title="Hands-On Workshops" delay={0.3}>
            Go beyond theory with practical workshops that give you real-world skills to apply immediately.
          </FeatureCard>
        </div>
      </SectionWrapper>
    </>
  );
};

export default AboutPage;