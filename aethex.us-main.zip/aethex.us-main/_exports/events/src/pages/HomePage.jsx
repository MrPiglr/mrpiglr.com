import React, { useState } from 'react';
import { Helmet } from 'react-helmet-async';
import { AnimatePresence, motion } from 'framer-motion';
import { useEvents } from '@/hooks/useEvents';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useSiteId } from '@/contexts/SiteIdContext';
import EventList from '@/components/EventList';
import EventDetailModal from '@/components/EventDetailModal';
import FeaturedSpeakers from '@/components/FeaturedSpeakers';
import Testimonials from '@/components/Testimonials';
import { useOutletContext } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ArrowDown, Sparkles } from 'lucide-react';

const SectionWrapper = ({ children, id, className = '' }) => (
  <motion.section
    id={id}
    className={`py-24 ${className}`}
    initial="hidden"
    whileInView="visible"
    viewport={{ once: true, amount: 0.2 }}
    transition={{ staggerChildren: 0.2 }}
  >
    {children}
  </motion.section>
);

const HomePage = () => {
  const {
    filteredEvents,
    setSearchTerm,
    setSelectedCategory,
    registeredEvents,
    handleRegister,
    handleUnregister,
    getCategoryColor,
    getCategoryLabel,
    loading: eventsLoading,
    registrationLoading,
  } = useEvents();

  const { user } = useAuth();
  const { siteId } = useSiteId();
  
  const [selectedEvent, setSelectedEvent] = useState(null);
  const { onAuthClick } = useOutletContext() || {};

  const handleRegisterClick = (eventId, ticketType) => {
    if (!user) {
      if(onAuthClick) onAuthClick();
    } else {
      handleRegister(eventId, ticketType);
    }
  };

  const scrollToEvents = () => {
    const eventsSection = document.getElementById('events-section');
    if (eventsSection) {
      eventsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };
  
  return (
    <>
      <Helmet>
        <title>AeThex Events - Innovation & Technology Conferences</title>
        <meta name="description" content="Join AeThex for cutting-edge technology events, conferences, workshops, and networking opportunities. Connect with industry leaders and innovators." />
        <meta property="og:title" content="AeThex Events - Innovation & Technology Conferences" />
        <meta property="og:description" content="Join AeThex for cutting-edge technology events, conferences, workshops, and networking opportunities. Connect with industry leaders and innovators." />
        {siteId && <meta name="aethex-site-id" content={siteId} />}
      </Helmet>
      
      <div className="relative min-h-[60vh] flex items-center justify-center text-center overflow-hidden mb-24 rounded-2xl bg-grid p-8">
        <div className="absolute inset-0 bg-gradient-to-b from-background/50 via-background/80 to-background z-10"></div>
        <motion.div 
            className="absolute inset-0 z-0"
            animate={{
                backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"],
            }}
            transition={{
                duration: 20,
                ease: "linear",
                repeat: Infinity,
            }}
            style={{
                backgroundImage: 'radial-gradient(ellipse 80% 80% at 50% -20%, hsl(var(--primary) / 0.2), transparent), radial-gradient(ellipse 80% 80% at 50% 120%, hsl(var(--secondary) / 0.2), transparent)',
            }}
        />
        <motion.div 
          className="z-20"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
        >
          <motion.div 
            className="inline-flex items-center gap-2 px-4 py-2 mb-4 text-sm font-semibold rounded-full bg-primary/10 text-primary border border-primary/20"
            initial={{ y: -20, opacity: 0}}
            animate={{ y: 0, opacity: 1}}
            transition={{ delay: 0.2 }}
          >
            <Sparkles className="w-4 h-4" />
            <span>The Future of Tech is Here</span>
          </motion.div>
          <h1 className="text-5xl md:text-7xl font-bold tracking-tighter text-transparent bg-clip-text bg-gradient-to-br from-white to-gray-400">
            Level Up Your Skills
          </h1>
          <p className="mt-4 text-lg text-gray-300 max-w-2xl mx-auto">
            Join elite developers, designers, and innovators at AeThex Events. Explore cutting-edge tech, forge new connections, and redefine what's possible.
          </p>
          <Button size="lg" className="mt-8 font-bold" onClick={scrollToEvents}>
            Explore Events
            <ArrowDown className="ml-2 h-5 w-5" />
          </Button>
        </motion.div>
      </div>
      
      <SectionWrapper id="events-section" className="bg-card/20 rounded-2xl">
        <EventList
          loading={eventsLoading}
          filteredEvents={filteredEvents}
          onSelectEvent={setSelectedEvent}
          getCategoryColor={getCategoryColor}
          getCategoryLabel={getCategoryLabel}
          setSearchTerm={setSearchTerm}
          setSelectedCategory={setSelectedCategory}
        />
      </SectionWrapper>

      <SectionWrapper>
        <FeaturedSpeakers />
      </SectionWrapper>
      
      <SectionWrapper>
        <Testimonials />
      </SectionWrapper>

      <AnimatePresence>
        {selectedEvent && (
          <EventDetailModal
            event={selectedEvent}
            onClose={() => setSelectedEvent(null)}
            onRegister={handleRegisterClick}
            onUnregister={handleUnregister}
            isRegistered={registeredEvents.includes(selectedEvent.id)}
            getCategoryColor={getCategoryColor}
            getCategoryLabel={getCategoryLabel}
            isLoading={registrationLoading}
          />
        )}
      </AnimatePresence>
    </>
  );
};

export default HomePage;