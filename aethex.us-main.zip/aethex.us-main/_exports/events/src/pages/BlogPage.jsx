import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/customSupabaseClient';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowRight } from 'lucide-react';
import { formatDate } from '@/lib/utils';

const BlogPage = () => {
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchPosts = async () => {
            setLoading(true);
            const { data, error } = await supabase
                .from('blog_posts')
                .select('*')
                .eq('status', 'published')
                .order('published_at', { ascending: false });

            if (error) {
                console.error("Error fetching blog posts:", error);
            } else {
                setPosts(data);
            }
            setLoading(false);
        };
        fetchPosts();
    }, []);

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: {
                staggerChildren: 0.1,
            },
        },
    };

    const itemVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: { opacity: 1, y: 0 },
    };

    return (
        <>
            <Helmet>
                <title>News & Updates - AeThex Events</title>
                <meta name="description" content="Stay up to date with the latest news, announcements, and articles from AeThex Events." />
            </Helmet>
            <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
                className="space-y-12"
            >
                <div className="text-center">
                    <h1 className="text-4xl md:text-5xl font-bold text-white tracking-tight">News & Updates</h1>
                    <p className="mt-4 text-lg text-gray-300 max-w-2xl mx-auto">
                        The latest articles, announcements, and insights from the AeThex team.
                    </p>
                </div>

                {loading ? (
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {[...Array(3)].map((_, i) => (
                            <Card key={i} className="animate-pulse">
                                <div className="h-52 bg-muted rounded-t-lg"></div>
                                <CardHeader>
                                    <div className="h-6 bg-muted rounded w-3/4"></div>
                                </CardHeader>
                                <CardContent>
                                    <div className="h-4 bg-muted rounded w-full mb-2"></div>
                                    <div className="h-4 bg-muted rounded w-5/6"></div>
                                </CardContent>
                                <CardFooter>
                                    <div className="h-8 bg-muted rounded w-1/3"></div>
                                </CardFooter>
                            </Card>
                        ))}
                    </div>
                ) : (
                    <motion.div
                        variants={containerVariants}
                        initial="hidden"
                        animate="visible"
                        className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
                    >
                        {posts.map((post) => (
                            <motion.div key={post.id} variants={itemVariants}>
                                <Card className="bg-card h-full flex flex-col group overflow-hidden border-white/10 hover:border-primary/50 transition-all duration-300">
                                    <div className="overflow-hidden">
                                        <img 
                                            className="w-full h-52 object-cover group-hover:scale-105 transition-transform duration-300"
                                            alt={post.title}
                                         src="https://images.unsplash.com/photo-1504983875-d3b163aba9e6" />
                                    </div>
                                    <CardHeader>
                                        <CardTitle className="group-hover:text-primary transition-colors">{post.title}</CardTitle>
                                    </CardHeader>
                                    <CardContent className="flex-grow">
                                        <p className="text-gray-400 line-clamp-3">{post.content.substring(0, 150)}...</p>
                                        <p className="text-xs text-gray-500 mt-4">{formatDate(post.published_at)}</p>
                                    </CardContent>
                                    <CardFooter>
                                        <Button asChild variant="ghost" className="text-primary hover:text-primary">
                                            <Link to={`/blog/${post.slug}`}>
                                                Read More <ArrowRight className="ml-2 h-4 w-4" />
                                            </Link>
                                        </Button>
                                    </CardFooter>
                                </Card>
                            </motion.div>
                        ))}
                    </motion.div>
                )}

                {posts.length === 0 && !loading && (
                    <div className="text-center py-16">
                        <h2 className="text-2xl font-bold">No Posts Yet</h2>
                        <p className="text-gray-400 mt-2">Check back soon for news and updates!</p>
                    </div>
                )}
            </motion.div>
        </>
    );
};

export default BlogPage;