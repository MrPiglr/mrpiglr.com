import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Award, BarChart, CheckCircle, Loader2, Shield, Star, Trophy } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const MyAchievementsPage = () => {
    const { user, profile } = useAuth();
    const [achievements, setAchievements] = useState([]);
    const [loading, setLoading] = useState(true);

    const achievementData = [
        { id: 1, title: 'First Event', description: 'Registered for your first AeThex event.', icon: <CheckCircle /> },
        { id: 2, title: 'Tech Summit Attendee', description: 'Attended a Tech Summit.', icon: <Shield /> },
        { id: 3, title: 'Workshop Wizard', description: 'Completed a developer workshop.', icon: <Star /> },
        { id: 4, title: 'Social Sharer', description: 'Shared an event on social media.', icon: <Trophy /> },
        { id: 5, title: 'Early Bird', description: 'Registered for an event 30 days in advance.', icon: <Award /> },
        { id: 6, title: 'Triple Threat', description: 'Attended 3 events in a year.', icon: <BarChart /> },
    ];
    
    useEffect(() => {
        const fetchAchievements = async () => {
            if (!user) {
                setLoading(false);
                return;
            }
            setLoading(true);
            // This is mocked for now. In a real scenario, you'd fetch this from a 'user_achievements' table.
            setTimeout(() => {
                const userAchievements = achievementData.slice(0, Math.floor(Math.random() * achievementData.length) + 1);
                setAchievements(userAchievements);
                setLoading(false);
            }, 1000);
        };

        fetchAchievements();
    }, [user]);

    const containerVariants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: { staggerChildren: 0.1 }
        }
    };

    const itemVariants = {
        hidden: { y: 20, opacity: 0 },
        visible: { y: 0, opacity: 1 }
    };

    return (
        <>
            <Helmet>
                <title>My Achievements - AeThex Events</title>
                <meta name="description" content="Track your progress, view your achievements, and see your reputation score on the AeThex Events platform." />
            </Helmet>
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.5 }}
                className="max-w-6xl mx-auto"
            >
                <div className="text-center mb-12">
                    <motion.h1 
                        className="text-5xl md:text-6xl font-bold tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary"
                        initial={{ y: -20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ delay: 0.1 }}
                    >
                        Your Trophies
                    </motion.h1>
                    <motion.p 
                        className="mt-4 text-lg text-gray-300"
                        initial={{ y: -20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ delay: 0.2 }}
                    >
                        Check out your stats and collected achievements. Keep engaging to unlock more!
                    </motion.p>
                </div>

                <motion.div 
                    className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12"
                    variants={containerVariants}
                    initial="hidden"
                    animate="visible"
                >
                    <motion.div variants={itemVariants}>
                        <Card className="h-full">
                            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                <CardTitle className="text-sm font-medium text-muted-foreground">Reputation Score</CardTitle>
                                <Star className="h-5 w-5 text-yellow-400" />
                            </CardHeader>
                            <CardContent>
                                <div className="text-4xl font-bold text-white">{profile?.loyalty_points || 0}</div>
                                <p className="text-xs text-muted-foreground">Points from event participation</p>
                            </CardContent>
                        </Card>
                    </motion.div>
                     <motion.div variants={itemVariants}>
                        <Card className="h-full">
                            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                <CardTitle className="text-sm font-medium text-muted-foreground">Achievements Unlocked</CardTitle>
                                <Trophy className="h-5 w-5 text-primary" />
                            </CardHeader>
                            <CardContent>
                                <div className="text-4xl font-bold text-white">{loading ? '...' : achievements.length} / {achievementData.length}</div>
                                <p className="text-xs text-muted-foreground">Keep going to collect them all!</p>
                            </CardContent>
                        </Card>
                    </motion.div>
                     <motion.div variants={itemVariants}>
                        <Card className="h-full">
                            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                <CardTitle className="text-sm font-medium text-muted-foreground">Current Level</CardTitle>
                                <Shield className="h-5 w-5 text-secondary" />
                            </CardHeader>
                            <CardContent>
                                <div className="text-4xl font-bold text-white">Level {Math.floor((profile?.loyalty_points || 0) / 100) + 1}</div>
                                <p className="text-xs text-muted-foreground">Event Veteran</p>
                            </CardContent>
                        </Card>
                    </motion.div>
                </motion.div>

                <h2 className="text-3xl font-bold text-white mb-6">Unlocked Achievements</h2>
                {loading ? (
                     <div className="flex justify-center items-center h-64">
                        <Loader2 className="h-12 w-12 text-primary animate-spin" />
                    </div>
                ) : (
                    <motion.div 
                        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
                        variants={containerVariants}
                        initial="hidden"
                        animate="visible"
                    >
                        {achievementData.map((ach) => {
                            const isUnlocked = achievements.some(unlocked => unlocked.id === ach.id);
                            return (
                                <motion.div key={ach.id} variants={itemVariants}>
                                    <Card className={`transition-all duration-300 h-full ${isUnlocked ? 'border-primary/50 shadow-primary/10' : 'opacity-40 grayscale'}`}>
                                        <CardContent className="p-6 flex items-center gap-6">
                                            <div className={`text-4xl ${isUnlocked ? 'text-primary' : 'text-gray-500'}`}>{ach.icon}</div>
                                            <div>
                                                <h3 className={`font-bold ${isUnlocked ? 'text-white' : 'text-gray-400'}`}>{ach.title}</h3>
                                                <p className="text-sm text-gray-500">{ach.description}</p>
                                            </div>
                                        </CardContent>
                                    </Card>
                                </motion.div>
                            )
                        })}
                    </motion.div>
                )}
            </motion.div>
        </>
    );
};

export default MyAchievementsPage;