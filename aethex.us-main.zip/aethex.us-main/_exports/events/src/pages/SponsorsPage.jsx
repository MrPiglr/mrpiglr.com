import React from 'react';
import { Helmet } from 'react-helmet-async';
import Sponsors from '@/components/Sponsors';
import PageHeader from '@/components/PageHeader';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

const SponsorsPage = () => {
  return (
    <>
      <Helmet>
        <title>Sponsors - AeThex Events</title>
        <meta name="description" content="Meet the industry-leading companies and partners who make AeThex Events possible. Learn about sponsorship opportunities." />
      </Helmet>
      
      <PageHeader
        title="Our Valued Sponsors"
        subtitle="We are incredibly grateful for the support of these forward-thinking organizations."
      />
      
      <div className="py-16">
        <Sponsors />
      </div>

      <div className="text-center bg-card/30 rounded-2xl py-16 px-8">
        <h2 className="text-3xl font-bold text-white">Become a Sponsor</h2>
        <p className="text-lg text-gray-400 mt-4 max-w-2xl mx-auto">
          Interested in showcasing your brand to a dedicated audience of tech professionals and innovators? Let's talk.
        </p>
        <Button asChild size="lg" className="mt-8">
            <Link to="/contact">Contact Us</Link>
        </Button>
      </div>
    </>
  );
};

export default SponsorsPage;