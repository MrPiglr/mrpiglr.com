import React, { useState, useEffect } from 'react';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useToast } from '@/components/ui/use-toast';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Textarea } from '@/components/ui/textarea';
    import {
      Select,
      SelectContent,
      SelectItem,
      SelectTrigger,
      SelectValue,
    } from "@/components/ui/select";
    import {
      Dialog,
      DialogContent,
      DialogHeader,
      DialogTitle,
      DialogDescription,
      DialogFooter,
    } from '@/components/ui/dialog';
    import { Trash2, PlusCircle, BadgeDollarSign, Ticket, Star } from 'lucide-react';
    import { CATEGORIES } from '@/hooks/useEvents';

    const EventFormModal = ({ isOpen, onClose, eventData, onSuccess }) => {
      
      const getInitialState = () => ({
        title: '', description: '', full_description: '',
        date: '', time: '', location: '', category: '',
        capacity: 100, price: 0, image_url: '', featured: false,
        speakers: [''], agenda: [{ time: '', title: '' }],
        map_url: '',
        ticket_types: [{ name: 'General Admission', price: 0, benefits: 'Access to all main sessions' }]
      });

      const [formData, setFormData] = useState(getInitialState());
      const [loading, setLoading] = useState(false);
      const { toast } = useToast();

      useEffect(() => {
        if (isOpen) {
            if (eventData) {
              setFormData({
                title: eventData.title || '',
                description: eventData.description || '',
                full_description: eventData.full_description || '',
                date: eventData.date || '',
                time: eventData.time || '',
                location: eventData.location || '',
                category: eventData.category || '',
                capacity: eventData.capacity || 100,
                price: eventData.price || 0, // Keep this for backward compatibility or simple pricing
                image_url: eventData.image_url || '',
                featured: eventData.featured || false,
                speakers: eventData.speakers && eventData.speakers.length > 0 ? eventData.speakers : [''],
                agenda: eventData.agenda && eventData.agenda.length > 0 ? eventData.agenda : [{ time: '', title: '' }],
                map_url: eventData.map_url || '',
                ticket_types: eventData.ticket_types && eventData.ticket_types.length > 0 ? eventData.ticket_types : [{ name: 'General Admission', price: eventData.price || 0, benefits: 'Access to all main sessions' }]
              });
            } else {
              setFormData(getInitialState());
            }
        }
      }, [eventData, isOpen]);

      const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData(prev => ({ ...prev, [name]: type === 'checkbox' ? checked : value }));
      };
      
      const handleDynamicListChange = (listName, index, value) => {
        const list = [...formData[listName]];
        list[index] = value;
        setFormData(prev => ({...prev, [listName]: list}));
      };

      const addDynamicListItem = (listName, newItem) => {
        setFormData(prev => ({ ...prev, [listName]: [...prev[listName], newItem] }));
      };
      
      const removeDynamicListItem = (listName, index) => {
        if(formData[listName].length <= 1) return;
        const list = [...formData[listName]];
        list.splice(index, 1);
        setFormData(prev => ({...prev, [listName]: list}));
      };
      
      const handleAgendaChange = (index, field, value) => {
        const newAgenda = [...formData.agenda];
        newAgenda[index][field] = value;
        setFormData(prev => ({...prev, agenda: newAgenda }));
      };

      const handleTicketTypeChange = (index, field, value) => {
        const newTicketTypes = [...formData.ticket_types];
        newTicketTypes[index][field] = value;
        setFormData(prev => ({ ...prev, ticket_types: newTicketTypes }));
      };

      const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        
        // Find the lowest price among ticket types to set as the main price for sorting/display
        const lowestPrice = formData.ticket_types.length > 0 ? Math.min(...formData.ticket_types.map(t => Number(t.price))) : 0;

        const submissionData = {
          ...formData,
          price: lowestPrice,
          speakers: formData.speakers.filter(s => s.trim() !== ''),
          agenda: formData.agenda.filter(a => a.time.trim() !== '' && a.title.trim() !== ''),
          ticket_types: formData.ticket_types.filter(t => t.name.trim() !== ''),
        };

        let error;
        if (eventData?.id) {
          const { error: updateError } = await supabase.from('aethex_events').update(submissionData).eq('id', eventData.id);
          error = updateError;
        } else {
          const { error: insertError } = await supabase.from('aethex_events').insert([submissionData]);
          error = insertError;
        }

        setLoading(false);

        if (error) {
          toast({ variant: 'destructive', title: `Error ${eventData?.id ? 'updating' : 'creating'} event`, description: error.message });
        } else {
          toast({ variant: 'success', title: `Event ${eventData?.id ? 'Updated' : 'Created'}`, description: `The event has been successfully ${eventData?.id ? 'updated' : 'created'}.`});
          onSuccess();
        }
      };

      return (
        <Dialog open={isOpen} onOpenChange={onClose}>
          <DialogContent className="max-w-4xl bg-gray-950/80 border-white/10 text-white backdrop-blur-lg">
            <DialogHeader>
              <DialogTitle className="text-2xl font-bold">{eventData ? 'Edit Event' : 'Create New Event'}</DialogTitle>
              <DialogDescription className="text-gray-400">
                Fill in the details for the event. Click save when you're done.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="py-4 max-h-[70vh] overflow-y-auto pr-4 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input id="title" name="title" value={formData.title} onChange={handleChange} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="location">Location</Label>
                  <Input id="location" name="location" value={formData.location} onChange={handleChange} required />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="description">Short Description</Label>
                  <Textarea id="description" name="description" value={formData.description} onChange={handleChange} required />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="full_description">Full Description (Markdown supported)</Label>
                  <Textarea id="full_description" name="full_description" value={formData.full_description} onChange={handleChange} rows={6}/>
                </div>
                 <div className="space-y-2">
                  <Label htmlFor="date">Date</Label>
                  <Input id="date" name="date" type="date" value={formData.date} onChange={handleChange} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="time">Time</Label>
                  <Input id="time" name="time" type="time" value={formData.time} onChange={handleChange} required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select onValueChange={(value) => setFormData(p => ({...p, category: value}))} value={formData.category}>
                    <SelectTrigger><SelectValue placeholder="Select a category" /></SelectTrigger>
                    <SelectContent>
                      {Object.entries(CATEGORIES).map(([key, {label}]) => (
                        <SelectItem key={key} value={key}>{label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="image_url">Image URL</Label>
                  <Input id="image_url" name="image_url" value={formData.image_url} onChange={handleChange} />
                </div>
                <div className="space-y-2">
                    <Label htmlFor="map_url">Map URL (e.g., Google Maps)</Label>
                    <Input id="map_url" name="map_url" value={formData.map_url} onChange={handleChange} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="capacity">Capacity</Label>
                  <Input id="capacity" name="capacity" type="number" value={formData.capacity} onChange={handleChange} required />
                </div>
              </div>

              <div className="space-y-4 pt-4 border-t border-white/10">
                <h3 className="text-lg font-semibold text-white flex items-center"><Ticket className="mr-2 h-5 w-5 text-primary" />Ticket Types</h3>
                {formData.ticket_types.map((ticket, index) => (
                  <div key={index} className="p-4 bg-gray-900/50 rounded-lg border border-gray-800 space-y-3">
                    <div className="flex justify-end">
                      <Button type="button" variant="destructive" size="icon" className="h-7 w-7" onClick={() => removeDynamicListItem('ticket_types', index)} disabled={formData.ticket_types.length <= 1}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor={`ticket_name_${index}`}>Ticket Name</Label>
                        <Input id={`ticket_name_${index}`} value={ticket.name} onChange={(e) => handleTicketTypeChange(index, 'name', e.target.value)} placeholder="e.g., VIP Access" required/>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor={`ticket_price_${index}`}>Price ($)</Label>
                        <Input id={`ticket_price_${index}`} type="number" step="0.01" value={ticket.price} onChange={(e) => handleTicketTypeChange(index, 'price', e.target.value)} required/>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor={`ticket_benefits_${index}`}>Benefits (one per line)</Label>
                      <Textarea id={`ticket_benefits_${index}`} value={ticket.benefits} onChange={(e) => handleTicketTypeChange(index, 'benefits', e.target.value)} placeholder="e.g., Front row seating" />
                    </div>
                  </div>
                ))}
                <Button type="button" variant="outline" size="sm" onClick={() => addDynamicListItem('ticket_types', { name: '', price: 0, benefits: '' })}><PlusCircle className="mr-2 h-4 w-4" />Add Ticket Type</Button>
              </div>
              
              <div className="space-y-4 pt-4 border-t border-white/10">
                <Label>Speakers</Label>
                {formData.speakers.map((speaker, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <Input value={speaker} onChange={(e) => handleDynamicListChange('speakers', index, e.target.value)} placeholder={`Speaker ${index + 1}`} />
                    <Button type="button" variant="destructive" size="icon" onClick={() => removeDynamicListItem('speakers', index)} disabled={formData.speakers.length <= 1}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                <Button type="button" variant="outline" size="sm" onClick={() => addDynamicListItem('speakers', '')}><PlusCircle className="mr-2 h-4 w-4" />Add Speaker</Button>
              </div>

              <div className="space-y-4 pt-4 border-t border-white/10">
                <Label>Agenda</Label>
                {formData.agenda.map((item, index) => (
                  <div key={index} className="grid grid-cols-1 md:grid-cols-[1fr_2fr_auto] gap-2 items-center">
                    <Input value={item.time} onChange={(e) => handleAgendaChange(index, 'time', e.target.value)} placeholder="Time (e.g., 09:00 AM)" />
                    <Input value={item.title} onChange={(e) => handleAgendaChange(index, 'title', e.target.value)} placeholder="Agenda Item Title" />
                    <Button type="button" variant="destructive" size="icon" onClick={() => removeDynamicListItem('agenda', index)} disabled={formData.agenda.length <= 1}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
                <Button type="button" variant="outline" size="sm" onClick={() => addDynamicListItem('agenda', { time: '', title: '' })}><PlusCircle className="mr-2 h-4 w-4" />Add Agenda Item</Button>
              </div>

              <div className="flex items-center space-x-2 pt-4 border-t border-white/10">
                <input type="checkbox" id="featured" name="featured" checked={formData.featured} onChange={handleChange} className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary bg-gray-900/50"/>
                <Label htmlFor="featured">Featured Event</Label>
              </div>
            </form>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
              <Button type="submit" onClick={handleSubmit} disabled={loading}>
                {loading ? 'Saving...' : 'Save Changes'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      );
    };

    export default EventFormModal;