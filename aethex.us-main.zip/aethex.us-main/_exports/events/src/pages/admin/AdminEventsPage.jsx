import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { formatDate, formatTime } from '@/lib/utils';
import { PlusCircle, MoreHorizontal, Edit, Trash2, Users } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import EventFormModal from '@/pages/admin/EventFormModal';

const AdminEventsPage = () => {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState(null);
  const { toast } = useToast();

  const fetchEvents = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('aethex_events')
      .select('*, aethex_event_registrations(count)')
      .order('date', { ascending: false });

    if (error) {
      toast({ variant: 'destructive', title: 'Error fetching events', description: error.message });
      setEvents([]);
    } else {
      const formattedEvents = data.map(event => ({
        ...event,
        registered_count: event.aethex_event_registrations[0]?.count || 0,
      }));
      setEvents(formattedEvents);
    }
    setLoading(false);
  }, [toast]);

  useEffect(() => {
    fetchEvents();
  }, [fetchEvents]);

  const handleCreateNew = () => {
    setSelectedEvent(null);
    setIsModalOpen(true);
  };

  const handleEdit = (event) => {
    setSelectedEvent(event);
    setIsModalOpen(true);
  };

  const handleDelete = async (eventId) => {
    if (window.confirm('Are you sure you want to delete this event? This action cannot be undone.')) {
      const { error } = await supabase.from('aethex_events').delete().eq('id', eventId);
      if (error) {
        toast({ variant: 'destructive', title: 'Error deleting event', description: error.message });
      } else {
        toast({ variant: 'success', title: 'Event Deleted', description: 'The event has been successfully deleted.' });
        fetchEvents();
      }
    }
  };

  const onFormSuccess = () => {
    setIsModalOpen(false);
    fetchEvents();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white">Event Management</h1>
          <p className="text-gray-400 mt-1">Create, update, and manage all events.</p>
        </div>
        <Button onClick={handleCreateNew}>
          <PlusCircle className="mr-2 h-4 w-4" />
          Create Event
        </Button>
      </div>

      <div className="border border-white/10 rounded-lg overflow-hidden bg-gray-950/20 backdrop-blur-lg shadow-2xl shadow-black/40">
        <Table>
          <TableHeader>
            <TableRow className="border-b-white/10 hover:bg-transparent">
              <TableHead className="text-white/80">Title</TableHead>
              <TableHead className="text-white/80">Date</TableHead>
              <TableHead className="text-white/80">Location</TableHead>
              <TableHead className="text-center text-white/80">Registrations</TableHead>
              <TableHead className="text-right text-white/80">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan="5" className="text-center text-gray-400 py-16">Loading events...</TableCell>
              </TableRow>
            ) : events.length === 0 ? (
              <TableRow>
                <TableCell colSpan="5" className="text-center text-gray-400 py-16">No events found.</TableCell>
              </TableRow>
            ) : (
              events.map((event) => (
                <TableRow key={event.id} className="border-b-white/10 last:border-b-0 hover:bg-white/5 transition-colors duration-200">
                  <TableCell className="font-medium text-white">{event.title}</TableCell>
                  <TableCell className="text-gray-300">{formatDate(event.date)} at {formatTime(event.time)}</TableCell>
                  <TableCell className="text-gray-300">{event.location}</TableCell>
                  <TableCell className="text-center text-gray-300">
                    <div className="flex items-center justify-center gap-2">
                        <Users className="h-4 w-4 text-primary"/> 
                        <span>{event.registered_count} / {event.capacity}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0 data-[state=open]:bg-white/10">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-gray-900 border-white/10 text-white">
                        <DropdownMenuItem onClick={() => handleEdit(event)} className="hover:!bg-white/10 focus:!bg-white/10 cursor-pointer">
                          <Edit className="mr-2 h-4 w-4" />
                          <span>Edit</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleDelete(event.id)} className="hover:!bg-red-500/20 focus:!bg-red-500/20 text-red-400 cursor-pointer">
                          <Trash2 className="mr-2 h-4 w-4" />
                          <span>Delete</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
      <EventFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        eventData={selectedEvent}
        onSuccess={onFormSuccess}
      />
    </div>
  );
};

export default AdminEventsPage;