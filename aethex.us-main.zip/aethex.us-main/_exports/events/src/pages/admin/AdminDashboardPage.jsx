import React from 'react';
    import { Link } from 'react-router-dom';
    import { useAuth } from '@/contexts/SupabaseAuthContext';
    import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
    import { Calendar, Users, ArrowRight } from 'lucide-react';
    import { motion } from 'framer-motion';

    const AdminDashboardPage = () => {
        const { profile } = useAuth();

        const containerVariants = {
            hidden: { opacity: 0 },
            visible: {
                opacity: 1,
                transition: {
                    staggerChildren: 0.1
                }
            }
        };

        const itemVariants = {
            hidden: { y: 20, opacity: 0 },
            visible: {
                y: 0,
                opacity: 1
            }
        };

        return (
            <div>
                <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
                    <h1 className="text-4xl font-bold text-white mb-2">Welcome, <span className="text-primary">{profile?.username || 'Admin'}</span>!</h1>
                    <p className="text-lg text-gray-400 mb-10">This is your command center for AeThex Events.</p>
                </motion.div>
                
                <motion.div 
                    className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
                    variants={containerVariants}
                    initial="hidden"
                    animate="visible"
                >
                     <motion.div variants={itemVariants}>
                         <Card>
                            <CardHeader>
                                <CardTitle>Manage Events</CardTitle>
                                <CardDescription>Create, edit, and oversee all scheduled events.</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <Link to="/admin/events" className="flex items-center justify-between text-sm text-primary hover:text-primary/80 font-semibold transition-colors">
                                    Go to Events
                                    <ArrowRight className="h-4 w-4" />
                                </Link>
                            </CardContent>
                        </Card>
                     </motion.div>
                    <motion.div variants={itemVariants}>
                        <Card>
                            <CardHeader>
                                <CardTitle>Manage Users</CardTitle>
                                <CardDescription>View user data and manage site roles.</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <Link to="/admin/users" className="flex items-center justify-between text-sm text-primary hover:text-primary/80 font-semibold transition-colors">
                                   Go to Users
                                   <ArrowRight className="h-4 w-4" />
                                </Link>
                            </CardContent>
                        </Card>
                    </motion.div>
                </motion.div>
            </div>
        );
    };

    export default AdminDashboardPage;