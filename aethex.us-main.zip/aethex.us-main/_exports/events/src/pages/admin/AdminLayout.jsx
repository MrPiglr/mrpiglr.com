import React from 'react';
    import { Outlet, NavLink, Link, useNavigate, useLocation } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { LayoutDashboard, Calendar, Users, Settings, LogOut } from 'lucide-react';
    import AeThexLogo from '@/components/AeThexLogo';
    import { useAuth } from '@/contexts/SupabaseAuthContext';

    const AdminLayout = () => {
      const { signOut, profile } = useAuth();
      const navigate = useNavigate();
      const location = useLocation();

      const handleSignOut = async () => {
        await signOut();
        navigate('/');
      };

      const navItems = [
        { name: 'Dashboard', path: '/admin', icon: LayoutDashboard },
        { name: 'Events', path: '/admin/events', icon: Calendar },
        { name: 'Users', path: '/admin/users', icon: Users },
      ];

      return (
        <div className="min-h-screen text-gray-200 flex radial-gradient-background">
          <aside className="w-64 bg-black/30 border-r border-white/10 flex flex-col p-4 backdrop-blur-sm">
            <div className="p-4 mb-8">
              <Link to="/" className="flex items-center gap-2">
                {/* Using AeThexLogo component */}
                <AeThexLogo className="h-8 w-auto" />
                <span className="font-bold text-lg text-white">Events Admin</span>
              </Link>
            </div>
            <nav className="flex-grow space-y-2">
              {navItems.map((item) => (
                <NavLink
                  key={item.name}
                  to={item.path}
                  end={item.path === '/admin'}
                  className={({ isActive }) =>
                    `flex items-center px-4 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 ${
                      isActive
                        ? 'bg-primary/20 text-primary shadow-inner shadow-primary/20'
                        : 'text-gray-400 hover:bg-white/10 hover:text-white'
                    }`
                  }
                >
                  <item.icon className="h-5 w-5 mr-3" />
                  {item.name}
                </NavLink>
              ))}
            </nav>
            <div className="p-2">
               <div className="p-2 flex items-center gap-3 border-t border-white/10 pt-4">
                 <img 
                   src={profile?.avatar_url || `https://api.dicebear.com/7.x/bottts/svg?seed=${profile?.id}`}
                   alt={profile?.username || 'Admin'}
                   className="w-10 h-10 rounded-full object-cover border-2 border-primary/50"/>
                 <div>
                   <p className="font-semibold text-white">{profile?.username}</p>
                   <p className="text-xs text-primary/80 capitalize">{profile?.role}</p>
                 </div>
               </div>
               <button onClick={handleSignOut} className="w-full flex items-center mt-4 px-4 py-2.5 rounded-lg text-sm font-medium text-gray-400 hover:bg-red-500/10 hover:text-red-400 transition-colors">
                 <LogOut className="h-5 w-5 mr-3" />
                 Sign Out
               </button>
            </div>
          </aside>
          <div className="flex-1 flex flex-col">
            <main className="flex-1 p-8 lg:p-12 overflow-y-auto">
              <motion.div
                key={location.pathname}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.35 }}
              >
                <Outlet />
              </motion.div>
            </main>
          </div>
        </div>
      );
    };

    export default AdminLayout;