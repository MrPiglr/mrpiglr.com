import React, { useState, useEffect } from 'react';
    import { supabase } from '@/lib/customSupabaseClient';
    import { useSiteId } from '@/contexts/SiteIdContext';
    import { useToast } from '@/components/ui/use-toast';
    import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
    import { Badge } from '@/components/ui/badge';
    import { motion } from 'framer-motion';
    import { Users, Loader2 } from 'lucide-react';

    const AdminUsersPage = () => {
        const [users, setUsers] = useState([]);
        const [loading, setLoading] = useState(true);
        const { siteId } = useSiteId();
        const { toast } = useToast();

        useEffect(() => {
            const fetchUsers = async () => {
                if (!siteId) return;
                setLoading(true);
                
                const { data, error } = await supabase.rpc('get_all_users_for_site', { p_site_id: siteId });

                if (error) {
                    console.error('Error fetching users:', error);
                    toast({
                        variant: 'destructive',
                        title: 'Failed to fetch users',
                        description: error.message,
                    });
                } else {
                    setUsers(data);
                }
                setLoading(false);
            };

            fetchUsers();
        }, [siteId, toast]);

        const getRoleBadgeVariant = (role) => {
            switch (role) {
                case 'admin':
                case 'site_owner':
                case 'oversee':
                    return 'destructive';
                case 'member':
                    return 'secondary';
                default:
                    return 'default';
            }
        };

        return (
            <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
            >
                <div className="flex justify-between items-center mb-8">
                    <div>
                        <h1 className="text-4xl font-bold text-white flex items-center gap-3">
                            <Users className="w-10 h-10 text-primary" />
                            User Management
                        </h1>
                        <p className="text-lg text-gray-400 mt-2">View and manage users for this site.</p>
                    </div>
                </div>

                {loading ? (
                    <div className="flex justify-center items-center h-64">
                        <Loader2 className="w-8 h-8 text-primary animate-spin" />
                    </div>
                ) : (
                    <div className="bg-card border border-white/10 rounded-lg shadow-lg overflow-hidden">
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>User</TableHead>
                                    <TableHead>Email</TableHead>
                                    <TableHead>Role</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {users.map((user) => (
                                    <TableRow key={user.id}>
                                        <TableCell>
                                            <div className="flex items-center gap-3">
                                                <img
                                                    src={user.avatar_url || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.id}`}
                                                    alt={user.username}
                                                    className="w-10 h-10 rounded-full object-cover border-2 border-primary/50"
                                                />
                                                <div>
                                                    <p className="font-medium text-white">{user.username}</p>
                                                    <p className="text-sm text-gray-400">{user.full_name}</p>
                                                </div>
                                            </div>
                                        </TableCell>
                                        <TableCell className="text-gray-300">{user.email}</TableCell>
                                        <TableCell>
                                            <Badge variant={getRoleBadgeVariant(user.role)} className="capitalize">
                                                {user.role}
                                            </Badge>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </div>
                )}
            </motion.div>
        );
    };

    export default AdminUsersPage;