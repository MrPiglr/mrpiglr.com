import React from 'react';
import { Helmet } from 'react-helmet-async';
import DeveloperResources from '@/components/DeveloperResources';
import PageHeader from '@/components/PageHeader';

const DeveloperResourcesPage = () => {
  return (
    <>
      <Helmet>
        <title>Developer Resources - AeThex Events</title>
        <meta name="description" content="A curated list of essential tools, libraries, and resources for developers, provided by AeThex Events." />
      </Helmet>
      
      <PageHeader
        title="Developer's Toolkit"
        subtitle="A curated collection of essential tools and resources to boost your productivity and skills."
      />
      
      <div className="py-16">
        <DeveloperResources />
      </div>
    </>
  );
};

export default DeveloperResourcesPage;