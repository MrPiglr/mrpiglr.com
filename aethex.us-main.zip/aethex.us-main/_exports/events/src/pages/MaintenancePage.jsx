import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet-async';
import { motion, AnimatePresence } from 'framer-motion';
import { HardHat, Server, User, Calendar, Cpu, CheckCircle, Mail, Send } from 'lucide-react';
import AeThexLogo from '@/components/AeThexLogo';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/customSupabaseClient';

const CountdownTimer = ({ targetDate }) => {
  const calculateTimeLeft = () => {
    const difference = +new Date(targetDate) - +new Date();
    let timeLeft = {};

    if (difference > 0) {
      timeLeft = {
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60),
      };
    }
    return timeLeft;
  };

  const [timeLeft, setTimeLeft] = useState(calculateTimeLeft());

  useEffect(() => {
    const timer = setTimeout(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);
    return () => clearTimeout(timer);
  });

  const timerComponents = Object.keys(timeLeft).map((interval) => (
    <div key={interval} className="text-center">
      <span className="text-4xl md:text-6xl font-bold text-primary">{String(timeLeft[interval]).padStart(2, '0')}</span>
      <span className="block text-sm uppercase tracking-widest text-gray-400 mt-1">{interval}</span>
    </div>
  ));

  return (
    <div className="flex justify-center gap-4 md:gap-8">
      {timerComponents.length ? timerComponents : <span className="text-2xl font-semibold text-gray-300">We'll be back shortly!</span>}
    </div>
  );
};

const StatusUpdateFeed = ({ updates }) => {
  return (
    <div className="mt-8 space-y-4 max-h-60 overflow-y-auto pr-4 font-mono text-sm">
      {updates.map((update, index) => (
        <motion.div
          key={index}
          className="flex gap-4 items-start"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: index * 0.1 }}
        >
          <div className="text-primary pt-1"><CheckCircle className="w-4 h-4" /></div>
          <div>
            <p className="text-gray-400">[{new Date(update.timestamp).toLocaleTimeString()}]</p>
            <p className="text-white">{update.message}</p>
          </div>
        </motion.div>
      ))}
    </div>
  );
};

const affectedServices = [
  { name: 'Event Registration', icon: Calendar, status: 'Impacted' },
  { name: 'User Profiles', icon: User, status: 'Impacted' },
  { name: 'API Services', icon: Server, status: 'Degraded' },
  { name: 'Core Infrastructure', icon: Cpu, status: 'Operational' },
];

const MaintenancePage = ({ config }) => {
  const { toast } = useToast();
  const { 
    site_name = 'Our Site', 
    system_status_message = 'We are currently performing scheduled maintenance to improve our services. We apologize for any inconvenience.',
    maintenance_ends_at,
    status_updates = []
  } = config || {};

  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleNotifySubmit = async (e) => {
    e.preventDefault();
    if (!email) return;
    setIsSubmitting(true);
    
    // In a real scenario, you'd have a specific table for this.
    // We'll use 'newsletter_subscribers' as a placeholder.
    const { error } = await supabase
      .from('newsletter_subscribers')
      .insert({ email });

    setIsSubmitting(false);

    if (error) {
      toast({
        title: "Error",
        description: "This email is already on the list or there was a problem.",
        variant: "destructive",
      });
    } else {
      toast({
        title: "You're on the list!",
        description: "We'll notify you as soon as we're back online.",
      });
      setEmail('');
    }
  };


  return (
    <>
      <Helmet>
        <title>{site_name} - Under Maintenance</title>
        <meta name="description" content="Our site is currently down for scheduled maintenance. We'll be back online soon!" />
      </Helmet>
      <div className="min-h-screen bg-background text-white flex flex-col items-center justify-center p-4 font-['Courier_New',_monospace] relative overflow-hidden">
        <div className="absolute inset-0 bg-grid z-0 opacity-50"></div>
        <div className="absolute inset-0 z-0" style={{
            backgroundImage: 'radial-gradient(ellipse 80% 80% at 20% -20%, hsl(var(--primary) / 0.1), transparent), radial-gradient(ellipse 80% 80% at 80% 120%, hsl(var(--secondary) / 0.1), transparent)',
        }} />

        <motion.main 
          className="relative z-20 flex flex-col items-center text-center w-full max-w-4xl"
          initial="hidden"
          animate="visible"
          variants={{
             visible: { transition: { staggerChildren: 0.1 } }
          }}
        >
          <motion.div variants={{ hidden: { scale: 0.5, opacity: 0 }, visible: { scale: 1, opacity: 1, transition: { type: 'spring' } }}}>
            <AeThexLogo className="h-12 mb-8" />
          </motion.div>
          
          <motion.div variants={{ hidden: { y: 20, opacity: 0 }, visible: { y: 0, opacity: 1 }}} className="flex items-center gap-3 bg-primary/10 text-primary px-4 py-2 rounded-full border border-primary/20 mb-6">
            <HardHat className="w-5 h-5" />
            <span className="font-semibold">Scheduled Maintenance</span>
          </motion.div>

          <motion.h1 variants={{ hidden: { y: 20, opacity: 0 }, visible: { y: 0, opacity: 1 }}} className="text-4xl md:text-6xl font-bold tracking-tighter bg-clip-text text-transparent bg-gradient-to-br from-white to-gray-400">
            Upgrades in Progress
          </motion.h1>
          <motion.p variants={{ hidden: { y: 20, opacity: 0 }, visible: { y: 0, opacity: 1 }}} className="mt-4 text-lg text-gray-400 max-w-2xl mx-auto">
            {system_status_message}
          </motion.p>
          
          {maintenance_ends_at && (
            <motion.div variants={{ hidden: { y: 20, opacity: 0 }, visible: { y: 0, opacity: 1 }}} className="mt-12 w-full bg-card/50 border border-white/10 rounded-2xl p-8 backdrop-blur-sm shadow-2xl shadow-primary/5">
              <h2 className="text-lg font-semibold mb-6 text-gray-300 tracking-widest uppercase">Expected Completion</h2>
              <CountdownTimer targetDate={maintenance_ends_at} />
            </motion.div>
          )}

          <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8 w-full text-left">
            <motion.div variants={{ hidden: { y: 20, opacity: 0 }, visible: { y: 0, opacity: 1 }}} className="bg-card/50 border border-white/10 rounded-2xl p-6 backdrop-blur-sm">
              <h3 className="font-semibold text-lg mb-4 text-gray-300">Live Status Updates</h3>
              <div className="h-[2px] bg-gradient-to-r from-primary/50 to-secondary/50 mb-4"></div>
              <StatusUpdateFeed updates={status_updates.slice().reverse()} />
            </motion.div>

            <div className="flex flex-col gap-8">
              <motion.div variants={{ hidden: { y: 20, opacity: 0 }, visible: { y: 0, opacity: 1 }}} className="bg-card/50 border border-white/10 rounded-2xl p-6 backdrop-blur-sm">
                <h3 className="font-semibold text-lg mb-4 text-gray-300">Services Affected</h3>
                 <div className="space-y-3">
                    {affectedServices.map(service => (
                      <div key={service.name} className="flex justify-between items-center text-sm">
                        <div className="flex items-center gap-2">
                          <service.icon className="w-4 h-4 text-gray-400" />
                          <span className="text-gray-200">{service.name}</span>
                        </div>
                        <span className={`px-2 py-1 rounded-full text-xs font-bold ${service.status === 'Operational' ? 'bg-green-500/20 text-green-300' : 'bg-yellow-500/20 text-yellow-300'}`}>
                          {service.status}
                        </span>
                      </div>
                    ))}
                 </div>
              </motion.div>

              <motion.div variants={{ hidden: { y: 20, opacity: 0 }, visible: { y: 0, opacity: 1 }}} className="bg-card/50 border border-white/10 rounded-2xl p-6 backdrop-blur-sm">
                <h3 className="font-semibold text-lg mb-4 text-gray-300">Get Notified When We're Back</h3>
                 <form onSubmit={handleNotifySubmit} className="flex gap-2">
                   <Input 
                     type="email" 
                     placeholder="your.email@example.com"
                     className="bg-background/50 border-white/20"
                     value={email}
                     onChange={(e) => setEmail(e.target.value)}
                     disabled={isSubmitting}
                   />
                   <Button type="submit" variant="secondary" size="icon" disabled={isSubmitting}>
                     <Send className="w-4 h-4"/>
                   </Button>
                 </form>
              </motion.div>
            </div>
          </div>
        </motion.main>
      </div>
    </>
  );
};

export default MaintenancePage;