import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import AeThexLogo from './AeThexLogo';
import { Github, Twitter, Mail, Send } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { useToast } from './ui/use-toast';

const NewsletterSignup = () => {
  const { toast } = useToast();

  const handleSubmit = (e) => {
    e.preventDefault();
    toast({
      title: "🚧 Feature In Progress",
      description: "Newsletter signup isn't implemented yet, but stay tuned!",
    });
  };

  return (
    <div className="max-w-md">
      <p className="font-semibold text-white">Stay Updated</p>
      <p className="mt-2 text-sm text-gray-400">
        Subscribe to our newsletter to get the latest news, updates, and event announcements.
      </p>
      <form onSubmit={handleSubmit} className="mt-4 flex gap-2">
        <Input
          type="email"
          placeholder="Enter your email"
          className="flex-1 bg-gray-900/50 border-gray-700/50"
          required
        />
        <Button type="submit" size="icon">
          <Send className="h-4 w-4" />
        </Button>
      </form>
    </div>
  );
};


const Footer = () => {
  const footerSections = {
    'Company': [
      { name: 'About', path: '/about' },
      { name: 'News', path: '/blog' },
      { name: 'Sponsors', path: '/sponsors' },
    ],
    'Resources': [
      { name: 'Developer Toolkit', path: '/resources' },
      { name: 'FAQ', path: '/faq' },
      { name: 'Contact', path: '/contact' },
    ]
  };

  const socialLinks = [
    { name: 'Twitter', icon: <Twitter className="w-5 h-5" />, path: '#' },
    { name: 'GitHub', icon: <Github className="w-5 h-5" />, path: '#' },
    { name: 'Email', icon: <Mail className="w-5 h-5" />, path: 'mailto:hello@aethex.events' },
  ];

  return (
    <motion.footer
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5, delay: 0.5 }}
      className="bg-transparent text-white mt-24 border-t border-white/10"
    >
      <div className="container mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-1 flex flex-col items-start">
             <AeThexLogo className="h-8" />
             <p className="mt-4 text-sm text-gray-400">The premier destination for tech innovators and creators.</p>
          </div>
          
          <div className="lg:col-span-3 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {Object.entries(footerSections).map(([title, links]) => (
                <div key={title}>
                  <p className="font-semibold text-white">{title}</p>
                  <ul className="mt-4 space-y-2">
                    {links.map((link) => (
                      <li key={link.name}>
                        <Link to={link.path} className="text-sm text-gray-400 hover:text-primary transition-colors">
                          {link.name}
                        </Link>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
              <NewsletterSignup />
          </div>
        </div>

        <div className="mt-12 flex flex-col md:flex-row justify-between items-center gap-4 border-t border-white/10 pt-8">
          <p className="text-sm text-gray-500 order-2 md:order-1">
            &copy; {new Date().getFullYear()} AeThex Events. A division of AeThex, Inc. All rights reserved.
          </p>
          <div className="flex justify-center gap-6 order-1 md:order-2">
            {socialLinks.map((social) => (
              <a key={social.name} href={social.path} className="text-gray-500 hover:text-primary transition-colors">
                <span className="sr-only">{social.name}</span>
                {social.icon}
              </a>
            ))}
          </div>
        </div>
      </div>
    </motion.footer>
  );
};

export default Footer;