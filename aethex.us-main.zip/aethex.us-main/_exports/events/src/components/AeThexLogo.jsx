import React from 'react';
import { useLocation } from 'react-router-dom';

const AeThexLogo = ({ className, forceLight = false, showText = true }) => {
  const location = useLocation();
  const isAdminRoute = location.pathname.startsWith('/admin');
  const textColor = forceLight || !isAdminRoute ? 'white' : 'black';

  return (
    <div className={`flex items-center ${className}`}>
      <img
        src="https://horizons-cdn.hostinger.com/dd582fba-3b13-4502-bbc3-c6c66a980f8a/8fe16181293ef75161b902f6790febc6.png"
        alt="AeThex Logo"
        className="h-full object-contain"
        aria-label="AeThex Logo"
      />
      {showText && (
        <span
          style={{ color: textColor }}
          className="ml-2 font-bold text-lg"
        >
          AETHEX
        </span>
      )}
    </div>
  );
};

export default AeThexLogo;