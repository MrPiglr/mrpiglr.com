import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import AeThexLogo from '@/components/AeThexLogo';

const LoadingScreen = () => {
  const [progress, setProgress] = useState(0);
  const [message, setMessage] = useState('Booting up core systems...');

  const messages = [
    'Connecting to the AeThex network...',
    'Calibrating event streams...',
    'Unlocking achievements cache...',
    'Polishing pixels...',
    'Finalizing experience...',
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        const next = prev + Math.random() * 10;
        return Math.min(next, 100);
      });
    }, 400);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    let messageIndex = 0;
    const messageInterval = setInterval(() => {
      if (messageIndex < messages.length - 1) {
        messageIndex++;
        setMessage(messages[messageIndex]);
      } else {
        clearInterval(messageInterval);
      }
    }, 1000);

    return () => clearInterval(messageInterval);
  }, [messages]);

  const barVariants = {
    initial: {
      y: "50%",
      opacity: 0.5
    },
    animate: {
      y: ["50%", "-50%", "50%"],
      opacity: [0.5, 1, 0.5],
      transition: {
        duration: 1.5,
        repeat: Infinity,
        ease: "easeInOut"
      }
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-black text-white font-mono">
      <div className="text-center w-full max-w-md p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, ease: "backOut" }}
          className="relative inline-block mb-8"
        >
          <div className="w-32 h-32 bg-primary/10 rounded-2xl flex items-center justify-center shadow-lg shadow-primary/10 border border-primary/20">
            <AeThexLogo className="h-16 w-16" forceLight={true} showText={false} />
          </div>
          <div className="absolute inset-0 border-2 border-primary/30 rounded-2xl animate-ping opacity-50"></div>
        </motion.div>
        
        <div className="h-8 flex justify-center items-end gap-1 mb-4">
          {[...Array(7)].map((_, i) => (
             <motion.div
                key={i}
                className="w-4 h-full bg-gradient-to-b from-primary to-secondary rounded-full"
                variants={barVariants}
                animate="animate"
                transition={{ ...barVariants.animate.transition, delay: i * 0.1 }}
             />
          ))}
        </div>

        <div className="w-full bg-gray-800 rounded-full h-2 mb-2 overflow-hidden border border-gray-700">
          <motion.div
            className="bg-primary h-full rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.4, ease: 'linear' }}
          />
        </div>
        <p className="text-primary text-sm mb-4">{Math.round(progress)}%</p>
        
        <AnimatePresence mode="wait">
            <motion.p 
              key={message}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className="text-gray-400 text-sm tracking-widest"
            >
              {message}
            </motion.p>
        </AnimatePresence>

      </div>
    </div>
  );
};

export default LoadingScreen;