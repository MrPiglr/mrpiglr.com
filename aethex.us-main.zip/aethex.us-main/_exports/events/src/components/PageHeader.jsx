import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles } from 'lucide-react';

const PageHeader = ({ title, subtitle, children }) => {
  return (
    <motion.div
      className="text-center py-16 mb-12 bg-grid-slate rounded-2xl relative overflow-hidden"
      initial="hidden"
      animate="visible"
      variants={{
        hidden: { opacity: 0 },
        visible: { opacity: 1, transition: { staggerChildren: 0.2 } },
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-b from-background/30 via-background/70 to-background z-10"></div>
       <motion.div 
            className="absolute inset-0 z-0"
            style={{
                backgroundImage: 'radial-gradient(ellipse 50% 40% at 50% 0%, hsl(var(--primary) / 0.1), transparent)',
            }}
        />
      <div className="relative z-20">
        <motion.div
          variants={{
            hidden: { opacity: 0, y: -20 },
            visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut' } },
          }}
        >
          <Sparkles className="w-8 h-8 text-primary mx-auto mb-4" />
        </motion.div>
        <motion.h1
          className="text-4xl md:text-6xl font-bold text-white tracking-tight"
          variants={{
            hidden: { opacity: 0, y: 20 },
            visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut', delay: 0.1 } },
          }}
        >
          {title}
        </motion.h1>
        {subtitle && (
          <motion.p
            className="mt-4 text-lg text-gray-400 max-w-3xl mx-auto"
            variants={{
              hidden: { opacity: 0, y: 20 },
              visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut', delay: 0.2 } },
            }}
          >
            {subtitle}
          </motion.p>
        )}
        {children && (
            <motion.div
                variants={{
                    hidden: { opacity: 0, y: 20 },
                    visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: 'easeOut', delay: 0.3 } },
                }}
                className="mt-8"
            >
                {children}
            </motion.div>
        )}
      </div>
    </motion.div>
  );
};

export default PageHeader;