import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, MapPin, Star, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { formatDate } from '@/lib/utils';

const cardVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { duration: 0.5, ease: "easeOut" }
  },
  exit: { 
    opacity: 0, 
    y: -30,
    transition: { duration: 0.3, ease: "easeIn" }
  }
};

const EventCard = ({ event, onSelectEvent, getCategoryColor, getCategoryLabel }) => {
  return (
    <motion.div
      variants={cardVariants}
      whileHover={{ y: -8 }}
      transition={{ type: 'spring', stiffness: 300, damping: 15 }}
      className="group relative"
      layout
    >
      <div className="bg-card backdrop-blur-sm rounded-2xl border border-white/10 overflow-hidden group-hover:border-primary/80 transition-all duration-300 h-full flex flex-col shadow-lg hover:shadow-primary/10">
        <div className="relative h-48 overflow-hidden">
          <div className={`absolute inset-0 bg-gradient-to-br ${getCategoryColor(event.category)} opacity-20 group-hover:opacity-40 transition-opacity duration-300`}></div>
          <img
            className="w-full h-full object-cover opacity-70 group-hover:opacity-100 group-hover:scale-105 transition-all duration-500" 
            alt={`${event.title} event banner`}
            src={event.image_url || `https://images.unsplash.com/photo-1540575467063-178a50c2df87?q=80&w=2070&auto=format&fit=crop&ixid=${event.id}`} 
          />
          <div className="absolute top-4 left-4">
            <span className="bg-black/60 backdrop-blur-sm text-white px-3 py-1 rounded-full text-xs font-semibold border border-white/20">
              {getCategoryLabel(event.category)}
            </span>
          </div>
          {event.featured && (
            <motion.div 
              initial={{ scale: 0, rotate: -45 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ delay: 0.5, type: 'spring' }}
              className="absolute top-4 right-4 z-10"
            >
              <div className="bg-secondary/80 backdrop-blur-sm text-white px-3 py-1 rounded-full text-xs font-semibold flex items-center border border-secondary/50">
                <Star className="w-3 h-3 mr-1" />
                Featured
              </div>
            </motion.div>
          )}
        </div>

        <div className="p-6 flex flex-col flex-grow">
          <h2 className="text-xl font-bold text-white mb-2 group-hover:text-primary transition-colors">
            {event.title}
          </h2>
          <p className="text-gray-400 mb-4 text-sm line-clamp-2 flex-grow">
            {event.description}
          </p>

          <div className="space-y-2 mb-6 text-sm">
            <div className="flex items-center text-gray-400">
              <Calendar className="w-4 h-4 mr-2 text-primary/70" />
              <span>{formatDate(event.date)}</span>
            </div>
            <div className="flex items-center text-gray-400">
              <MapPin className="w-4 h-4 mr-2 text-primary/70" />
              <span>{event.location}</span>
            </div>
          </div>

          <div className="flex items-center justify-between mt-auto">
            <div className="text-2xl font-bold text-white">
              {event.price === 0 ? 'Free' : `$${event.price}`}
            </div>
            <Button
              onClick={() => onSelectEvent(event)}
              className="bg-primary text-background font-bold hover:bg-primary/90 px-4 py-2 text-sm"
            >
              <span>View Details</span>
              <motion.div
                className="inline-block"
                whileHover={{ x: 4 }}
              >
                <ArrowRight className="w-4 h-4 ml-2" />
              </motion.div>
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default EventCard;