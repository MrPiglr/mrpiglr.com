import React, {useState} from 'react';
    import { motion, AnimatePresence } from 'framer-motion';
    import { Calendar, Clock, MapPin, Users, X, Loader2, Mic, List, Navigation, Ticket, Star, CheckCircle } from 'lucide-react';
    import { Button } from '@/components/ui/button';
    import { formatDate, formatTime } from '@/lib/utils';
    import ReactMarkdown from 'react-markdown';
    import { Card, CardContent } from '@/components/ui/card';

    const backdropVariants = {
      visible: { opacity: 1 },
      hidden: { opacity: 0 }
    };

    const modalVariants = {
      hidden: { opacity: 0, scale: 0.9, y: 50 },
      visible: { 
        opacity: 1, 
        scale: 1, 
        y: 0,
        transition: { type: 'spring', damping: 25, stiffness: 200 }
      },
      exit: { 
        opacity: 0, 
        scale: 0.9, 
        y: 50,
        transition: { duration: 0.2 }
      }
    };

    const TicketTypeCard = ({ ticket, onSelect, isSelected }) => (
        <motion.div 
            className={`p-4 rounded-lg border-2 cursor-pointer transition-all duration-300 ${isSelected ? 'border-primary bg-primary/10' : 'border-gray-800 bg-gray-900/50 hover:border-primary/50'}`}
            onClick={onSelect}
            whileHover={{ y: -5 }}
        >
            <div className="flex justify-between items-start">
                <div>
                    <h4 className="font-bold text-lg text-white">{ticket.name}</h4>
                    <p className="text-gray-400 text-sm">{ticket.benefits.split('\n')[0]}</p>
                </div>
                <div className="text-2xl font-bold text-primary">${ticket.price}</div>
            </div>
            <AnimatePresence>
            {isSelected && (
                <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-4 space-y-2 text-sm text-gray-300 overflow-hidden"
                >
                    {ticket.benefits.split('\n').map((benefit, i) => (
                        <div key={i} className="flex items-center gap-2">
                           <CheckCircle className="w-4 h-4 text-green-400 flex-shrink-0" />
                           <span>{benefit}</span>
                        </div>
                    ))}
                </motion.div>
            )}
            </AnimatePresence>
        </motion.div>
    );

    const EventDetailModal = ({ event, onClose, onRegister, onUnregister, isRegistered, getCategoryColor, getCategoryLabel, isLoading }) => {
      const [selectedTicket, setSelectedTicket] = useState(event.ticket_types && event.ticket_types.length > 0 ? event.ticket_types[0] : { price: event.price });
      
      const handleRegisterClick = () => {
        // Here you would pass which ticket type is being purchased
        onRegister(event.id, selectedTicket);
      };
      
      return (
        <motion.div
          variants={backdropVariants}
          initial="hidden"
          animate="visible"
          exit="hidden"
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={onClose}
        >
          <motion.div
            variants={modalVariants}
            className="bg-gray-950/80 rounded-2xl border border-gray-800 max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl shadow-primary/10"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative">
              <button
                onClick={onClose}
                className="absolute top-4 right-4 z-20 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="relative h-64 overflow-hidden rounded-t-2xl">
                <div className={`absolute inset-0 bg-gradient-to-br ${getCategoryColor(event.category)} opacity-30`}></div>
                <img
                  className="w-full h-full object-cover" 
                  alt={`${event.title} detailed view`}
                  src={event.image_url || `https://images.unsplash.com/photo-1523580494863-6f3031224c94?q=80&w=2070&auto=format&fit=crop&ixid=${event.id}`}
                />
                <motion.div 
                  initial={{ y: 20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.2, duration: 0.5 }}
                  className="absolute bottom-6 left-6"
                >
                  <span className="bg-black/60 backdrop-blur-sm text-white px-4 py-2 rounded-full font-medium border border-white/20">
                    {getCategoryLabel(event.category)}
                  </span>
                </motion.div>
              </div>

              <div className="p-8">
                <div className="flex flex-col lg:flex-row gap-8">
                  <div className="flex-1">
                    <h1 className="text-3xl font-bold text-white mb-2">{event.title}</h1>
                    <p className="text-gray-400 mb-6">{event.description}</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                      <div className="space-y-3 bg-gray-900/40 p-4 rounded-lg border border-white/10">
                          <div className="flex items-center text-gray-300"><Calendar className="w-5 h-5 mr-3 text-primary" /><span>{formatDate(event.date)}</span></div>
                          <div className="flex items-center text-gray-300"><Clock className="w-5 h-5 mr-3 text-primary" /><span>{formatTime(event.time)}</span></div>
                          <div className="flex items-center text-gray-300"><MapPin className="w-5 h-5 mr-3 text-primary" /><span>{event.location}</span></div>
                          <div className="flex items-center text-gray-300"><Users className="w-5 h-5 mr-3 text-primary" /><span>{event.aethex_event_registrations[0]?.count || 0}/{event.capacity} registered</span></div>
                          {event.map_url && (
                             <a href={event.map_url} target="_blank" rel="noopener noreferrer" className="flex items-center text-primary hover:underline"><Navigation className="w-5 h-5 mr-3"/><span>View on Map</span></a>
                          )}
                      </div>
                      
                      {event.speakers && event.speakers.length > 0 && (
                        <div className="bg-gray-900/40 p-4 rounded-lg border border-white/10">
                          <h2 className="text-lg font-semibold text-white mb-3 flex items-center"><Mic className="w-5 h-5 mr-2 text-primary" />Speakers</h2>
                          <ul className="space-y-2 text-gray-300">
                            {event.speakers.map((speaker, index) => <li key={index} className="flex items-center"><div className="w-1.5 h-1.5 bg-primary rounded-full mr-3"></div>{speaker}</li>)}
                          </ul>
                        </div>
                      )}
                    </div>
                    
                    <div className="prose prose-invert max-w-none prose-p:text-gray-300 prose-headings:text-white mb-8">
                        <ReactMarkdown>{event.full_description}</ReactMarkdown>
                    </div>

                    {event.agenda && event.agenda.length > 0 && (
                      <div className="mb-8">
                        <h2 className="text-xl font-semibold text-white mb-4 flex items-center"><List className="w-5 h-5 mr-2 text-primary"/>Agenda</h2>
                        <div className="space-y-3">
                          {event.agenda.map((item, index) => (
                            <div key={index} className="flex items-start gap-4 p-4 bg-gray-900/50 rounded-lg border border-gray-800 hover:border-primary/50 transition-colors">
                              <div className="text-primary font-semibold min-w-[4rem]">{item.time}</div>
                              <div className="text-gray-300 font-medium">{item.title}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="lg:w-80 flex-shrink-0">
                    <Card className="sticky top-6">
                      <CardContent className="p-6">
                        <h3 className="text-xl font-bold text-white mb-4 flex items-center"><Ticket className="w-6 h-6 mr-2 text-primary"/> Get Your Ticket</h3>
                        
                        <div className="space-y-3 mb-6">
                          {event.ticket_types && event.ticket_types.length > 0 ? (
                            event.ticket_types.map(ticket => (
                              <TicketTypeCard
                                key={ticket.name}
                                ticket={ticket}
                                onSelect={() => setSelectedTicket(ticket)}
                                isSelected={selectedTicket?.name === ticket.name}
                              />
                            ))
                          ) : (
                            <div className="text-center mb-6">
                              <div className="text-3xl font-bold text-white mb-2">{event.price === 0 ? 'Free' : `$${event.price}`}</div>
                            </div>
                          )}
                        </div>
                        
                        <div className="mb-6">
                          <div className="flex justify-between text-sm text-gray-400 mb-2">
                            <span>Availability</span>
                            <span>{event.capacity - (event.aethex_event_registrations[0]?.count || 0)} spots left</span>
                          </div>
                          <div className="w-full bg-gray-700 rounded-full h-2.5">
                            <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: `${((event.aethex_event_registrations[0]?.count || 0) / event.capacity) * 100}%` }}
                              transition={{ duration: 1, ease: 'easeOut' }}
                              className="bg-primary h-2.5 rounded-full"
                            ></motion.div>
                          </div>
                        </div>

                        {isRegistered ? (
                          <div className="space-y-3">
                            <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4 text-center">
                              <div className="text-green-400 font-semibold">✓ Registered</div>
                              <div className="text-green-300 text-sm mt-1">You're all set!</div>
                            </div>
                            <Button onClick={() => onUnregister(event.id)} variant="outline" className="w-full border-red-500/30 text-red-400 hover:bg-red-500/10 hover:text-red-300" disabled={isLoading}>
                               {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                              Cancel Registration
                            </Button>
                          </div>
                        ) : (
                          <Button onClick={handleRegisterClick} className="w-full bg-primary hover:bg-primary/90 text-white py-3 text-base" disabled={(event.aethex_event_registrations[0]?.count || 0) >= event.capacity || isLoading}>
                            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                            {(event.aethex_event_registrations[0]?.count || 0) >= event.capacity ? 'Event Full' : 'Register Now'}
                          </Button>
                        )}
                        <div className="mt-4 text-xs text-gray-500 text-center">Registration confirmation will be sent via email.</div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      );
    };

    export default EventDetailModal;