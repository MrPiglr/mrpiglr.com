import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Quote } from 'lucide-react';

const testimonials = [
  {
    quote: "AeThex Events are a game-changer. The quality of speakers and networking opportunities is unmatched. I left inspired and with a notebook full of ideas.",
    name: 'Elena Rodriguez',
    title: 'Lead Developer, Nova Solutions',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=1961&auto=format&fit=crop'
  },
  {
    quote: "The workshops alone were worth the price of admission. Truly hands-on, practical knowledge I could apply to my projects the very next day.",
    name: 'Ben Carter',
    title: 'UX/UI Designer, Creative Canvas',
    avatar: 'https://images.unsplash.com/photo-1544723795-3fb6469f5b39?q=80&w=1889&auto=format&fit=crop'
  },
  {
    quote: "I've been to many tech conferences, but AeThex has a special energy. It feels less like a conference and more like a community of innovators.",
    name: 'Aisha Khan',
    title: 'Data Scientist, Apex Analytics',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=1964&auto=format&fit=crop'
  },
];

const Testimonials = () => {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
    }, 7000);
    return () => clearTimeout(timer);
  }, [index]);

  return (
    <div className="w-full">
      <motion.div
        className="text-center mb-16"
        variants={{
          hidden: { opacity: 0, y: 20 },
          visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
        }}
      >
        <h2 className="text-4xl md:text-5xl font-bold text-white tracking-tight">What Our Community Says</h2>
        <p className="mt-4 text-lg text-gray-400 max-w-3xl mx-auto">
          Hear from past attendees who have experienced the magic of an AeThex event.
        </p>
      </motion.div>

      <div className="relative h-80 md:h-64 flex items-center justify-center">
        <AnimatePresence mode="wait">
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -30 }}
            transition={{ duration: 0.5 }}
            className="text-center max-w-3xl mx-auto"
          >
            <Quote className="w-12 h-12 text-primary mx-auto mb-4" />
            <p className="text-xl md:text-2xl text-gray-200 italic leading-relaxed">
              "{testimonials[index].quote}"
            </p>
            <div className="mt-6 flex items-center justify-center gap-4">
              <img src={testimonials[index].avatar} alt={testimonials[index].name} className="w-12 h-12 rounded-full object-cover border-2 border-primary/50"/>
              <div>
                <p className="font-bold text-white">{testimonials[index].name}</p>
                <p className="text-gray-400 text-sm">{testimonials[index].title}</p>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
      <div className="flex justify-center mt-8 space-x-3">
        {testimonials.map((_, i) => (
          <button
            key={i}
            onClick={() => setIndex(i)}
            className="w-2 h-2 rounded-full transition-all duration-300"
            style={{ backgroundColor: index === i ? 'hsl(var(--primary))' : 'hsl(var(--muted))' }}
          />
        ))}
      </div>
    </div>
  );
};

export default Testimonials;