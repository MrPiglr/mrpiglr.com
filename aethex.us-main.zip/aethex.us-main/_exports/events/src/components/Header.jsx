import React, { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { LogIn, User, LogOut, Ticket, Gem, UserPlus, Sparkles, X, Menu, Shield, Trophy, HelpCircle, Mail, BookOpen, HeartHandshake as Handshake, Users, Code } from 'lucide-react';
import AeThexLogo from '@/components/AeThexLogo';

const Header = ({ onAuthClick, onPassportClick }) => {
  const { user, profile, signOut } = useAuth();
  const navigate = useNavigate();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const isAdmin = profile && ['admin', 'site_owner', 'oversee'].includes(profile.role);
  const avatarUrl = profile?.avatar_url || `https://api.dicebear.com/7.x/bottts/svg?seed=${user?.id || 'guest'}`;

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const navLinks = [
    { to: '/about', text: 'About', icon: <Sparkles className="mr-2 h-4 w-4" /> },
    { to: '/sponsors', text: 'Sponsors', icon: <Handshake className="mr-2 h-4 w-4" /> },
    { to: '/resources', text: 'Resources', icon: <Code className="mr-2 h-4 w-4" /> },
    { to: '/blog', text: 'News', icon: <BookOpen className="mr-2 h-4 w-4" /> },
  ];

  const MobileNavLink = ({ to, children }) => (
    <NavLink
      to={to}
      className={({ isActive }) =>
        `flex items-center w-full px-4 py-3 text-lg rounded-md transition-colors ${
          isActive ? 'bg-primary/10 text-primary' : 'text-gray-300 hover:bg-primary/10 hover:text-primary'
        }`
      }
      onClick={() => setIsMenuOpen(false)}
    >
      {children}
    </NavLink>
  );

  const DesktopNavLink = ({ to, children }) => (
     <Button asChild variant="ghost" className="text-gray-300 hover:bg-primary/10 hover:text-primary data-[active=true]:bg-primary/10 data-[active=true]:text-primary">
       <NavLink to={to}>{children}</NavLink>
     </Button>
  )

  const UserMenu = ({ isMobile = false }) => (
    <div className={`${isMobile ? 'mt-4 w-full' : 'relative'}`}>
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.2 }}
        className="flex items-center"
      >
        <div className={`flex items-center gap-4 ${isMobile ? 'flex-col w-full' : ''}`}>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className={`flex items-center gap-2 ${isMobile ? 'w-full justify-start p-4' : 'p-2'}`}>
                <div className="relative h-10 w-10 rounded-full p-0 transition-transform duration-200 hover:scale-105">
                  <img className="h-10 w-10 rounded-full object-cover border-2 border-primary" alt={profile?.username || 'User Avatar'} src={avatarUrl} />
                </div>
                <div className="text-left">
                  <p className="font-semibold text-sm">{profile?.username || user.email}</p>
                  <div className="flex items-center text-xs text-gray-400">
                    <Gem className="w-3 h-3 mr-1 text-primary" />
                    <span>{profile?.loyalty_points || 0} Points</span>
                  </div>
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56" align="end" forceMount>
              <DropdownMenuLabel>
                <p className="text-base font-semibold leading-none">{profile?.username}</p>
                <p className="text-xs leading-none text-gray-400 mt-1">{profile?.email}</p>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem asChild>
                <Link to="/my-events" className="flex items-center">
                  <Ticket className="mr-2 h-4 w-4" />
                  <span>My Events</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild>
                <Link to="/my-achievements" className="flex items-center">
                  <Trophy className="mr-2 h-4 w-4" />
                  <span>My Achievements</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={onPassportClick}>
                <User className="mr-2 h-4 w-4" />
                <span>My Passport</span>
              </DropdownMenuItem>
              {isAdmin && (
                <DropdownMenuItem asChild>
                  <Link to="/admin" className="flex items-center">
                    <Shield className="mr-2 h-4 w-4" />
                    <span>Admin Dashboard</span>
                  </Link>
                </DropdownMenuItem>
              )}
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleSignOut} className="text-red-400 focus:text-red-300">
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </motion.div>
    </div>
  );

  const AuthButtons = ({ isMobile = false }) => (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.2 }}
      className={`flex gap-2 ${isMobile ? 'flex-col w-full' : ''}`}
    >
      <Button variant="outline" onClick={onAuthClick} className={`${isMobile ? 'w-full' : ''}`}>
        <LogIn className="mr-2 h-4 w-4" />
        Sign In
      </Button>
      <Button onClick={onAuthClick} className={`${isMobile ? 'w-full' : ''}`}>
        <UserPlus className="mr-2 h-4 w-4" />
        Sign Up
      </Button>
    </motion.div>
  );

  return (
    <>
      <header className="py-4 px-6 fixed top-0 left-0 right-0 z-40 bg-black/50 backdrop-blur-lg border-b border-white/10">
        <div className="container mx-auto flex justify-between items-center">
          <Link to="/" className="flex items-center gap-2" onClick={() => setIsMenuOpen(false)}>
            <AeThexLogo className="h-8 w-auto" />
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-white">Events</h1>
            </div>
          </Link>
          <nav className="hidden md:flex items-center gap-1">
            {navLinks.map(link => (
              <DesktopNavLink key={link.to} to={link.to}>{link.text}</DesktopNavLink>
            ))}
             <DropdownMenu>
              <DropdownMenuTrigger asChild>
                 <Button variant="ghost" className="text-gray-300 hover:bg-primary/10 hover:text-primary">More</Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem asChild><Link to="/faq" className="flex items-center"><HelpCircle className="mr-2 h-4 w-4" />FAQ</Link></DropdownMenuItem>
                <DropdownMenuItem asChild><Link to="/contact" className="flex items-center"><Mail className="mr-2 h-4 w-4" />Contact</Link></DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <div className="border-l border-gray-700 h-6 mx-2"></div>
            <AnimatePresence mode="wait">
              {user ? <UserMenu key="user-menu" /> : <AuthButtons key="auth-buttons" />}
            </AnimatePresence>
          </nav>
          <div className="md:hidden">
            <Button variant="ghost" size="icon" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>
      </header>
      
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-30 bg-black/80 backdrop-blur-sm md:hidden"
            onClick={() => setIsMenuOpen(false)}
          >
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: '0%' }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', stiffness: 300, damping: 30 }}
              className="fixed top-0 right-0 h-full w-4/5 max-w-sm bg-background p-6 pt-24 shadow-2xl"
              onClick={e => e.stopPropagation()}
            >
              <div className="flex flex-col h-full">
                <nav className="flex flex-col gap-4">
                  {navLinks.map(link => (
                    <MobileNavLink key={link.to} to={link.to}>{link.icon}{link.text}</MobileNavLink>
                  ))}
                  <MobileNavLink to="/faq"><HelpCircle className="mr-2 h-4 w-4" />FAQ</MobileNavLink>
                  <MobileNavLink to="/contact"><Mail className="mr-2 h-4 w-4" />Contact</MobileNavLink>
                </nav>
                <div className="border-t border-gray-700 my-6"></div>
                <div className="flex flex-col items-center gap-4 py-4">
                    {user ? <UserMenu isMobile={true} /> : <AuthButtons isMobile={true} />}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
};

export default Header;