import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from './ui/card';
import { Linkedin, Twitter } from 'lucide-react';

const speakers = [
  {
    name: 'Dr. Evelyn Reed',
    title: 'Lead AI Ethicist, QuantumLeap',
    topic: 'The Future of Ethical AI',
    image: 'https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?q=80&w=1887&auto=format&fit=crop',
  },
  {
    name: 'Jaxon "Glitch" Hayes',
    title: 'Principal Security Engineer, Cyberia',
    topic: 'Next-Gen Cyber Defense',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=1887&auto=format&fit=crop',
  },
  {
    name: 'Kenji Tanaka',
    title: 'Head of Robotics, InnovateX',
    topic: 'Human-Robot Collaboration',
    image: 'https://images.unsplash.com/photo-1548142813-c348350df52b?q=80&w=1889&auto=format&fit=crop',
  },
  {
    name: 'Lena Petrova',
    title: 'Quantum Computing Pioneer, FutureForge',
    topic: 'The Quantum Revolution',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=1887&auto=format&fit=crop',
  },
   {
    name: 'Marco Diaz',
    title: 'Senior AR/VR Architect, NexusPrime',
    topic: 'Building the Metaverse',
    image: 'https://images.unsplash.com/photo-1583195764338-23e08c6954b3?q=80&w=2070&auto=format&fit=crop',
  },
];

const variants = {
  enter: (direction) => ({
    x: direction > 0 ? 1000 : -1000,
    opacity: 0,
  }),
  center: {
    zIndex: 1,
    x: 0,
    opacity: 1,
  },
  exit: (direction) => ({
    zIndex: 0,
    x: direction < 0 ? 1000 : -1000,
    opacity: 0,
  }),
};

const FeaturedSpeakers = () => {
  const [[page, direction], setPage] = useState([0, 0]);
  
  const paginate = (newDirection) => {
    setPage([(page + newDirection + speakers.length) % speakers.length, newDirection]);
  };

  useEffect(() => {
    const interval = setInterval(() => {
      paginate(1);
    }, 5000);
    return () => clearInterval(interval);
  }, [page]);


  return (
    <div className="w-full">
      <motion.div
        className="text-center mb-16"
        variants={{
          hidden: { opacity: 0, y: 20 },
          visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
        }}
      >
        <h2 className="text-4xl md:text-5xl font-bold text-white tracking-tight">Featured Speakers</h2>
        <p className="mt-4 text-lg text-gray-400 max-w-3xl mx-auto">
          Learn from the brightest minds in technology. Our speakers are pioneers, researchers, and visionaries shaping the future.
        </p>
      </motion.div>

      <div className="relative h-[450px] md:h-[400px] overflow-hidden">
        <AnimatePresence initial={false} custom={direction}>
          <motion.div
            key={page}
            custom={direction}
            variants={variants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{
              x: { type: 'spring', stiffness: 300, damping: 30 },
              opacity: { duration: 0.2 },
            }}
            className="absolute w-full h-full"
          >
            <Card className="bg-card/50 backdrop-blur-sm border-white/10 w-full h-full">
              <CardContent className="p-0 flex flex-col md:flex-row h-full">
                <div className="md:w-1/3 h-64 md:h-full">
                  <img
                    src={speakers[page].image}
                    alt={speakers[page].name}
                    className="w-full h-full object-cover object-top rounded-t-xl md:rounded-l-xl md:rounded-t-none"
                  />
                </div>
                <div className="md:w-2/3 p-8 flex flex-col justify-center">
                  <p className="text-primary font-bold text-sm uppercase tracking-wider">{speakers[page].topic}</p>
                  <h3 className="text-3xl font-bold text-white mt-2">{speakers[page].name}</h3>
                  <p className="text-gray-400 mt-1">{speakers[page].title}</p>
                  <div className="flex gap-4 mt-6">
                    <motion.a href="#" whileHover={{scale: 1.1}} className="text-gray-500 hover:text-primary"><Twitter /></motion.a>
                    <motion.a href="#" whileHover={{scale: 1.1}} className="text-gray-500 hover:text-primary"><Linkedin /></motion.a>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-2 z-10">
          {speakers.map((_, i) => (
            <button
              key={i}
              onClick={() => setPage([i, i > page ? 1 : -1])}
              className={`w-2.5 h-2.5 rounded-full transition-colors ${
                page === i ? 'bg-primary' : 'bg-gray-600 hover:bg-gray-400'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default FeaturedSpeakers;