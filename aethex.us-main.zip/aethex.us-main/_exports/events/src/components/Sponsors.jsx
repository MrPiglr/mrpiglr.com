import React from 'react';
import { motion } from 'framer-motion';

const sponsors = [
  { name: "QuantumLeap", description: "QuantumLeap logo" },
  { name: "Cyberia", description: "Cyberia logo" },
  { name: "InnovateX", description: "InnovateX logo" },
  { name: "FutureForge", description: "FutureForge logo" },
  { name: "NexusPrime", description: "NexusPrime logo" },
];

const Sponsors = () => {
  return (
    <div className="py-16 sm:py-24">
      <div className="container mx-auto px-6 lg:px-8">
        <h2 className="text-center text-lg font-semibold leading-8 text-gray-400">
          Proudly sponsored by the leaders in tech innovation
        </h2>
        <div className="mt-10 grid max-w-lg grid-cols-2 items-center gap-x-8 gap-y-10 sm:max-w-xl sm:grid-cols-3 lg:mx-0 lg:max-w-none lg:grid-cols-5">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="flex justify-center"
          >
            <img 
              class="max-h-12 w-full object-contain filter grayscale hover:filter-none opacity-60 hover:opacity-100 transition-all duration-300"
              alt="QuantumLeap logo"
              width="158"
              height="48"
             src="https://images.unsplash.com/photo-1695462131550-24be3156b25d" />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="flex justify-center"
          >
            <img 
              class="max-h-12 w-full object-contain filter grayscale hover:filter-none opacity-60 hover:opacity-100 transition-all duration-300"
              alt="Cyberia logo"
              width="158"
              height="48"
             src="https://images.unsplash.com/photo-1454527919536-963384b54537" />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="flex justify-center"
          >
            <img 
              class="max-h-12 w-full object-contain filter grayscale hover:filter-none opacity-60 hover:opacity-100 transition-all duration-300"
              alt="InnovateX logo"
              width="158"
              height="48"
             src="https://images.unsplash.com/photo-1681992894234-6db66a592c29" />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="flex justify-center"
          >
            <img 
              class="max-h-12 w-full object-contain filter grayscale hover:filter-none opacity-60 hover:opacity-100 transition-all duration-300"
              alt="FutureForge logo"
              width="158"
              height="48"
             src="https://images.unsplash.com/photo-1559331196-8509b728b43c" />
          </motion.div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.5, delay: 0.5 }}
            className="flex justify-center"
          >
            <img 
              class="max-h-12 w-full object-contain filter grayscale hover:filter-none opacity-60 hover:opacity-100 transition-all duration-300"
              alt="NexusPrime logo"
              width="158"
              height="48"
             src="https://images.unsplash.com/photo-1663813116840-cef0040331fe" />
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Sponsors;