import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { ArrowUpRight, Book, Github, Palette } from 'lucide-react';

const resources = [
  {
    title: 'Awesome Developer Tools',
    description: 'A curated list of fantastic tools and utilities for modern developers.',
    link: 'https://github.com/topics/developer-tools',
    icon: <Github className="w-8 h-8" />,
    color: 'from-purple-500 to-indigo-500',
  },
  {
    title: 'Design Resources for Devs',
    description: 'A collection of design assets, UI kits, and inspiration for developers.',
    link: 'https://github.com/bradtraversy/design-resources-for-developers',
    icon: <Palette className="w-8 h-8" />,
    color: 'from-pink-500 to-rose-500',
  },
  {
    title: 'Free Programming Books',
    description: 'Access a huge library of free programming books on various topics.',
    link: 'https://github.com/EbookFoundation/free-programming-books',
    icon: <Book className="w-8 h-8" />,
    color: 'from-green-500 to-emerald-500',
  },
];

const ResourceCard = ({ title, description, link, icon, color, delay }) => (
  <motion.a
    href={link}
    target="_blank"
    rel="noopener noreferrer"
    className="block group"
    variants={{
      hidden: { opacity: 0, y: 50 },
      visible: { opacity: 1, y: 0, transition: { delay, duration: 0.5, ease: 'easeOut' } },
    }}
  >
    <Card className="h-full bg-card/50 backdrop-blur-sm border-white/10 hover:border-primary/50 transition-all duration-300 hover:shadow-primary/10 overflow-hidden">
      <CardHeader className="flex flex-row items-center justify-between">
        <div className={`p-3 rounded-lg bg-gradient-to-br ${color} text-white`}>
          {icon}
        </div>
        <ArrowUpRight className="w-6 h-6 text-gray-500 group-hover:text-primary transition-colors group-hover:rotate-45" />
      </CardHeader>
      <CardContent>
        <CardTitle className="text-xl font-bold group-hover:text-primary transition-colors">{title}</CardTitle>
        <p className="text-muted-foreground mt-2">{description}</p>
      </CardContent>
    </Card>
  </motion.a>
);

const DeveloperResources = () => {
  return (
    <>
      <motion.div
        className="text-center mb-16"
        variants={{
          hidden: { opacity: 0, y: 20 },
          visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
        }}
      >
        <h2 className="text-4xl md:text-5xl font-bold text-white tracking-tight">Developer's Toolkit</h2>
        <p className="mt-4 text-lg text-gray-400 max-w-3xl mx-auto">
          A curated collection of essential tools and resources to boost your productivity and skills.
        </p>
      </motion.div>
      <div className="grid md:grid-cols-3 gap-8">
        {resources.map((resource, index) => (
          <ResourceCard key={resource.title} {...resource} delay={index * 0.1} />
        ))}
      </div>
    </>
  );
};

export default DeveloperResources;