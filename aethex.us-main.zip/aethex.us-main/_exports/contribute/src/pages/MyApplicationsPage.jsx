import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Loader2, FileText, ArrowLeft, AlertCircle } from 'lucide-react';
import { timeAgo } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';

const getStatusVariant = (status) => {
  switch (status.toLowerCase()) {
    case 'submitted':
      return 'default';
    case 'under review':
      return 'secondary';
    case 'interviewing':
      return 'success';
    case 'rejected':
      return 'destructive';
    case 'hired':
      return 'success';
    default:
      return 'outline';
  }
};

const MyApplicationsPage = () => {
  const { user } = useAuth();
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchApplications = async () => {
      if (!user) {
        setLoading(false);
        return;
      }
      setLoading(true);
      const { data, error } = await supabase
        .from('job_applications')
        .select(`
          *,
          job_openings (
            title,
            department,
            location
          )
        `)
        .eq('user_id', user.id)
        .order('submitted_at', { ascending: false });

      if (error) {
        console.error('Error fetching applications:', error);
        setApplications([]);
      } else {
        setApplications(data);
      }
      setLoading(false);
    };

    fetchApplications();
  }, [user]);

  return (
    <>
      <Helmet>
        <title>My Applications - AeThex Careers</title>
        <meta name="description" content="Track the status of your job applications with AeThex." />
      </Helmet>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        transition={{ duration: 0.5 }}
      >
        <div className="mb-8 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-white">My Applications</h1>
            <p className="text-gray-400 mt-1">Track the status of all your applications here.</p>
          </div>
          <Button asChild variant="outline">
            <Link to="/" className="flex items-center">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Job Listings
            </Link>
          </Button>
        </div>

        <div className="bg-gray-900/50 border border-gray-800 rounded-lg overflow-hidden">
          {loading ? (
            <div className="flex justify-center items-center p-16">
              <Loader2 className="w-8 h-8 text-primary animate-spin" />
            </div>
          ) : applications.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Position</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead>Submitted</TableHead>
                    <TableHead className="text-right">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {applications.map((app) => (
                    <TableRow key={app.id}>
                      <TableCell className="font-medium">
                        <Link to={`/job/${app.job_id}`} className="hover:text-primary transition-colors">
                          {app.job_openings.title}
                        </Link>
                        <div className="text-xs text-gray-500">{app.job_openings.department}</div>
                      </TableCell>
                      <TableCell>{app.job_openings.location}</TableCell>
                      <TableCell>{timeAgo(app.submitted_at)}</TableCell>
                      <TableCell className="text-right">
                        <Badge variant={getStatusVariant(app.status)} className="capitalize">
                          {app.status}
                        </Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center py-16 px-6">
              <FileText className="w-16 h-16 mx-auto text-primary mb-4" />
              <h2 className="text-2xl font-bold text-white mb-2">No Applications Yet</h2>
              <p className="text-gray-400 mb-6">You haven't applied for any positions.</p>
              <Button asChild>
                <Link to="/">Explore Open Roles</Link>
              </Button>
            </div>
          )}
        </div>
      </motion.div>
    </>
  );
};

export default MyApplicationsPage;