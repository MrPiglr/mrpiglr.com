import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Loader2, ArrowRight, CheckCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.15 }
  }
};

const itemVariants = {
  hidden: { y: 20, opacity: 0 },
  visible: { y: 0, opacity: 1, transition: { duration: 0.5 } }
};

const GetInvolvedPage = () => {
  const [opportunities, setOpportunities] = useState([]);
  const [testimonials, setTestimonials] = useState([]);
  const [faqs, setFaqs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [applying, setApplying] = useState(null);
  const [applied, setApplied] = useState([]);
  const { user, profile, setShowAuthModal } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [opps, tests, faqsData, apps] = await Promise.all([
          supabase.from('volunteer_opportunities').select('*').eq('is_active', true),
          supabase.from('volunteer_testimonials').select('*'),
          supabase.from('faqs').select('*').eq('category', 'Volunteering').order('display_order'),
          user ? supabase.from('volunteer_applications').select('opportunity_id').eq('user_id', user.id) : Promise.resolve({ data: [] })
        ]);

        if (opps.error) throw opps.error;
        if (tests.error) throw tests.error;
        if (faqsData.error) throw faqsData.error;
        if (apps.error) throw apps.error;

        setOpportunities(opps.data);
        setTestimonials(tests.data);
        setFaqs(faqsData.data);
        setApplied(apps.data.map(a => a.opportunity_id));

      } catch (error) {
        toast({ variant: 'destructive', title: 'Error fetching data', description: error.message });
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [toast, user]);

  const handleApply = async (opportunityId) => {
    if (!user) {
      setShowAuthModal(true);
      toast({ title: 'Please sign in', description: 'You need to be logged in to apply for an opportunity.' });
      return;
    }
    
    setApplying(opportunityId);
    
    const { data, error } = await supabase
      .from('volunteer_applications')
      .insert({ opportunity_id: opportunityId, user_id: user.id });

    if (error) {
      toast({
        variant: 'destructive',
        title: 'Application failed',
        description: error.message,
      });
    } else {
      toast({
        variant: 'success',
        title: 'Application Submitted!',
        description: 'Thank you for your interest. We will review your application.',
      });
      setApplied(prev => [...prev, opportunityId]);
    }
    setApplying(null);
  };

  return (
    <>
      <Helmet>
        <title>Get Involved | AeThex Collective</title>
        <meta name="description" content="Join the AeThex collective. Find volunteer opportunities, learn about our mission, and become a co-owner of the future of the internet." />
        <meta property="og:title" content="Get Involved | AeThex Collective" />
        <meta property="og:description" content="Contribute your skills to build decentralized, intelligent technologies." />
      </Helmet>

      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="max-w-6xl mx-auto"
      >
        <motion.div variants={itemVariants} className="text-center mb-16">
          <h1 className="text-5xl md:text-7xl font-bold tracking-tighter mb-4 font-mono">
            Join the <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">Collective</span>
          </h1>
          <p className="text-lg md:text-xl text-gray-400 max-w-3xl mx-auto">
            We are building a decentralized future, and we believe it should be built by a decentralized community. Your skills, passion, and vision can help shape the next digital epoch.
          </p>
        </motion.div>

        <motion.section variants={itemVariants} className="mb-24">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 font-mono">Available Opportunities</h2>
          {loading ? (
            <div className="flex justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>
          ) : (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {opportunities.map(opp => (
                <Card key={opp.id} className="flex flex-col">
                  <CardHeader>
                    <CardTitle>{opp.title}</CardTitle>
                    <CardDescription>{opp.time_commitment}</CardDescription>
                  </CardHeader>
                  <CardContent className="flex-grow">
                    <p className="text-gray-400 mb-4">{opp.description}</p>
                    <div className="space-y-1">
                      <h4 className="font-bold text-sm text-white">Skills Required:</h4>
                      <div className="flex flex-wrap gap-2">
                        {opp.skills_required.map(skill => <Badge key={skill} variant="secondary">{skill}</Badge>)}
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button 
                      className="w-full" 
                      onClick={() => handleApply(opp.id)}
                      disabled={applying === opp.id || applied.includes(opp.id)}
                    >
                      {applying === opp.id ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : applied.includes(opp.id) ? (
                        <>
                          <CheckCircle className="mr-2 h-4 w-4" /> Applied
                        </>
                      ) : (
                        <>
                          Apply Now <ArrowRight className="ml-2 h-4 w-4" />
                        </>
                      )}
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </motion.section>

        <motion.section variants={itemVariants} className="mb-24 bg-gray-900/30 rounded-xl p-8 md:p-12 border border-white/10">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 font-mono">Voices of the Collective</h2>
          {loading ? (
            <div className="flex justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>
          ) : (
            <div className="grid md:grid-cols-2 gap-8">
              {testimonials.map(t => (
                <blockquote key={t.id} className="p-6 border-l-4 border-primary bg-gray-950/40 rounded-r-lg">
                  <p className="text-gray-300 italic">"{t.testimonial}"</p>
                  <footer className="mt-4 flex items-center gap-3">
                    <img  class="h-12 w-12 rounded-full object-cover" alt={`Avatar of ${t.name}`} src="https://images.unsplash.com/photo-1701269395744-32e3c1d11645" />
                    <div>
                      <p className="font-bold text-white">{t.name}</p>
                      <p className="text-sm text-primary">{t.role}</p>
                    </div>
                  </footer>
                </blockquote>
              ))}
            </div>
          )}
        </motion.section>

        <motion.section variants={itemVariants} className="max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 font-mono">Frequently Asked Questions</h2>
          {loading ? (
            <div className="flex justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>
          ) : (
            <Accordion type="single" collapsible className="w-full">
              {faqs.map(faq => (
                <AccordionItem key={faq.id} value={`item-${faq.id}`}>
                  <AccordionTrigger className="text-lg text-left">{faq.question}</AccordionTrigger>
                  <AccordionContent className="text-base text-gray-400">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          )}
        </motion.section>
      </motion.div>
    </>
  );
};

export default GetInvolvedPage;