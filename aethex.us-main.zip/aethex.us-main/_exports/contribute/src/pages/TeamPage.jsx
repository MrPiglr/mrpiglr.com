import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/customSupabaseClient';
import { Card, CardContent } from '@/components/ui/card';
import { Loader2, Linkedin, Twitter, Github } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const TeamMemberCard = ({ member }) => {
  const socialLinks = member.social_links || {};
  return (
    <Card className="text-center bg-gray-900/40 border-white/10 overflow-hidden transform hover:-translate-y-2 transition-transform duration-300">
      <CardContent className="p-6">
        <img  
          className="w-32 h-32 rounded-full mx-auto mb-4 border-4 border-primary/30 object-cover" 
          alt={`Portrait of ${member.name}, ${member.role}`}
         src="https://images.unsplash.com/photo-1575383596664-30f4489f9786" />
        <h3 className="text-xl font-bold text-white">{member.name}</h3>
        <p className="text-primary font-semibold">{member.role}</p>
        <p className="text-gray-400 mt-2 text-sm">{member.bio}</p>
        <div className="flex justify-center gap-4 mt-4">
          {socialLinks.linkedin && <a href={socialLinks.linkedin} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-primary"><Linkedin /></a>}
          {socialLinks.twitter && <a href={socialLinks.twitter} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-primary"><Twitter /></a>}
          {socialLinks.github && <a href={socialLinks.github} target="_blank" rel="noopener noreferrer" className="text-gray-500 hover:text-primary"><Github /></a>}
        </div>
      </CardContent>
    </Card>
  );
};

const TeamPage = () => {
  const [team, setTeam] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    const fetchTeam = async () => {
      const { data, error } = await supabase
        .from('team_members')
        .select('*')
        .order('order_index', { ascending: true });

      if (error) {
        toast({
          variant: "destructive",
          title: "Failed to load team",
          description: error.message,
        });
      } else {
        setTeam(data);
      }
      setLoading(false);
    };

    fetchTeam();
  }, [toast]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1 },
  };

  return (
    <>
      <Helmet>
        <title>Our Team | AeThex</title>
        <meta name="description" content="Meet the collective of visionaries, engineers, and architects building the future at AeThex." />
        <meta property="og:title" content="Our Team | AeThex" />
        <meta property="og:description" content="Meet the collective of visionaries, engineers, and architects building the future at AeThex." />
      </Helmet>

      <motion.div
        initial="hidden"
        animate="visible"
        variants={containerVariants}
      >
        <div className="text-center mb-16">
          <motion.h1 variants={itemVariants} className="text-5xl md:text-7xl font-bold tracking-tighter mb-4 font-mono">
            Our <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">Collective</span>
          </motion.h1>
          <motion.p variants={itemVariants} className="text-lg md:text-xl text-gray-400 max-w-3xl mx-auto">
            We are a distributed team of researchers, engineers, and strategists united by a shared vision for a decentralized future.
          </motion.p>
        </div>

        {loading ? (
          <div className="flex justify-center items-center py-20">
            <Loader2 className="w-12 h-12 text-primary animate-spin" />
          </div>
        ) : (
          <motion.div
            variants={containerVariants}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {team.map((member) => (
              <motion.div key={member.id} variants={itemVariants}>
                <TeamMemberCard member={member} />
              </motion.div>
            ))}
          </motion.div>
        )}
      </motion.div>
    </>
  );
};

export default TeamPage;