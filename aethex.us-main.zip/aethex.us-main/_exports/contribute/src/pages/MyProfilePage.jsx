import React from 'react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Helmet } from 'react-helmet';
import { toast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { Loader2 } from 'lucide-react';

const MyProfilePage = () => {
  const { user, profile, loading } = useAuth();

  const handleNotImplemented = () => {
    toast({
      title: "🚧 Feature in Development",
      description: "This feature isn't implemented yet—but we're working on it! 🚀",
      variant: "destructive"
    });
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <Loader2 className="w-12 h-12 text-primary animate-spin" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="text-center">
        <p>Could not load profile.</p>
      </div>
    );
  }
  
  const avatarUrl = profile?.avatar_url || `https://api.dicebear.com/7.x/bottts/svg?seed=${user?.id}`;

  return (
    <>
      <Helmet>
        <title>My Profile - AeThex</title>
        <meta name="description" content="Manage your AeThex contributor profile." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex flex-col md:flex-row items-start gap-8">
          <motion.div 
            className="w-full md:w-1/3 lg:w-1/4"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2, duration: 0.5 }}
          >
            <Card className="bg-slate-900/50 border-primary/20 backdrop-blur-sm overflow-hidden">
              <CardHeader className="p-0">
                <div className="relative h-40 bg-gradient-to-br from-primary/20 to-secondary/20">
                  <img 
                    alt="Abstract banner for user profile"
                    className="w-full h-full object-cover"
                    src="https://images.unsplash.com/photo-1686140386811-099f53c0dd54" />
                </div>
                <div className="relative p-6 flex flex-col items-center -mt-16">
                  <div className="relative">
                    <img
                      src={avatarUrl}
                      alt={profile.username}
                      className="w-28 h-28 rounded-full border-4 border-slate-900 object-cover"
                    />
                    <span className="absolute bottom-1 right-1 block h-5 w-5 rounded-full border-2 border-slate-900 bg-green-500" />
                  </div>
                  <CardTitle className="mt-4 text-2xl font-bold">{profile.full_name || profile.username}</CardTitle>
                  <p className="text-gray-400">@{profile.username}</p>
                  <p className="mt-2 text-center text-sm text-gray-300">{profile.bio}</p>
                  <Button onClick={handleNotImplemented} variant="outline" className="mt-4 w-full">Edit Profile</Button>
                </div>
              </CardHeader>
            </Card>
          </motion.div>

          <motion.div 
            className="w-full md:w-2/3 lg:w-3/4"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.4, duration: 0.5 }}
          >
            <Card className="bg-slate-900/50 border-primary/20 backdrop-blur-sm">
              <CardHeader>
                <CardTitle>Profile Details</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-gray-400">Email</label>
                    <p className="text-lg">{profile.email}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-400">Role</label>
                    <p className="text-lg capitalize">{profile.role}</p>
                  </div>
                    <div>
                    <label className="text-sm font-medium text-gray-400">Loyalty Points</label>
                    <p className="text-lg">{profile.loyalty_points}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-400">Joined</label>
                    <p className="text-lg">{new Date(profile.created_at).toLocaleDateString()}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </motion.div>
    </>
  );
};

export default MyProfilePage;