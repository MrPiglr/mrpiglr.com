import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { useNotifications } from '@/contexts/NotificationContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, Bell, MessageSquare, Briefcase, UserPlus } from 'lucide-react';
import { timeAgo } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';

const NotificationIcon = ({ type }) => {
    switch (type) {
        case 'new_message':
            return <MessageSquare className="w-6 h-6 text-blue-400" />;
        case 'new_job_application':
            return <Briefcase className="w-6 h-6 text-green-400" />;
        case 'user_joined':
             return <UserPlus className="w-6 h-6 text-purple-400" />;
        default:
            return <Bell className="w-6 h-6 text-gray-400" />;
    }
};

const getNotificationDetails = (notification) => {
    const { type, data } = notification;
    switch(type) {
        case 'new_message':
            return {
                text: <>New message from <strong>{data.sender_username}</strong>: "{data.message_preview}..."</>,
                link: `/messages/${data.conversation_id}`
            };
        case 'new_job_application':
            return {
                text: <>New application for <strong>{data.job_title}</strong> from {data.applicant_username}.</>,
                link: `/admin/applications/${data.application_id}`
            };
        case 'user_joined':
            return {
                text: <><strong>{data.username}</strong> just joined the platform!</>,
                link: `/profile/${data.user_id}`
            };
        default:
            return {
                text: <>{data.message || 'New notification'}</>,
                link: '#'
            };
    }
};

const NotificationsPage = () => {
    const { notifications, loading, unreadCount, markAllAsRead, markAsRead } = useNotifications();
    const navigate = useNavigate();

    const handleNotificationClick = (notification) => {
        const { link } = getNotificationDetails(notification);
        if (!notification.is_read) {
            markAsRead(notification.id);
        }
        if (link && link !== '#') {
            navigate(link);
        }
    };

    return (
        <>
            <Helmet>
                <title>Notifications | AeThex Contributor</title>
                <meta name="description" content="View all your notifications." />
            </Helmet>
            <div className="max-w-4xl mx-auto py-8 px-4">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                >
                    <div className="flex items-center justify-between mb-6">
                        <div>
                            <h1 className="text-3xl font-bold text-white">All Notifications</h1>
                            <p className="text-gray-400 mt-1">Here's what you've missed.</p>
                        </div>
                        {unreadCount > 0 && (
                            <Button onClick={markAllAsRead}>Mark All as Read</Button>
                        )}
                    </div>

                    <Card>
                        <CardHeader>
                            <CardTitle>Your Alerts</CardTitle>
                            <CardDescription>A complete history of your notifications.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            {loading ? (
                                <div className="flex justify-center items-center p-16">
                                    <Loader2 className="w-8 h-8 text-primary animate-spin" />
                                </div>
                            ) : notifications.length === 0 ? (
                                <div className="text-center py-16">
                                    <Bell className="mx-auto h-12 w-12 text-gray-500" />
                                    <h3 className="mt-2 text-lg font-medium text-white">All caught up!</h3>
                                    <p className="mt-1 text-sm text-gray-400">You have no new notifications.</p>
                                </div>
                            ) : (
                                <div className="space-y-4">
                                    {notifications.map((notification) => (
                                        <div
                                            key={notification.id}
                                            onClick={() => handleNotificationClick(notification)}
                                            className={`flex items-start gap-4 p-4 rounded-lg transition-colors cursor-pointer border ${
                                                notification.is_read
                                                    ? 'bg-gray-900/30 border-gray-800 hover:bg-gray-800/50'
                                                    : 'bg-primary/10 border-primary/20 hover:bg-primary/20'
                                            }`}
                                        >
                                            <div className="flex-shrink-0 pt-1">
                                                <NotificationIcon type={notification.type} />
                                            </div>
                                            <div className="flex-grow">
                                                <p className="text-sm text-gray-200">{getNotificationDetails(notification).text}</p>
                                                <p className="text-xs text-gray-400 mt-1">{timeAgo(notification.created_at)}</p>
                                            </div>
                                            {!notification.is_read && (
                                                <div className="flex-shrink-0 self-center">
                                                    <div className="w-2.5 h-2.5 rounded-full bg-primary animate-pulse"></div>
                                                </div>
                                            )}
                                        </div>
                                    ))}
                                </div>
                            )}
                        </CardContent>
                    </Card>
                </motion.div>
            </div>
        </>
    );
};

export default NotificationsPage;