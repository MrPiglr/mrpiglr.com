import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useSite } from '@/contexts/SiteContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, PlusCircle, Ticket } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { timeAgo } from '@/lib/utils';

const CreateTicketModal = ({ onTicketCreated }) => {
    const [open, setOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [priority, setPriority] = useState('Medium');
    const { user } = useAuth();
    const { siteId } = useSite();
    const { toast } = useToast();

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!title || !description) {
            toast({ variant: 'destructive', title: 'Missing fields', description: 'Please fill out all required fields.' });
            return;
        }
        setLoading(true);

        const { error } = await supabase.from('tickets').insert({
            title,
            description,
            priority,
            status: 'Open',
            type: 'General',
            created_by: user.id,
            site_id: siteId,
        });

        setLoading(false);
        if (error) {
            toast({ variant: 'destructive', title: 'Error creating ticket', description: error.message });
        } else {
            toast({ variant: 'success', title: 'Ticket Created!', description: 'Your support ticket has been submitted.' });
            setTitle('');
            setDescription('');
            setPriority('Medium');
            onTicketCreated();
            setOpen(false);
        }
    };

    return (
        <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
                <Button>
                    <PlusCircle className="mr-2 h-4 w-4" />
                    Create New Ticket
                </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                    <DialogTitle>Create a Support Ticket</DialogTitle>
                    <DialogDescription>
                        Describe the issue you're facing. Our team will get back to you as soon as possible.
                    </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit}>
                    <div className="grid gap-4 py-4">
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="title" className="text-right">Title</Label>
                            <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} className="col-span-3" required />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="description" className="text-right">Description</Label>
                            <Textarea id="description" value={description} onChange={(e) => setDescription(e.target.value)} className="col-span-3" required />
                        </div>
                        <div className="grid grid-cols-4 items-center gap-4">
                            <Label htmlFor="priority" className="text-right">Priority</Label>
                            <Select value={priority} onValueChange={setPriority}>
                                <SelectTrigger className="col-span-3">
                                    <SelectValue placeholder="Select priority" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="Low">Low</SelectItem>
                                    <SelectItem value="Medium">Medium</SelectItem>
                                    <SelectItem value="High">High</SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    </div>
                    <DialogFooter>
                        <Button type="submit" disabled={loading}>
                            {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                            Submit Ticket
                        </Button>
                    </DialogFooter>
                </form>
            </DialogContent>
        </Dialog>
    );
};

const MyTicketsPage = () => {
    const [tickets, setTickets] = useState([]);
    const [loading, setLoading] = useState(true);
    const { user } = useAuth();
    const { toast } = useToast();

    const fetchTickets = useCallback(async () => {
        if (!user) return;
        setLoading(true);
        const { data, error } = await supabase
            .from('tickets')
            .select('*')
            .eq('created_by', user.id)
            .order('created_at', { ascending: false });

        if (error) {
            toast({ variant: 'destructive', title: 'Error fetching tickets', description: error.message });
        } else {
            setTickets(data);
        }
        setLoading(false);
    }, [user, toast]);

    useEffect(() => {
        fetchTickets();
    }, [fetchTickets]);

    const getStatusVariant = (status) => {
        switch (status) {
            case 'Open': return 'success';
            case 'In Progress': return 'secondary';
            case 'Closed': return 'outline';
            default: return 'default';
        }
    };

    const getPriorityVariant = (priority) => {
        switch (priority) {
            case 'High': return 'destructive';
            case 'Medium': return 'warning';
            case 'Low': return 'success';
            default: return 'outline';
        }
    };

    return (
        <>
            <Helmet>
                <title>My Tickets | AeThex Contributor</title>
                <meta name="description" content="View and manage your support tickets." />
            </Helmet>
            <div className="max-w-6xl mx-auto py-8 px-4">
                <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                >
                    <div className="flex items-center justify-between mb-6">
                        <div>
                            <h1 className="text-3xl font-bold text-white">My Support Tickets</h1>
                            <p className="text-gray-400 mt-1">Track the status of your support requests.</p>
                        </div>
                        <CreateTicketModal onTicketCreated={fetchTickets} />
                    </div>

                    <Card>
                        <CardHeader>
                            <CardTitle>Your Tickets</CardTitle>
                            <CardDescription>A list of all tickets you have submitted.</CardDescription>
                        </CardHeader>
                        <CardContent>
                            {loading ? (
                                <div className="flex justify-center items-center p-16">
                                    <Loader2 className="w-8 h-8 text-primary animate-spin" />
                                </div>
                            ) : tickets.length === 0 ? (
                                <div className="text-center py-16">
                                    <Ticket className="mx-auto h-12 w-12 text-gray-500" />
                                    <h3 className="mt-2 text-lg font-medium text-white">No tickets found</h3>
                                    <p className="mt-1 text-sm text-gray-400">Get started by creating a new ticket.</p>
                                </div>
                            ) : (
                                <Table>
                                    <TableHeader>
                                        <TableRow>
                                            <TableHead>Title</TableHead>
                                            <TableHead>Status</TableHead>
                                            <TableHead>Priority</TableHead>
                                            <TableHead className="text-right">Created</TableHead>
                                        </TableRow>
                                    </TableHeader>
                                    <TableBody>
                                        {tickets.map((ticket) => (
                                            <TableRow key={ticket.id}>
                                                <TableCell className="font-medium">{ticket.title}</TableCell>
                                                <TableCell><Badge variant={getStatusVariant(ticket.status)}>{ticket.status}</Badge></TableCell>
                                                <TableCell><Badge variant={getPriorityVariant(ticket.priority)}>{ticket.priority}</Badge></TableCell>
                                                <TableCell className="text-right">{timeAgo(ticket.created_at)}</TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            )}
                        </CardContent>
                    </Card>
                </motion.div>
            </div>
        </>
    );
};

export default MyTicketsPage;