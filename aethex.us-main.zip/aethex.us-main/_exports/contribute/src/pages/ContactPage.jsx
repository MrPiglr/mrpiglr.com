import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Loader2, Mail, Phone, MapPin } from 'lucide-react';

const ContactPage = () => {
    const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
    const [loading, setLoading] = useState(false);
    const { toast } = useToast();

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.id]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);

        const { error } = await supabase.from('contact_submissions').insert([
            { name: formData.name, email: formData.email, subject: formData.subject, message: formData.message }
        ]);

        if (error) {
            toast({
                variant: 'destructive',
                title: 'Error submitting form',
                description: error.message,
            });
        } else {
            toast({
                title: 'Message Sent!',
                description: "Thank you for reaching out. We'll be in touch soon.",
            });
            setFormData({ name: '', email: '', subject: '', message: '' });
        }
        setLoading(false);
    };

    const contactInfo = [
        { icon: Mail, title: "General Inquiries", value: "contact@aethex.com" },
        { icon: Phone, title: "Phone Support", value: "+1 (555) 010-4567" },
        { icon: MapPin, title: "Headquarters", value: "Digital Realm / Decentralized" },
    ];

    return (
        <>
            <Helmet>
                <title>Contact Us | AeThex</title>
                <meta name="description" content="Get in touch with the AeThex team for inquiries, partnerships, or press via our contact form or official channels." />
                <meta property="og:title" content="Contact Us | AeThex" />
                <meta property="og:description" content="Reach out to the AeThex collective." />
            </Helmet>

            <motion.div 
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }} 
                transition={{ duration: 0.5 }}
                className="max-w-6xl mx-auto"
            >
                <div className="text-center mb-16">
                    <motion.h1 
                        initial={{ opacity: 0, y: -20 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="text-5xl md:text-7xl font-bold tracking-tighter mb-4 font-mono"
                    >
                        Contact <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">Us</span>
                    </motion.h1>
                    <motion.p 
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.2 }}
                        className="text-lg md:text-xl text-gray-400 max-w-3xl mx-auto"
                    >
                        Have a question, proposal, or just want to connect? We're here to listen.
                    </motion.p>
                </div>

                <div className="grid md:grid-cols-5 gap-12">
                    <motion.div 
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.3 }}
                        className="md:col-span-2 space-y-8"
                    >
                        {contactInfo.map((item, index) => (
                            <div key={index} className="flex gap-4 items-start">
                                <div className="p-3 bg-primary/10 rounded-lg w-max border border-primary/20">
                                    <item.icon className="w-6 h-6 text-primary" />
                                </div>
                                <div>
                                    <h3 className="font-bold text-white text-lg">{item.title}</h3>
                                    <p className="text-gray-400">{item.value}</p>
                                </div>
                            </div>
                        ))}
                    </motion.div>

                    <motion.div 
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: 0.4 }}
                        className="md:col-span-3"
                    >
                        <Card className="bg-gray-900/40 border-white/10">
                            <CardHeader>
                                <CardTitle>Send us a message</CardTitle>
                                <CardDescription>Fill out the form below and we'll get back to you.</CardDescription>
                            </CardHeader>
                            <CardContent>
                                <form onSubmit={handleSubmit} className="space-y-4">
                                    <div className="space-y-2">
                                        <Label htmlFor="name">Full Name</Label>
                                        <Input id="name" type="text" value={formData.name} onChange={handleChange} required disabled={loading} placeholder="John Doe" />
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="email">Email Address</Label>
                                        <Input id="email" type="email" value={formData.email} onChange={handleChange} required disabled={loading} placeholder="you@example.com" />
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="subject">Subject</Label>
                                        <Input id="subject" type="text" value={formData.subject} onChange={handleChange} disabled={loading} placeholder="Partnership Inquiry" />
                                    </div>
                                    <div className="space-y-2">
                                        <Label htmlFor="message">Your Message</Label>
                                        <Textarea id="message" value={formData.message} onChange={handleChange} required disabled={loading} rows={5} placeholder="Tell us how we can help..." />
                                    </div>
                                    <Button type="submit" className="w-full" disabled={loading}>
                                        {loading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                                        Send Message
                                    </Button>
                                </form>
                            </CardContent>
                        </Card>
                    </motion.div>
                </div>
            </motion.div>
        </>
    );
};

export default ContactPage;