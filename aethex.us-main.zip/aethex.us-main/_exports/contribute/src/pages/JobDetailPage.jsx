import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Loader2, Briefcase, MapPin, ArrowLeft, CheckCircle, AlertCircle, AlertTriangle, Lock, Flag } from 'lucide-react';
import { timeAgo } from '@/lib/utils';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

const EquityDisclaimer = () => (
  <motion.div 
    className="my-8 p-6 bg-yellow-900/20 border-2 border-yellow-500/30 rounded-xl"
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay: 0.2 }}
  >
    <div className="flex items-start gap-4">
      <AlertTriangle className="w-10 h-10 text-yellow-400 flex-shrink-0 mt-1" />
      <div>
        <h3 className="text-xl font-bold text-yellow-300 mb-2">READ BEFORE APPLYING — THIS IS AN EQUITY ROLE</h3>
        <p className="text-yellow-200/80">
          This is not a job in the traditional sense. There is no guaranteed pay, salary, or benefits. Instead, this is an <strong>equity-track contributor role</strong> for individuals aligned with AeThex’s long-term mission.
        </p>
      </div>
    </div>
  </motion.div>
);

const NdaDisclaimer = () => (
  <motion.div 
    className="my-8 p-6 bg-red-900/20 border-2 border-red-500/30 rounded-xl"
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay: 0.4 }}
  >
    <div className="flex items-start gap-4">
      <Lock className="w-10 h-10 text-red-400 flex-shrink-0 mt-1" />
      <div>
        <h3 className="text-xl font-bold text-red-300 mb-2">Strict Confidentiality Required</h3>
        <p className="text-red-200/80">
          Due to the sensitive nature of our work, all contributors must sign a comprehensive Non-Disclosure Agreement (NDA). This protects our intellectual property and the future we are building together.
        </p>
      </div>
    </div>
  </motion.div>
);

const FinalNote = () => (
  <motion.div
    className="my-8 p-6 bg-purple-900/20 border-2 border-purple-500/30 rounded-xl"
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, delay: 0.6 }}
  >
    <div className="flex items-start gap-4">
      <Flag className="w-10 h-10 text-purple-400 flex-shrink-0 mt-1" />
      <div>
        <h3 className="text-xl font-bold text-purple-300 mb-2">Final Note on This Role</h3>
        <p className="text-purple-200/80">
          By applying, you acknowledge that you are stepping in as a strategic partner, not an employee. Your participation is based on ownership, contribution, and vision alignment. This is not employment. <strong>This is equity. This is ownership. This is legacy.</strong>
        </p>
      </div>
    </div>
  </motion.div>
);

const JobDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, setShowAuthModal } = useAuth();

  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [hasApplied, setHasApplied] = useState(false);
  
  useEffect(() => {
    let isMounted = true;
    const fetchJob = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('job_openings')
        .select('*')
        .eq('id', id)
        .single();

      if (!isMounted) return;

      if (error || !data) {
        console.error('Error fetching job:', error);
        navigate('/');
      } else {
        setJob(data);
      }
    };

    const checkApplicationStatus = async () => {
      if (!user) return;
      const { data, error } = await supabase
        .from('job_applications')
        .select('id')
        .eq('user_id', user.id)
        .eq('job_id', id)
        .maybeSingle(); // Use maybeSingle to avoid error if no application is found
      
      if (!isMounted) return;
      
      if (data) {
        setHasApplied(true);
      }
    };

    fetchJob().then(() => {
        checkApplicationStatus().then(() => {
          if (isMounted) setLoading(false);
        });
    });

    return () => { isMounted = false; };
  }, [id, navigate, user]);
  
  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <Loader2 className="w-12 h-12 text-primary animate-spin" />
      </div>
    );
  }

  if (!job) {
    return null; 
  }

  const handleApplyClick = () => {
    if (!user) {
      setShowAuthModal(true);
    } else {
      navigate(`/job/${job.id}/apply`);
    }
  };
  
  return (
    <>
      <Helmet>
        <title>{`${job.title} - AeThex Careers`}</title>
        <meta name="description" content={job.description.substring(0, 160)} />
      </Helmet>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="mb-8">
          <Button asChild variant="ghost" className="mb-4">
            <Link to="/" className="flex items-center text-gray-400 hover:text-white">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to All Roles
            </Link>
          </Button>
        </div>
        
        <div className="lg:grid lg:grid-cols-3 lg:gap-8">
          <div className="lg:col-span-2">
            <Card className="mb-8">
              <CardHeader>
                <CardDescription className="text-sm text-gray-400">Posted {timeAgo(job.posted_at)}</CardDescription>
                <CardTitle className="text-3xl font-bold text-white">{job.title}</CardTitle>
                <div className="flex items-center gap-4 pt-2 text-gray-300">
                  <span className="flex items-center gap-1.5"><Briefcase className="w-4 h-4 text-primary" /> {job.division} / {job.department}</span>
                  <span className="flex items-center gap-1.5"><MapPin className="w-4 h-4 text-primary" /> {job.location}</span>
                </div>
              </CardHeader>
              <CardContent>
                <div className="prose prose-invert prose-lg max-w-none text-gray-300 whitespace-pre-wrap">
                  {job.description}
                </div>
              </CardContent>
            </Card>

            <EquityDisclaimer />
            <NdaDisclaimer />
            <FinalNote />
          </div>
          
          <div className="lg:col-span-1">
            <Card className="sticky top-24">
              <CardHeader>
                <CardTitle>Ready to Contribute?</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {hasApplied ? (
                   <div className="flex items-center gap-3 p-4 rounded-lg bg-green-500/10 border border-green-500/30">
                    <CheckCircle className="w-8 h-8 text-green-400" />
                    <div>
                      <h4 className="font-semibold text-white">Application Submitted</h4>
                      <p className="text-sm text-gray-300">We've received your application.</p>
                    </div>
                  </div>
                ) : (
                  <>
                    <p className="text-sm text-gray-400">
                      Submit your application to be considered for this role. We'll review your profile and get back to you soon.
                    </p>
                    <Button onClick={handleApplyClick} className="w-full" size="lg">
                      Apply Now
                    </Button>
                  </>
                )}
                 {!user && !hasApplied && (
                  <div className="flex items-start gap-3 p-3 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-300 text-sm">
                    <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
                    <p>
                      You must be <button onClick={() => setShowAuthModal(true)} className="font-bold underline hover:text-amber-200">signed in</button> to apply for this position.
                    </p>
                  </div>
                 )}
              </CardContent>
            </Card>
          </div>
        </div>
      </motion.div>
    </>
  );
};

export default JobDetailPage;