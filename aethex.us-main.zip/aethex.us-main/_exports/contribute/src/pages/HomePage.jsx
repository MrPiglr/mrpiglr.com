import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowRight, Cpu, Shield, Users, Sparkles } from 'lucide-react';

const HomePage = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.5 } },
  };

  const services = [
    {
      icon: Cpu,
      title: "Decentralized AI",
      description: "Pioneering intelligent systems that operate on distributed networks for unparalleled security and autonomy.",
      link: "/technology#ai"
    },
    {
      icon: Shield,
      title: "Next-Gen Protocols",
      description: "Architecting the foundational communication and data protocols for a truly decentralized internet.",
      link: "/technology#protocols"
    },
    {
      icon: Users,
      title: "Digital Sovereignty",
      description: "Building tools and platforms that empower individuals with true ownership of their data and digital identity.",
      link: "/technology#sovereignty"
    },
  ];

  return (
    <>
      <Helmet>
        <title>AeThex | Engineering the Next Digital Epoch</title>
        <meta name="description" content="AeThex is a research and engineering collective building the foundational layers for the next generation of the internet. Discover our work in decentralized AI, next-gen protocols, and digital sovereignty." />
        <meta property="og:title" content="AeThex | Engineering the Next Digital Epoch" />
        <meta property="og:description" content="Pioneering the future of decentralized systems, AI, and digital ownership." />
      </Helmet>
      
      <div className="relative -mx-4 -mt-8 mb-16 overflow-hidden">
        <div className="aurora-background">
          <div className="relative z-10 container mx-auto text-white py-24 sm:py-32 px-4 text-center">
            <motion.h1 
              className="text-5xl md:text-7xl font-bold tracking-tighter mb-4 font-mono"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7 }}
            >
              Engineering the Next <br className="hidden md:block"/>Digital <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">Epoch</span>
            </motion.h1>
            <motion.p 
              className="text-lg md:text-xl text-gray-400 max-w-3xl mx-auto mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.2 }}
            >
              AeThex is a research and engineering collective building the foundational layers for the next generation of the internet. We create decentralized, intelligent, and user-centric technologies to foster a more resilient and equitable digital world.
            </motion.p>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.4 }}
              className="flex justify-center items-center gap-4"
            >
              <Button asChild size="lg">
                <Link to="/get-involved">
                  Get Involved <Sparkles className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline">
                <Link to="/about">
                  Our Mission <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
            </motion.div>
          </div>
        </div>
      </div>

      <div className="py-16 sm:py-24">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          <motion.h2 variants={itemVariants} className="text-3xl md:text-4xl font-bold text-center mb-4 font-mono tracking-tight">Our Focus Areas</motion.h2>
          <motion.p variants={itemVariants} className="text-lg text-gray-400 text-center max-w-2xl mx-auto mb-16">
            We are deeply engaged in solving the most complex challenges at the intersection of decentralization and artificial intelligence.
          </motion.p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <motion.div key={index} variants={itemVariants}>
                <Card className="h-full bg-gray-900/40 border-white/10 hover:border-primary/50 hover:bg-primary/10 transition-all duration-300">
                  <CardHeader>
                    <div className="p-3 bg-primary/10 rounded-lg w-max mb-4 border border-primary/20">
                        <service.icon className="w-8 h-8 text-primary" />
                    </div>
                    <CardTitle>{service.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-gray-400">{service.description}</p>
                    <Link to={service.link} className="text-primary font-semibold mt-4 inline-block hover:underline">
                      Learn More &rarr;
                    </Link>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>

      <div className="py-16 sm:py-24">
        <motion.div
            className="grid md:grid-cols-2 gap-12 items-center"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, amount: 0.3 }}
          >
          <motion.div variants={itemVariants}>
            <h2 className="font-mono text-3xl font-bold tracking-tight">For the Builders, by the Builders</h2>
            <p className="mt-4 text-lg text-gray-400">AeThex operates as an equity-based collective. We are not hiring employees; we are onboarding partners and co-owners who share our long-term vision. Our structure is designed for those who seek not just to participate in the future, but to build and own a piece of it.</p>
            <Button asChild size="lg" className="mt-6">
              <Link to="/get-involved">Join the Collective</Link>
            </Button>
          </motion.div>
          <motion.div variants={itemVariants}>
            <img  class="rounded-xl shadow-2xl shadow-primary/10 w-full h-auto" alt="A group of diverse software engineers collaborating intently in a modern, dark-themed office space" src="https://images.unsplash.com/photo-1651009188116-bb5f80eaf6aa" />
          </motion.div>
        </motion.div>
      </div>
    </>
  );
};

export default HomePage;