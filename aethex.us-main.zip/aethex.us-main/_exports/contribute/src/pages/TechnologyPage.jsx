import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';

const TechnologyPage = () => {
    // Placeholder content. In a real app, this would come from a CMS or the database.
    return (
        <>
            <Helmet>
                <title>Technology | AeThex</title>
                <meta name="description" content="Explore the core technologies and research areas that power AeThex's vision for a decentralized future." />
            </Helmet>
            <div className="text-center mb-16">
                <motion.h1 
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-5xl md:text-7xl font-bold tracking-tighter mb-4 font-mono"
                >
                    Our <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">Technology</span> Stack
                </motion.h1>
                <motion.p 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="text-lg md:text-xl text-gray-400 max-w-3xl mx-auto"
                >
                    A brief overview of the technological pillars we are building upon. This page is currently a placeholder.
                </motion.p>
            </div>
        </>
    );
};

export default TechnologyPage;