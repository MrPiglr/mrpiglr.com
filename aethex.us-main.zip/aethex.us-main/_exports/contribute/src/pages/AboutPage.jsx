import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const AboutPage = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3,
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.5 } }
  };


  return (
    <>
      <Helmet>
        <title>About AeThex | Our Mission, Vision, and Team</title>
        <meta name="description" content="Learn about AeThex's mission to build the future of digital infrastructure, our core values, and the team of visionaries driving us forward." />
        <meta property="og:title" content="About AeThex | Our Mission, Vision, and Team" />
        <meta property="og:description" content="Learn about AeThex's mission, vision, and the team behind our innovations." />
      </Helmet>
      
      <div className="aurora-background -mx-4 -mt-8">
        <div className="relative z-10 container mx-auto text-white py-16 sm:py-24 px-4">
          
          <motion.div 
            className="text-center"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
          >
            <h1 className="text-5xl md:text-7xl font-bold tracking-tighter mb-4 font-mono">
              About <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">AeThex</span>
            </h1>
            <p className="text-lg md:text-xl text-gray-400 max-w-3xl mx-auto">
              We are a collective of architects, innovators, and visionaries dedicated to engineering the foundational systems for the next digital epoch.
            </p>
          </motion.div>
        </div>
      </div>
      
      <div className="py-16 sm:py-24">
        <motion.div 
          className="grid md:grid-cols-2 gap-12 items-center mb-24"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          <motion.div variants={itemVariants}>
            <img   className="rounded-xl shadow-2xl shadow-primary/10 w-full h-auto" alt="A diverse team of engineers collaborating around a futuristic holographic display"  src="https://images.unsplash.com/photo-1531497258014-b5736f376b1b" />
          </motion.div>
          <motion.div variants={itemVariants} className="prose prose-lg prose-invert max-w-none">
            <h2 className="font-mono text-3xl">Our Story</h2>
            <p>AeThex was born from a simple yet profound observation: the digital world was built on centralized, fragile foundations. We envisioned a new internet—more resilient, intelligent, and equitable. We are not just a company; we are a movement to build that future.</p>
            <p>Our journey began with a small group of experts in decentralized systems, AI, and cryptography. Today, we are a growing ecosystem of contributors, each an owner, all unified by a single, audacious goal.</p>
          </motion.div>
        </motion.div>

        <motion.div 
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 font-mono">Our Core Principles</h2>
          <motion.div variants={itemVariants} className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
            <Card className="bg-gray-900/40 border-white/10">
              <CardHeader>
                <CardTitle>Decentralization First</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400">We prioritize architectural designs that distribute power, eliminate single points of failure, and resist censorship.</p>
              </CardContent>
            </Card>
            <Card className="bg-gray-900/40 border-white/10">
              <CardHeader>
                <CardTitle>Radical Ownership</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400">Our contributors are co-owners. We believe that those who build the future should have a stake in it.</p>
              </CardContent>
            </Card>
            <Card className="bg-gray-900/40 border-white/10">
              <CardHeader>
                <CardTitle>Long-Term Vision</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400">We are not driven by short-term trends. Our focus is on building robust, scalable, and enduring infrastructure.</p>
              </CardContent>
            </Card>
            <Card className="bg-gray-900/40 border-white/10">
              <CardHeader>
                <CardTitle>Open Collaboration</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-400">We foster an environment of intense, transparent collaboration, believing that the best ideas emerge from diverse perspectives.</p>
              </CardContent>
            </Card>
          </motion.div>
        </motion.div>
      </div>
    </>
  );
};

export default AboutPage;