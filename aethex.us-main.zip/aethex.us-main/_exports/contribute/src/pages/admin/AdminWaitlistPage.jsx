import React from 'react';

const AdminWaitlistPage = () => {
  return null;
};

export default AdminWaitlistPage;