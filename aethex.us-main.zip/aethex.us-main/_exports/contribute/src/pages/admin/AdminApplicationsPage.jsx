import React from 'react';

const AdminApplicationsPage = () => {
  return null;
};

export default AdminApplicationsPage;