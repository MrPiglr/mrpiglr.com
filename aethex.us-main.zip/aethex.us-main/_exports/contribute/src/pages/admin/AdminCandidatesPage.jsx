import React from 'react';

const AdminCandidatesPage = () => {
  return null;
};

export default AdminCandidatesPage;