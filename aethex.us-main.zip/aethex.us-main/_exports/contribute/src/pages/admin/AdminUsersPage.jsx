import React from 'react';

const AdminUsersPage = () => {
  return null;
};

export default AdminUsersPage;