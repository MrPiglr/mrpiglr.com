import React from 'react';

const AdminEventsPage = () => {
  return null;
};

export default AdminEventsPage;