import React from 'react';

const AdminProspectsPage = () => {
  return null;
};

export default AdminProspectsPage;