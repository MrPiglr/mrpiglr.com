import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { useSite } from '@/contexts/SiteContext';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Loader2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { timeAgo } from '@/lib/utils';

const AdminProjectsPage = () => {
    const [projects, setProjects] = useState([]);
    const [loading, setLoading] = useState(true);
    const { toast } = useToast();
    const { siteId } = useSite();

    const fetchProjects = useCallback(async () => {
        if (!siteId) return;
        setLoading(true);

        const { data, error } = await supabase
            .from('projects')
            .select('*, owner:profiles(username, avatar_url)')
            .eq('site_id', siteId)
            .order('created_at', { ascending: false });

        if (error) {
            console.error('Error fetching projects:', error);
            toast({ variant: 'destructive', title: 'Error', description: 'Could not fetch projects.' });
        } else {
            setProjects(data);
        }
        setLoading(false);
    }, [toast, siteId]);

    useEffect(() => {
        fetchProjects();
    }, [fetchProjects]);

    const getStatusVariant = (status) => {
        switch (status) {
            case 'In Progress': return 'success';
            case 'Completed': return 'default';
            case 'On Hold': return 'secondary';
            default: return 'outline';
        }
    }

    return (
        <>
            <div className="flex items-center justify-between mb-6">
                <div>
                    <h1 className="text-3xl font-bold text-white">Projects</h1>
                    <p className="text-gray-400 mt-1">Oversee all contributor projects.</p>
                </div>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>All Projects</CardTitle>
                    <CardDescription>A total of {projects.length} projects.</CardDescription>
                </CardHeader>
                <CardContent>
                    {loading ? (
                        <div className="flex justify-center items-center p-16">
                            <Loader2 className="w-8 h-8 text-primary animate-spin" />
                        </div>
                    ) : (
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Title</TableHead>
                                    <TableHead>Owner</TableHead>
                                    <TableHead>Created</TableHead>
                                    <TableHead className="text-right">Status</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {projects.map((project) => (
                                    <TableRow key={project.id}>
                                        <TableCell className="font-medium">{project.title}</TableCell>
                                        <TableCell>
                                            <div className="flex items-center gap-3">
                                                <img src={project.owner.avatar_url} alt={project.owner.username} className="w-8 h-8 rounded-full" />
                                                {project.owner.username}
                                            </div>
                                        </TableCell>
                                        <TableCell>{timeAgo(project.created_at)}</TableCell>
                                        <TableCell className="text-right">
                                            <Badge variant={getStatusVariant(project.status)}>{project.status}</Badge>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    )}
                </CardContent>
            </Card>
        </>
    );
};

export default AdminProjectsPage;