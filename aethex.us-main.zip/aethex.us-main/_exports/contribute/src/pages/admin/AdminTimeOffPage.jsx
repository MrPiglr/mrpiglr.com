import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Loader2, Check, X, MoreHorizontal } from 'lucide-react';
import { formatDate } from '@/lib/utils';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';

const AdminTimeOffPage = () => {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchRequests = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('time_off_requests')
      .select('*, profiles(username, avatar_url)')
      .order('created_at', { ascending: false });

    if (error) {
      toast({ variant: 'destructive', title: 'Error fetching time off requests', description: error.message });
    } else {
      setRequests(data);
    }
    setLoading(false);
  }, [toast]);

  useEffect(() => {
    fetchRequests();
  }, [fetchRequests]);

  const handleUpdateStatus = async (id, status) => {
    const { error } = await supabase
      .from('time_off_requests')
      .update({ status })
      .eq('id', id);

    if (error) {
      toast({ variant: 'destructive', title: 'Error updating status', description: error.message });
    } else {
      toast({ variant: 'success', title: 'Status Updated' });
      fetchRequests();
    }
  };

  const getStatusVariant = (status) => {
    switch (status.toLowerCase()) {
      case 'approved': return 'success';
      case 'rejected': return 'destructive';
      case 'pending': return 'warning';
      default: return 'outline';
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white">Time Off Requests</h1>
          <p className="text-gray-400 mt-1">Review and manage employee time off requests.</p>
        </div>
      </div>
      
      <div className="border border-white/10 rounded-lg overflow-hidden bg-gray-950/20 backdrop-blur-lg">
        <Table>
          <TableHeader>
            <TableRow className="border-b-white/10 hover:bg-transparent">
              <TableHead className="text-white/80">Employee</TableHead>
              <TableHead className="text-white/80">Dates</TableHead>
              <TableHead className="text-white/80">Reason</TableHead>
              <TableHead className="text-center text-white/80">Status</TableHead>
              <TableHead className="text-right text-white/80">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow><TableCell colSpan="5" className="text-center py-16"><Loader2 className="mx-auto h-8 w-8 animate-spin text-primary" /></TableCell></TableRow>
            ) : requests.length === 0 ? (
              <TableRow><TableCell colSpan="5" className="text-center py-16 text-gray-500">No time off requests found.</TableCell></TableRow>
            ) : (
              requests.map((req) => (
                <TableRow key={req.id} className="border-b-white/10 last:border-b-0 hover:bg-white/5">
                  <TableCell className="font-medium text-white">
                    <div className="flex items-center gap-3">
                      <img src={req.profiles.avatar_url} alt={req.profiles.username} className="w-8 h-8 rounded-full" />
                      {req.profiles.username}
                    </div>
                  </TableCell>
                  <TableCell className="text-gray-300">{formatDate(req.start_date)} - {formatDate(req.end_date)}</TableCell>
                  <TableCell className="text-gray-300 max-w-xs truncate">{req.reason}</TableCell>
                  <TableCell className="text-center"><Badge variant={getStatusVariant(req.status)} className="capitalize">{req.status}</Badge></TableCell>
                  <TableCell className="text-right">
                    {req.status === 'pending' && (
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0"><MoreHorizontal className="h-4 w-4" /></Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="bg-gray-900 border-white/10 text-white">
                          <DropdownMenuItem onClick={() => handleUpdateStatus(req.id, 'approved')} className="text-green-400 focus:text-green-400 cursor-pointer"><Check className="mr-2 h-4 w-4" /> Approve</DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleUpdateStatus(req.id, 'rejected')} className="text-red-400 focus:text-red-400 cursor-pointer"><X className="mr-2 h-4 w-4" /> Reject</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    )}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default AdminTimeOffPage;