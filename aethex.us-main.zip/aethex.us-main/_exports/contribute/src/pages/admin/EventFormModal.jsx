import React from 'react';

const EventFormModal = () => {
  return null;
};

export default EventFormModal;