import React from 'react';

const AdminPagesPage = () => {
  return null;
};

export default AdminPagesPage;