import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { useSite } from '@/contexts/SiteContext';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardContent, CardDescription, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Loader2 } from 'lucide-react';
import { Switch } from '@/components/ui/switch';

const AdminSettingsPage = () => {
  const [editableSettings, setEditableSettings] = useState(null);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();
  const { siteId, siteConfig, loading: siteLoading, refreshSiteConfig } = useSite();

  useEffect(() => {
    if (siteConfig) {
      setEditableSettings(siteConfig);
    }
  }, [siteConfig]);

  const handleSave = useCallback(async (settingsToSave) => {
    if (!siteId) {
      toast({ variant: 'destructive', title: 'Error', description: 'Site ID is missing. Cannot save settings.' });
      return;
    }
    
    setSaving(true);
    try {
      const { error } = await supabase
        .from('site_config')
        .update(settingsToSave)
        .eq('site_id', siteId)
        .select()
        .single();

      if (error) throw error;
      
      toast({ title: 'Settings saved successfully' });
      await refreshSiteConfig();
    } catch (error) {
      toast({ variant: 'destructive', title: 'Error saving settings', description: error.message });
    } finally {
      setSaving(false);
    }
  }, [siteId, refreshSiteConfig, toast]);

  const handleInputChange = (e) => {
    const { id, value } = e.target;
    setEditableSettings(prev => ({ ...prev, [id]: value }));
  };

  const handleSwitchChange = (checked) => {
    const newStatus = checked ? 'maintenance' : 'online';
    const newSettings = { ...editableSettings, system_status: newStatus };
    setEditableSettings(newSettings);
    handleSave({ system_status: newStatus });
  };
  
  const handleGeneralSave = () => {
    if (!editableSettings) return;
    const settingsToSave = { 
      site_name: editableSettings.site_name, 
      site_description: editableSettings.site_description 
    };
    handleSave(settingsToSave);
  };

  const handleMessageSave = () => {
    if (!editableSettings) return;
    const settingsToSave = {
        system_status_message: editableSettings.system_status_message
    };
    handleSave(settingsToSave);
  };

  if (siteLoading || !editableSettings) {
    return <div className="flex justify-center items-center h-full"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  }
  
  const isMaintenanceMode = editableSettings.system_status === 'maintenance';

  return (
    <div>
      <h1 className="text-3xl font-bold text-white mb-8">Site Settings</h1>
      <div className="grid gap-8">
        <Card className="bg-gray-900/50 border-gray-800">
          <CardHeader>
            <CardTitle>General Settings</CardTitle>
            <CardDescription>Manage general site information and settings.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
             <div className="space-y-2">
              <Label htmlFor="site_id">Site ID</Label>
              <Input id="site_id" value={siteId || ''} readOnly disabled className="font-mono text-gray-400" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="site_name">Site Name</Label>
              <Input id="site_name" value={editableSettings.site_name || ''} onChange={handleInputChange} disabled={saving} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="site_description">Site Description</Label>
              <Textarea id="site_description" value={editableSettings.site_description || ''} onChange={handleInputChange} disabled={saving} />
            </div>
          </CardContent>
          <CardFooter className="border-t border-white/10 px-6 py-4">
            <Button onClick={handleGeneralSave} disabled={saving}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save General Settings
            </Button>
          </CardFooter>
        </Card>
        
        <Card className="bg-gray-900/50 border-gray-800">
          <CardHeader>
            <CardTitle>Maintenance Mode</CardTitle>
            <CardDescription>Put the site in maintenance mode to perform updates.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-2">
              <Switch 
                id="maintenance-mode" 
                checked={isMaintenanceMode} 
                onCheckedChange={handleSwitchChange}
                disabled={saving}
              />
              <Label htmlFor="maintenance-mode">Enable Maintenance Mode</Label>
            </div>
             {isMaintenanceMode && (
              <div className="space-y-2">
                <Label htmlFor="system_status_message">Maintenance Message</Label>
                <Textarea id="system_status_message" placeholder="e.g., We'll be back shortly!" value={editableSettings.system_status_message || ''} onChange={handleInputChange} disabled={saving} />
              </div>
            )}
          </CardContent>
          <CardFooter className="border-t border-white/10 px-6 py-4">
            <Button onClick={handleMessageSave} disabled={saving || !isMaintenanceMode}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save Maintenance Message
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default AdminSettingsPage;