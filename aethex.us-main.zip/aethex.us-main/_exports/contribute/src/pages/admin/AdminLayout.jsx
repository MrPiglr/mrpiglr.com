import React, { useState } from 'react';
import { NavLink, Outlet, Link } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { LayoutDashboard, Settings, Menu, X, Users, FolderGit2, Ticket } from 'lucide-react';
import { Button } from '@/components/ui/button';
import AeThexLogo from '@/components/AeThexLogo';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import NotificationBell from '@/components/NotificationBell';

const navItems = [
  { to: '/admin', icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/admin/contributors', icon: Users, label: 'Contributors' },
  { to: '/admin/projects', icon: FolderGit2, label: 'Projects' },
  { to: '/admin/tickets', icon: Ticket, label: 'Tickets' },
  { to: '/admin/settings', icon: Settings, label: 'Settings' },
];

const Sidebar = ({ isMobile, closeSidebar }) => (
  <aside className={`flex flex-col bg-slate-950/80 backdrop-blur-lg border-r border-white/10 ${isMobile ? 'w-64' : 'lg:w-64'}`}>
    <div className="p-4 flex items-center justify-between border-b border-white/10">
      <Link to="/" className="flex items-center gap-2">
        <AeThexLogo className="h-8" />
        <span className="font-bold text-lg">Contributor Admin</span>
      </Link>
      {isMobile && (
        <Button variant="ghost" size="icon" onClick={closeSidebar}>
          <X className="h-6 w-6" />
        </Button>
      )}
    </div>
    <nav className="flex-1 px-2 py-4 space-y-1">
      {navItems.map((item) => (
        <NavLink
          key={item.label}
          to={item.to}
          end={item.to === '/admin'}
          onClick={isMobile ? closeSidebar : undefined}
          className={({ isActive }) =>
            `flex items-center px-4 py-2 text-sm font-medium rounded-md transition-colors duration-200 ${
              isActive
                ? 'bg-primary/20 text-primary'
                : 'text-gray-300 hover:bg-slate-800/50 hover:text-white'
            }`
          }
        >
          <item.icon className="mr-3 h-5 w-5" />
          {item.label}
        </NavLink>
      ))}
    </nav>
  </aside>
);

const AdminLayout = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const { profile } = useAuth();
  const avatarUrl = profile?.avatar_url || `https://api.dicebear.com/7.x/bottts/svg?seed=${profile?.id}`;

  return (
    <div className="flex h-screen bg-slate-900 text-white font-mono">
      <div className="hidden lg:flex lg:flex-shrink-0">
        <Sidebar />
      </div>
      
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial={{ x: '-100%' }}
            animate={{ x: 0 }}
            exit={{ x: '-100%' }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="fixed inset-y-0 left-0 z-50 lg:hidden"
          >
            <Sidebar isMobile closeSidebar={() => setIsSidebarOpen(false)} />
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex flex-col w-0 flex-1 overflow-hidden">
        <header className="sticky top-0 z-30 lg:hidden flex items-center justify-between p-2 bg-slate-950/80 backdrop-blur-lg border-b border-white/10">
          <Button variant="ghost" size="icon" onClick={() => setIsSidebarOpen(true)}>
            <Menu className="h-6 w-6" />
          </Button>
          <div className="flex items-center gap-4">
            <NotificationBell />
            <img 
              src={avatarUrl}
              alt="User Avatar"
              className="h-8 w-8 rounded-full"
            />
          </div>
        </header>

        <main className="flex-1 relative overflow-y-auto focus:outline-none bg-grid-pattern">
          <div className="py-8 px-4 sm:px-6 lg:px-8">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;