import React from 'react';

const JobFormModal = () => {
  return null;
};

export default JobFormModal;