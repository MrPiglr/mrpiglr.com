import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { useSite } from '@/contexts/SiteContext';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Loader2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const AdminContributorsPage = () => {
    const [contributors, setContributors] = useState([]);
    const [loading, setLoading] = useState(true);
    const { toast } = useToast();
    const { siteId } = useSite();

    const fetchContributors = useCallback(async () => {
        if (!siteId) return;
        setLoading(true);

        const { data, error } = await supabase.rpc('get_all_users_for_site', { p_site_id: siteId });

        if (error) {
            console.error('Error fetching contributors:', error);
            toast({ variant: 'destructive', title: 'Error', description: 'Could not fetch contributors.' });
        } else {
            setContributors(data);
        }
        setLoading(false);
    }, [toast, siteId]);

    useEffect(() => {
        fetchContributors();
    }, [fetchContributors]);

    const getRoleVariant = (role) => {
        switch (role) {
            case 'site_owner': return 'default';
            case 'admin': return 'secondary';
            case 'oversee': return 'destructive';
            default: return 'outline';
        }
    }

    return (
        <>
            <div className="flex items-center justify-between mb-6">
                <div>
                    <h1 className="text-3xl font-bold text-white">Contributors</h1>
                    <p className="text-gray-400 mt-1">Manage all users contributing to this site.</p>
                </div>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>All Contributors</CardTitle>
                    <CardDescription>A total of {contributors.length} contributors.</CardDescription>
                </CardHeader>
                <CardContent>
                    {loading ? (
                        <div className="flex justify-center items-center p-16">
                            <Loader2 className="w-8 h-8 text-primary animate-spin" />
                        </div>
                    ) : (
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>User</TableHead>
                                    <TableHead>Email</TableHead>
                                    <TableHead className="text-right">Role</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {contributors.map((user) => (
                                    <TableRow key={user.id}>
                                        <TableCell className="font-medium">
                                            <div className="flex items-center gap-3">
                                                <img src={user.avatar_url} alt={user.username} className="w-8 h-8 rounded-full" />
                                                {user.username}
                                            </div>
                                        </TableCell>
                                        <TableCell>{user.email}</TableCell>
                                        <TableCell className="text-right">
                                            <Badge variant={getRoleVariant(user.role)} className="capitalize">{user.role.replace('_', ' ')}</Badge>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    )}
                </CardContent>
            </Card>
        </>
    );
};

export default AdminContributorsPage;