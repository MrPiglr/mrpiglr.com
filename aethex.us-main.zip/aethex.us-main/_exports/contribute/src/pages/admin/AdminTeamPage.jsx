import React from 'react';

const AdminTeamPage = () => {
  return null;
};

export default AdminTeamPage;