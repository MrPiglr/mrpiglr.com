import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, FolderGit2, Ticket, Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { useSite } from '@/contexts/SiteContext';

const StatCard = ({ title, value, icon: Icon, loading }) => {
  return (
    <Card className="bg-gray-900/40 border-white/10">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-gray-400">{title}</CardTitle>
        <Icon className="h-5 w-5 text-gray-500" />
      </CardHeader>
      <CardContent>
        {loading ? (
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
        ) : (
          <div className="text-2xl font-bold text-white">{value}</div>
        )}
      </CardContent>
    </Card>
  );
};

const AdminDashboardPage = () => {
    const { profile } = useAuth();
    const { siteId } = useSite();
    const [stats, setStats] = useState({ totalUsers: 0, activeProjects: 0, openTickets: 0 });
    const [loading, setLoading] = useState(true);
    
    useEffect(() => {
      const fetchStats = async () => {
        if (!siteId) return;
        setLoading(true);
        
        const { data, error } = await supabase.rpc('get_employee_management_stats', { p_site_id: siteId });

        if (error) {
          console.error("Error fetching dashboard stats:", error);
        } else {
          setStats(data);
        }
        setLoading(false);
      };

      fetchStats();
    }, [siteId]);
    
    return (
        <div>
            <div className="mb-8">
                <h1 className="text-3xl font-bold text-white">Welcome, {profile?.username || 'Admin'}!</h1>
                <p className="text-gray-400">Here's an overview of your contributor site.</p>
            </div>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
                <StatCard title="Total Contributors" value={stats.totalUsers} icon={Users} loading={loading} />
                <StatCard title="Active Projects" value={stats.activeProjects} icon={FolderGit2} loading={loading} />
                <StatCard title="Open Tickets" value={stats.openTickets} icon={Ticket} loading={loading} />
            </div>
            <div className="mt-8 text-center text-gray-500">
                <p>More detailed analytics will be available here soon.</p>
            </div>
        </div>
    );
};

export default AdminDashboardPage;