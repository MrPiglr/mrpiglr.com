import React from 'react';

const AdminAnnouncementsPage = () => {
  return null;
};

export default AdminAnnouncementsPage;