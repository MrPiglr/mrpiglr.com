import React from 'react';

const AdminJobsPage = () => {
  return null;
};

export default AdminJobsPage;