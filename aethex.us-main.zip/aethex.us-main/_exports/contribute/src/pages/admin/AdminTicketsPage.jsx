import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { useSite } from '@/contexts/SiteContext';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Loader2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { timeAgo } from '@/lib/utils';

const AdminTicketsPage = () => {
    const [tickets, setTickets] = useState([]);
    const [loading, setLoading] = useState(true);
    const { toast } = useToast();
    const { siteId } = useSite();

    const fetchTickets = useCallback(async () => {
        if (!siteId) return;
        setLoading(true);

        const { data, error } = await supabase
            .from('tickets')
            .select(`
                *,
                created_by:profiles!tickets_created_by_fkey(username, avatar_url),
                assigned_to:profiles!tickets_assigned_to_fkey(username, avatar_url)
            `)
            .eq('site_id', siteId)
            .order('created_at', { ascending: false });

        if (error) {
            console.error('Error fetching tickets:', error);
            toast({ variant: 'destructive', title: 'Error', description: 'Could not fetch tickets.' });
        } else {
            setTickets(data);
        }
        setLoading(false);
    }, [toast, siteId]);

    useEffect(() => {
        fetchTickets();
    }, [fetchTickets]);
    
    const getStatusVariant = (status) => {
        switch (status) {
            case 'Open': return 'success';
            case 'In Progress': return 'secondary';
            case 'Closed': return 'outline';
            default: return 'default';
        }
    }

    const getPriorityVariant = (priority) => {
        switch (priority) {
            case 'High': return 'destructive';
            case 'Medium': return 'warning';
            case 'Low': return 'success';
            default: return 'outline';
        }
    }

    return (
        <>
            <div className="flex items-center justify-between mb-6">
                <div>
                    <h1 className="text-3xl font-bold text-white">Tickets</h1>
                    <p className="text-gray-400 mt-1">Track and resolve contributor support tickets.</p>
                </div>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>All Tickets</CardTitle>
                    <CardDescription>A total of {tickets.length} tickets.</CardDescription>
                </CardHeader>
                <CardContent>
                    {loading ? (
                        <div className="flex justify-center items-center p-16">
                            <Loader2 className="w-8 h-8 text-primary animate-spin" />
                        </div>
                    ) : (
                        <Table>
                            <TableHeader>
                                <TableRow>
                                    <TableHead>Title</TableHead>
                                    <TableHead>Submitter</TableHead>
                                    <TableHead>Created</TableHead>
                                    <TableHead>Status</TableHead>
                                    <TableHead className="text-right">Priority</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {tickets.map((ticket) => (
                                    <TableRow key={ticket.id}>
                                        <TableCell className="font-medium">{ticket.title}</TableCell>
                                        <TableCell>
                                            {ticket.created_by ? (
                                                <div className="flex items-center gap-3">
                                                    <img src={ticket.created_by.avatar_url} alt={ticket.created_by.username} className="w-8 h-8 rounded-full" />
                                                    {ticket.created_by.username}
                                                </div>
                                            ) : 'N/A'}
                                        </TableCell>
                                        <TableCell>{timeAgo(ticket.created_at)}</TableCell>
                                        <TableCell><Badge variant={getStatusVariant(ticket.status)}>{ticket.status}</Badge></TableCell>
                                        <TableCell className="text-right">
                                            <Badge variant={getPriorityVariant(ticket.priority)}>{ticket.priority}</Badge>
                                        </TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    )}
                </CardContent>
            </Card>
        </>
    );
};

export default AdminTicketsPage;