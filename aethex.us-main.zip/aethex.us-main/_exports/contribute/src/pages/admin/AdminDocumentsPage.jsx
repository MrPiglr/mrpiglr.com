import React from 'react';

const AdminDocumentsPage = () => {
  return null;
};

export default AdminDocumentsPage;