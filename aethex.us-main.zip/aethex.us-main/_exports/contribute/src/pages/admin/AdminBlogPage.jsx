import React from 'react';

const AdminBlogPage = () => {
  return null;
};

export default AdminBlogPage;