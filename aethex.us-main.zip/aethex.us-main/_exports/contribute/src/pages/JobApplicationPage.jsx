import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useDropzone } from 'react-dropzone';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Loader2, ArrowLeft, Briefcase, MapPin, UploadCloud, FileText, Trash2, ShieldCheck } from 'lucide-react';

const JobApplicationPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();

  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [coverLetter, setCoverLetter] = useState('');
  const [resumeFile, setResumeFile] = useState(null);

  useEffect(() => {
    const fetchJob = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('job_openings')
        .select('*')
        .eq('id', id)
        .single();
      
      if (error || !data) {
        toast({ variant: 'destructive', title: 'Error', description: 'Could not find the job opening.' });
        navigate('/');
        return;
      }
      setJob(data);

      const { data: application, error: appError } = await supabase
        .from('job_applications')
        .select('id')
        .eq('user_id', user.id)
        .eq('job_id', id)
        .maybeSingle();

      if (application) {
        toast({ title: 'Already Applied', description: "You have already applied for this position." });
        navigate(`/job/${id}`);
      }
      
      setLoading(false);
    };

    if (user) {
      fetchJob();
    }
  }, [id, user, navigate, toast]);

  const onDrop = (acceptedFiles) => {
    if (acceptedFiles.length > 0) {
      const file = acceptedFiles[0];
      if(file.size > 5 * 1024 * 1024) {
        toast({
          variant: "destructive",
          title: "File too large",
          description: "Resume file must be under 5MB.",
        });
        return;
      }
      setResumeFile(file);
    }
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'application/pdf': ['.pdf'] },
    maxFiles: 1,
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!resumeFile) {
      toast({ variant: 'destructive', title: 'Resume Required', description: 'Please upload your resume to apply.' });
      return;
    }
    
    setIsSubmitting(true);
    let resumeUrl = null;

    try {
      const fileExt = resumeFile.name.split('.').pop();
      const fileName = `${user.id}-${Date.now()}.${fileExt}`;
      const filePath = `resumes/${fileName}`;
      
      const { error: uploadError } = await supabase.storage
        .from('job-applications')
        .upload(filePath, resumeFile);

      if (uploadError) throw uploadError;

      const { data: urlData } = supabase.storage
        .from('job-applications')
        .getPublicUrl(filePath);

      resumeUrl = urlData.publicUrl;

      const { error: insertError } = await supabase
        .from('job_applications')
        .insert({
          job_id: job.id,
          user_id: user.id,
          status: 'submitted',
          cover_letter: coverLetter,
          resume_url: resumeUrl,
          submitted_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        });
      
      if (insertError) throw insertError;
      
      toast({
        variant: "success",
        title: "Application Submitted!",
        description: `Your application for ${job.title} has been received.`,
      });
      navigate('/my-applications');
    } catch (error) {
       toast({
        variant: "destructive",
        title: "Application Failed",
        description: error.message,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <Loader2 className="w-12 h-12 text-primary animate-spin" />
      </div>
    );
  }

  if (!job) return null;

  return (
    <>
      <Helmet>
        <title>{`Apply for ${job.title} - AeThex Careers`}</title>
        <meta name="description" content={`Submit your application for the ${job.title} role at AeThex.`} />
      </Helmet>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="mb-8">
          <Button asChild variant="ghost" className="mb-4">
            <Link to={`/job/${id}`} className="flex items-center text-gray-400 hover:text-white">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Job Details
            </Link>
          </Button>
        </div>
        
        <div className="max-w-4xl mx-auto">
          <Card>
            <CardHeader className="text-center">
              <CardTitle className="text-3xl font-bold">Apply for {job.title}</CardTitle>
              <CardDescription className="flex justify-center items-center gap-4 pt-2">
                <span className="flex items-center gap-1.5"><Briefcase className="w-4 h-4 text-primary" /> {job.division} / {job.department}</span>
                <span className="flex items-center gap-1.5"><MapPin className="w-4 h-4 text-primary" /> {job.location}</span>
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-8">
                <div className="space-y-2">
                  <Label htmlFor="coverLetter">Cover Letter (Optional)</Label>
                  <Textarea
                    id="coverLetter"
                    placeholder="Tell us why you're a great fit for this equity-track role..."
                    value={coverLetter}
                    onChange={(e) => setCoverLetter(e.target.value)}
                    rows={8}
                    className="bg-gray-900/50"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="resume">Resume (PDF, max 5MB)</Label>
                  <div 
                    {...getRootProps()} 
                    className={`flex justify-center items-center w-full px-6 py-10 border-2 border-dashed rounded-lg cursor-pointer transition-colors ${isDragActive ? 'border-primary bg-primary/10' : 'border-gray-700 hover:border-gray-600'}`}
                  >
                    <input {...getInputProps()} />
                    <div className="text-center">
                      <UploadCloud className="w-12 h-12 mx-auto text-gray-500 mb-3" />
                      <p className="font-semibold text-white">
                        {isDragActive ? "Drop the file here..." : "Drag & drop your resume here, or click to select"}
                      </p>
                      <p className="text-xs text-gray-500">PDF format only, up to 5MB</p>
                    </div>
                  </div>
                  {resumeFile && (
                    <div className="mt-4 flex items-center justify-between p-3 bg-gray-800 rounded-md">
                      <div className="flex items-center gap-3">
                        <FileText className="w-6 h-6 text-primary" />
                        <span className="text-sm text-white">{resumeFile.name}</span>
                      </div>
                      <Button type="button" variant="destructive" size="icon" onClick={() => setResumeFile(null)}>
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                </div>

                <div className="flex flex-col items-center space-y-4">
                  <div className="flex items-center space-x-2 text-sm text-green-400">
                    <ShieldCheck className="w-5 h-5"/>
                    <span>By submitting, you agree to our NDA and the terms of this equity-based role.</span>
                  </div>
                  <Button type="submit" size="lg" className="w-full max-w-xs" disabled={isSubmitting}>
                    {isSubmitting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Submitting Application
                      </>
                    ) : "Confirm & Submit Application"}
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      </motion.div>
    </>
  );
};

export default JobApplicationPage;