import React, { useEffect, useState } from 'react';
import { Helmet } from 'react-helmet';
import { AnimatePresence, motion } from 'framer-motion';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import EventCard from '@/components/EventCard';
import EventCardSkeleton from '@/components/EventCardSkeleton';
import EventDetailModal from '@/components/EventDetailModal';
import { useEvents } from '@/hooks/useEvents';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Ticket, ArrowLeft } from 'lucide-react';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const MyEventsPage = () => {
  const { user } = useAuth();
  const [myEvents, setMyEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedEvent, setSelectedEvent] = useState(null);
  
  const { 
    getCategoryColor, 
    getCategoryLabel, 
    handleUnregister, 
    registrationLoading, 
    registeredEvents,
    handleRegister
  } = useEvents();

  useEffect(() => {
    const fetchMyEvents = async () => {
      if (!user) {
        setLoading(false);
        return;
      }
      setLoading(true);
      const { data, error } = await supabase
        .from('aethex_event_registrations')
        .select(`
          aethex_events (
            *,
            aethex_event_registrations (count)
          )
        `)
        .eq('user_id', user.id);

      if (error) {
        console.error('Error fetching my events:', error);
        setMyEvents([]);
      } else {
        const formattedEvents = data.map(item => ({
            ...item.aethex_events,
            registered: item.aethex_events.aethex_event_registrations[0]?.count || 0,
        }));
        setMyEvents(formattedEvents);
      }
      setLoading(false);
    };

    fetchMyEvents();
  }, [user]);

  return (
    <>
      <Helmet>
        <title>My Registered Events - AeThex</title>
        <meta name="description" content="View and manage all the AeThex events you are registered for." />
      </Helmet>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -20 }}
        transition={{ duration: 0.5 }}
      >
        <div className="mb-8 flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white">My Registered Events</h1>
              <p className="text-gray-400 mt-1">Here are all the upcoming events you've signed up for.</p>
            </div>
            <Button asChild variant="outline">
              <Link to="/" className="flex items-center">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to All Events
              </Link>
            </Button>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(3)].map((_, i) => <EventCardSkeleton key={i} />)}
          </div>
        ) : myEvents.length > 0 ? (
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            <AnimatePresence>
              {myEvents.map((event) => (
                <EventCard
                  key={event.id}
                  event={event}
                  onSelectEvent={setSelectedEvent}
                  getCategoryColor={getCategoryColor}
                  getCategoryLabel={getCategoryLabel}
                />
              ))}
            </AnimatePresence>
          </motion.div>
        ) : (
          <div className="text-center py-16 bg-gray-900/30 rounded-2xl border border-gray-800">
            <Ticket className="w-16 h-16 mx-auto text-primary mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">No Registered Events</h2>
            <p className="text-gray-400 mb-6">You haven't registered for any events yet.</p>
            <Button asChild>
                <Link to="/">Explore Events</Link>
            </Button>
          </div>
        )}
      </motion.div>

      <AnimatePresence>
        {selectedEvent && (
          <EventDetailModal
            event={selectedEvent}
            onClose={() => setSelectedEvent(null)}
            onRegister={() => handleRegister(selectedEvent.id)}
            onUnregister={handleUnregister}
            isRegistered={registeredEvents.includes(selectedEvent.id)}
            getCategoryColor={getCategoryColor}
            getCategoryLabel={getCategoryLabel}
            isLoading={registrationLoading}
          />
        )}
      </AnimatePresence>
    </>
  );
};

export default MyEventsPage;