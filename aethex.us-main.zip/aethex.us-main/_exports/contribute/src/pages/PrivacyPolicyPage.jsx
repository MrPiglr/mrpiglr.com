import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';

const PrivacyPolicyPage = () => {
    return (
        <>
            <Helmet>
                <title>Privacy Policy | AeThex</title>
                <meta name="description" content="Read the AeThex privacy policy to understand how we collect, store, and use your personal data to provide our services." />
                <meta property="og:title" content="Privacy Policy | AeThex" />
                <meta property="og:description" content="Learn how AeThex handles user data with a commitment to privacy and transparency." />
            </Helmet>
            <motion.div 
                className="prose prose-invert prose-lg max-w-4xl mx-auto py-16"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ staggerChildren: 0.2 }}
            >
                <motion.h1
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    Privacy Policy
                </motion.h1>
                <motion.p 
                    className="text-gray-400"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 }}
                >
                    Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
                </motion.p>
                <motion.p
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                >
                    AeThex ("us", "we", or "our") operates this website (the "Service"). This page informs you of our policies regarding the collection, use, and disclosure of personal data when you use our Service and the choices you have associated with that data. Our commitment is to user sovereignty and data minimization.
                </motion.p>
                
                <motion.h2 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>Information Collection and Use</motion.h2>
                <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
                    We collect only the data that is essential for the functionality of our services and for securing our network. This includes:
                </motion.p>
                <motion.ul initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>
                    <li><strong>Account Information:</strong> When you create an account, we may ask for information such as your username and email address to create and manage your contributor profile.</li>
                    <li><strong>Contact Form Submissions:</strong> When you contact us via our contact form, we collect your name, email, and message content to respond to your inquiries.</li>
                    <li><strong>Usage Data:</strong> We may collect anonymous data on how the Service is accessed and used to improve our offerings. This data is aggregated and cannot be used to identify you personally.</li>
                </motion.ul>

                <motion.h2 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}>Data Use</motion.h2>
                <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7 }}>
                    AeThex uses the collected data for various purposes:
                </motion.p>
                <motion.ul initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.8 }}>
                    <li>To provide and maintain our Service</li>
                    <li>To notify you about changes to our Service</li>
                    <li>To allow you to participate in interactive features of our Service when you choose to do so</li>
                    <li>To provide customer support</li>
                    <li>To monitor the usage of our Service to detect, prevent and address technical issues</li>
                </motion.ul>

                <motion.h2 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.9 }}>Data Security</motion.h2>
                <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.0 }}>
                    The security of your data is important to us. We strive to use commercially acceptable means to protect your Personal Data, but remember that no method of transmission over the Internet or method of electronic storage is 100% secure. We do not sell, trade, or otherwise transfer your personally identifiable information to outside parties.
                </motion.p>

                 <motion.h2 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.1 }}>Changes to This Privacy Policy</motion.h2>
                <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.2 }}>
                    We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page. You are advised to review this Privacy Policy periodically for any changes.
                </motion.p>
            </motion.div>
        </>
    );
};

export default PrivacyPolicyPage;