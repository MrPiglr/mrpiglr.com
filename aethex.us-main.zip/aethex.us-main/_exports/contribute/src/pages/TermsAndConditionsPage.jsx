import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';

const TermsAndConditionsPage = () => {
    return (
        <>
            <Helmet>
                <title>Terms and Conditions | AeThex</title>
                <meta name="description" content="Read the AeThex Terms and Conditions to understand the rules and guidelines for using our website and services." />
                <meta property="og:title" content="Terms and Conditions | AeThex" />
                <meta property="og:description" content="Review the terms of service for the AeThex platform." />
            </Helmet>
            <motion.div 
                className="prose prose-invert prose-lg max-w-4xl mx-auto py-16"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ staggerChildren: 0.2 }}
            >
                <motion.h1
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                >
                    Terms and Conditions
                </motion.h1>
                <motion.p 
                    className="text-gray-400"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 }}
                >
                    Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}
                </motion.p>
                <motion.p
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                >
                    Welcome to AeThex. These terms and conditions outline the rules and regulations for the use of our website. By accessing this website, we assume you accept these terms and conditions. Do not continue to use AeThex if you do not agree to all of the terms and conditions stated on this page.
                </motion.p>
                
                <motion.h2 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>1. Intellectual Property Rights</motion.h2>
                <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
                    Other than the content you own, under these Terms, AeThex and/or its licensors own all the intellectual property rights and materials contained in this Website. You are granted a limited license only for purposes of viewing the material contained on this Website. Contributor-owned content remains the property of the contributor.
                </motion.p>

                <motion.h2 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }}>2. Restrictions</motion.h2>
                <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6 }}>
                    You are specifically restricted from all of the following:
                </motion.p>
                <motion.ul initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.7 }}>
                    <li>Publishing any Website material in any other media without citation.</li>
                    <li>Selling, sublicensing and/or otherwise commercializing any Website material.</li>
                    <li>Using this Website in any way that is or may be damaging to this Website.</li>
                    <li>Using this Website contrary to applicable laws and regulations, or in any way may cause harm to the Website, or to any person or business entity.</li>
                    <li>Engaging in any data mining, data harvesting, data extracting or any other similar activity in relation to this Website.</li>
                </motion.ul>

                <motion.h2 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.8 }}>3. Limitation of Liability</motion.h2>
                <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.9 }}>
                    In no event shall AeThex, nor any of its officers, directors and contributors, be held liable for anything arising out of or in any way connected with your use of this Website whether such liability is under contract. AeThex, including its officers, directors and contributors shall not be held liable for any indirect, consequential or special liability arising out of or in any way related to your use of this Website.
                </motion.p>

                <motion.h2 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.0 }}>4. Governing Law & Jurisdiction</motion.h2>
                <motion.p initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.1 }}>
                    These Terms will be governed by and interpreted in accordance with the laws of the jurisdiction in which the company is registered, and you submit to the non-exclusive jurisdiction of the state and federal courts located in such jurisdiction for the resolution of any disputes.
                </motion.p>
            </motion.div>
        </>
    );
};

export default TermsAndConditionsPage;