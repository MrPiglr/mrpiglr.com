import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';

const NewsPage = () => {
    // Placeholder content. In a real app, this would come from the blog_posts table.
    return (
        <>
            <Helmet>
                <title>News & Press | AeThex</title>
                <meta name="description" content="The latest news, announcements, and press mentions from AeThex." />
            </Helmet>
            <div className="text-center mb-16">
                <motion.h1 
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-5xl md:text-7xl font-bold tracking-tighter mb-4 font-mono"
                >
                    News & <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">Updates</span>
                </motion.h1>
                <motion.p 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 }}
                    className="text-lg md:text-xl text-gray-400 max-w-3xl mx-auto"
                >
                    This section is under construction. Check back soon for the latest from AeThex.
                </motion.p>
            </div>
        </>
    );
};

export default NewsPage;