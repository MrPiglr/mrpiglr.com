import { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';

const CATEGORIES = {
  'tech-summit': { label: 'Tech Summit', color: 'bg-blue-500' },
  'dev-workshop': { label: 'Dev Workshop', color: 'bg-green-500' },
  'product-launch': { label: 'Product Launch', color: 'bg-purple-500' },
  'networking-mixer': { label: 'Networking Mixer', color: 'bg-yellow-500' },
};

export const useEvents = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [registrationLoading, setRegistrationLoading] = useState(false);
  const [registeredEvents, setRegisteredEvents] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const fetchEvents = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('aethex_events')
      .select('*, aethex_event_registrations(count)');

    if (error) {
      console.error('Error fetching events:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Could not fetch events.",
      });
      setEvents([]);
    } else {
      const formattedEvents = data.map(event => ({
        ...event,
        registered_count: event.aethex_event_registrations[0]?.count || 0,
      }));
      setEvents(formattedEvents);
    }
    setLoading(false);
  }, [toast]);

  const fetchRegisteredEvents = useCallback(async () => {
    if (!user) {
      setRegisteredEvents([]);
      return;
    }
    const { data, error } = await supabase
      .from('aethex_event_registrations')
      .select('event_id')
      .eq('user_id', user.id);

    if (error) {
      console.error('Error fetching registered events:', error);
    } else {
      setRegisteredEvents(data.map(reg => reg.event_id));
    }
  }, [user]);

  useEffect(() => {
    fetchEvents();
  }, [fetchEvents]);
  
  useEffect(() => {
    fetchRegisteredEvents();
  }, [user, fetchRegisteredEvents]);

  const handleRegister = useCallback(async (eventId) => {
    if (!user) {
      toast({
        variant: "destructive",
        title: "Authentication Required",
        description: "You must be signed in to register for an event.",
      });
      return;
    }
    setRegistrationLoading(true);
    const { error } = await supabase
      .from('aethex_event_registrations')
      .insert({ event_id: eventId, user_id: user.id });

    if (error) {
      console.error('Error registering for event:', error);
      toast({
        variant: "destructive",
        title: "Registration Failed",
        description: error.message,
      });
    } else {
      toast({
        variant: "success",
        title: "Registration Successful!",
        description: "You've successfully registered for the event and earned 100 loyalty points!",
      });
      setRegisteredEvents(prev => [...prev, eventId]);
      setEvents(prevEvents => prevEvents.map(event => 
        event.id === eventId ? { ...event, registered_count: event.registered_count + 1 } : event
      ));
    }
    setRegistrationLoading(false);
  }, [user, toast]);

  const handleUnregister = useCallback(async (eventId) => {
    if (!user) return;
    setRegistrationLoading(true);
    const { error } = await supabase
      .from('aethex_event_registrations')
      .delete()
      .match({ event_id: eventId, user_id: user.id });

    if (error) {
      console.error('Error unregistering from event:', error);
      toast({
        variant: "destructive",
        title: "Unregistration Failed",
        description: error.message,
      });
    } else {
      toast({
        title: "Unregistered Successfully",
        description: "You have been unregistered from the event.",
      });
      setRegisteredEvents(prev => prev.filter(id => id !== eventId));
      setEvents(prevEvents => prevEvents.map(event => 
        event.id === eventId ? { ...event, registered_count: Math.max(0, event.registered_count - 1) } : event
      ));
    }
    setRegistrationLoading(false);
  }, [user, toast]);
  
  const filteredEvents = useMemo(() => {
    return events
      .filter(event => 
        event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        event.description.toLowerCase().includes(searchTerm.toLowerCase())
      )
      .filter(event => 
        selectedCategory === 'all' || event.category === selectedCategory
      );
  }, [events, searchTerm, selectedCategory]);

  const getCategoryColor = useCallback((category) => {
    return CATEGORIES[category]?.color || 'bg-gray-500';
  }, []);

  const getCategoryLabel = useCallback((category) => {
    return CATEGORIES[category]?.label || 'General';
  }, []);

  const categories = useMemo(() => ['all', ...Object.keys(CATEGORIES)], []);

  return {
    events,
    filteredEvents,
    loading,
    registrationLoading,
    registeredEvents,
    searchTerm,
    setSearchTerm,
    selectedCategory,
    setSelectedCategory,
    handleRegister,
    handleUnregister,
    getCategoryColor,
    getCategoryLabel,
    categories,
  };
};