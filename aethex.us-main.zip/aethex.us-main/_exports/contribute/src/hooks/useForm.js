import { useState, useCallback } from 'react';

export const useForm = (initialState = {}) => {
  const [values, setValues] = useState(initialState);

  const reset = useCallback(() => {
    setValues(initialState);
  }, [initialState]);

  const handleInputChange = useCallback(({ target }) => {
    setValues(prev => ({
      ...prev,
      [target.name]: target.type === 'checkbox' ? target.checked : target.value,
    }));
  }, []);

  return { values, setValues, handleInputChange, reset };
};