import React, { createContext, useState, useEffect, useContext, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';

const SupabaseAuthContext = createContext(null);

export const useAuth = () => {
  const context = useContext(SupabaseAuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const { toast } = useToast();

  const fetchProfile = useCallback(async (userId) => {
    if (!userId) return null;
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();
      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching profile:', error.message);
        return null;
      };
      return data || null;
    } catch (error) {
      console.error('Error fetching profile:', error.message);
      return null;
    }
  }, []);

  const handleAuthStateChange = useCallback(async (event, session) => {
    setLoading(true);
    setSession(session);
    const currentUser = session?.user ?? null;
    setUser(currentUser);

    if (currentUser) {
      const userProfile = await fetchProfile(currentUser.id);
      setProfile(userProfile);
    } else {
      setProfile(null);
    }
    
    if (event === 'SIGNED_IN') {
      setShowAuthModal(false);
      toast({
        title: "Signed In Successfully",
        description: `Welcome back, ${session?.user.email}!`,
      });
    }
    if (event === 'SIGNED_OUT') {
      setProfile(null);
      setUser(null);
      setSession(null);
      // No toast on programmatic sign-out to avoid duplicate messages.
    }
     if (event === 'TOKEN_REFRESHED' && session === null) {
      // This case handles the "Invalid Refresh Token" error implicitly.
      // Supabase sets session to null after a failed refresh.
      signOut(true); // Pass true to show a toast
    }
    setLoading(false);
  }, [fetchProfile, toast]);

  useEffect(() => {
    setLoading(true);
    supabase.auth.getSession().then(({ data: { session }, error }) => {
       if (error && error.message.includes('Invalid Refresh Token')) {
        signOut(true);
      } else {
        handleAuthStateChange('INITIAL_SESSION', session);
      }
    }).finally(() => setLoading(false));

    const { data: authListener } = supabase.auth.onAuthStateChange(handleAuthStateChange);
    return () => {
      authListener.subscription.unsubscribe();
    };
  }, [handleAuthStateChange]);

  const signIn = async (email, password) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      toast({
        variant: "destructive",
        title: "Sign In Failed",
        description: error.message,
      });
    }
    return { error };
  };

  const signUp = async (email, password) => {
    const { error } = await supabase.auth.signUp({ email, password });
    if (error) {
      toast({
        variant: "destructive",
        title: "Sign Up Failed",
        description: error.message,
      });
    }
    return { error };
  };

  const signOut = async (showSessionExpiredToast = false) => {
    const { error } = await supabase.auth.signOut();
     if (error) {
      toast({
        variant: "destructive",
        title: "Sign Out Failed",
        description: error.message,
      });
    } else {
      if (showSessionExpiredToast) {
        toast({
          variant: "destructive",
          title: "Session Expired",
          description: "Your session has expired. Please sign in again.",
        });
      } else {
        toast({
          title: "Signed Out",
          description: "You have been successfully signed out.",
        });
      }
    }
    setProfile(null);
    setUser(null);
    setSession(null);
    return { error };
  };
  
  const sendPasswordResetEmail = async (email) => {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/password-reset`,
    });
    if (error) {
      toast({
        variant: "destructive",
        title: "Error Sending Email",
        description: error.message,
      });
    }
    return { error };
  };
  
  const signInWithProvider = async (provider) => {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: provider,
      options: {
        redirectTo: window.location.origin,
      },
    });
    if (error) {
      toast({
        variant: "destructive",
        title: `${provider} Sign In Failed`,
        description: error.message,
      });
    }
    return { error };
  };

  const value = useMemo(() => ({
    user,
    profile,
    session,
    loading,
    showAuthModal,
    setShowAuthModal,
    signIn,
    signUp,
    signOut,
    signInWithGitHub: () => signInWithProvider('github'),
    signInWithGoogle: () => signInWithProvider('google'),
    sendPasswordResetEmail,
  }), [user, profile, session, loading, showAuthModal]);

  return (
    <SupabaseAuthContext.Provider value={value}>
      {children}
    </SupabaseAuthContext.Provider>
  );
};