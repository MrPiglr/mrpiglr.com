import React, { createContext, useContext, useEffect, useState, useMemo, useCallback } from 'react';
import { supabase } from '@/lib/customSupabaseClient';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const SiteContext = createContext(undefined);

const SITE_NAME = "AeThex Corporate";

export const SiteProvider = ({ children }) => {
  const { toast } = useToast();
  const { user, profile, loading: authLoading } = useAuth();
  const [siteId, setSiteId] = useState(null);
  const [siteConfig, setSiteConfig] = useState(null);
  const [loading, setLoading] = useState(true);

  const initializeSite = useCallback(async (currentUser, currentUserProfile) => {
    if (!currentUser || !currentUserProfile) {
      setSiteId(null);
      setSiteConfig(null);
      setLoading(false);
      return;
    }
    
    setLoading(true);
    try {
      const { data, error } = await supabase.rpc('get_or_create_site_config', {
        p_site_name: SITE_NAME
      });

      if (error) {
        throw error;
      }

      if (data && data.length > 0) {
        const config = data[0];
        setSiteConfig(config);
        setSiteId(config.site_id);
      } else {
        // This case should ideally not be reached due to the function's design,
        // but it's good practice to handle it.
        toast({
          variant: "warning",
          title: "Site Not Found",
          description: "Could not retrieve or create site configuration.",
        });
        setSiteId(null);
        setSiteConfig(null);
      }
    } catch (error) {
      console.error("Error initializing site:", error);
      toast({
        variant: "destructive",
        title: "Site Initialization Failed",
        description: error.message || "Could not initialize the site.",
      });
      setSiteId(null);
      setSiteConfig(null);
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    if (!authLoading) {
      initializeSite(user, profile);
    }
  }, [user, profile, authLoading, initializeSite]);

  const refreshSiteConfig = useCallback(async () => {
    if (user && profile) {
      await initializeSite(user, profile);
    }
  }, [user, profile, initializeSite]);

  const value = useMemo(() => ({
    siteId,
    siteConfig,
    loading: authLoading || loading,
    refreshSiteConfig,
  }), [siteId, siteConfig, authLoading, loading, refreshSiteConfig]);

  return <SiteContext.Provider value={value}>{children}</SiteContext.Provider>;
};

export const useSite = () => {
  const context = useContext(SiteContext);
  if (context === undefined) {
    throw new Error('useSite must be used within a SiteProvider');
  }
  return context;
};