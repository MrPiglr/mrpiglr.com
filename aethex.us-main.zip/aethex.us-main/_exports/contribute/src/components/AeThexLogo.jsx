import React from 'react';

const AeThexLogo = ({ className, hideText }) => (
  <div className={`flex items-center gap-3 ${className}`}>
    <img 
      src="https://horizons-cdn.hostinger.com/1edbdcc3-df77-45f9-bc30-9f11766aa973/1df388aa94d930bbeb7ed03cb7a60888.png"
      alt="AeThex Company Logo - Stylized Blue and Silver Symbol"
      className="h-full w-auto" 
    />
    {!hideText && (
      <span className="font-bold text-2xl tracking-tighter text-white font-mono">
        AETHEX
      </span>
    )}
  </div>
);

export default AeThexLogo;