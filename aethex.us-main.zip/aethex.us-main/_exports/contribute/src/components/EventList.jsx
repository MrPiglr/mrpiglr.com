import React, { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import EventCard from '@/components/EventCard';
import EventCardSkeleton from '@/components/EventCardSkeleton';
import { Search, SlidersHorizontal } from 'lucide-react';
import { useEvents } from '@/hooks/useEvents';

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const EventList = ({ loading, filteredEvents, onSelectEvent, getCategoryColor, getCategoryLabel, setSearchTerm, setSelectedCategory }) => {
  const { categories } = useEvents();
  const [showFilters, setShowFilters] = useState(false);
  
  return (
    <>
      <div className="mb-12 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white tracking-tight">AeThex Events</h1>
          <p className="mt-4 text-lg text-gray-300 max-w-2xl mx-auto">
              Explore our upcoming conferences, workshops, and networking opportunities.
          </p>
      </div>

      <div className="mb-8 flex flex-col md:flex-row gap-4 items-center">
        <div className="relative w-full md:flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
          <input
            type="text"
            placeholder="Search events by title, topic, or location..."
            className="w-full bg-gray-900/50 border border-gray-700/50 rounded-lg pl-12 pr-4 py-3 text-white focus:ring-2 focus:ring-primary focus:border-primary transition"
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="relative">
          <button onClick={() => setShowFilters(!showFilters)} className="flex items-center gap-2 bg-gray-900/50 border border-gray-700/50 px-4 py-3 rounded-lg hover:border-primary/50 transition-colors">
            <SlidersHorizontal className="w-5 h-5 text-gray-400" />
            <span className="text-white">Filters</span>
          </button>
          <AnimatePresence>
            {showFilters && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="absolute right-0 mt-2 w-48 bg-gray-900 border border-gray-800 rounded-lg shadow-lg p-2 z-20"
              >
                {categories.map(category => (
                  <button
                    key={category}
                    onClick={() => {
                      setSelectedCategory(category);
                      setShowFilters(false);
                    }}
                    className="w-full text-left px-3 py-2 rounded text-sm text-gray-300 hover:bg-gray-800"
                  >
                    {getCategoryLabel(category)}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[...Array(6)].map((_, i) => (
            <EventCardSkeleton key={i} />
          ))}
        </div>
      ) : (
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          <AnimatePresence>
            {filteredEvents.map((event) => (
              <EventCard
                key={event.id}
                event={event}
                onSelectEvent={onSelectEvent}
                getCategoryColor={getCategoryColor}
                getCategoryLabel={getCategoryLabel}
              />
            ))}
          </AnimatePresence>
        </motion.div>
      )}

      {filteredEvents.length === 0 && !loading && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center py-16"
        >
          <motion.div 
            className="text-6xl mb-4"
            animate={{ rotate: [0, 10, -10, 10, 0], scale: [1, 1.1, 1] }}
            transition={{ duration: 1, repeat: Infinity, repeatDelay: 2 }}
          >
            🔍
          </motion.div>
          <h3 className="text-2xl font-bold text-white mb-2">No events found</h3>
          <p className="text-gray-400">Try adjusting your search or filter criteria.</p>
        </motion.div>
      )}
    </>
  );
};

export default EventList;