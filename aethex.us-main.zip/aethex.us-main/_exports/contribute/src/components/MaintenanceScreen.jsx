import React from 'react';
import { motion } from 'framer-motion';
import AeThexLogo from '@/components/AeThexLogo';
import { HardDrive } from 'lucide-react';

const MaintenanceScreen = ({ message }) => {
  const defaultMessage = "We're currently performing scheduled maintenance. We'll be back online shortly. Thank you for your patience!";
  
  return (
    <div className="flex items-center justify-center min-h-screen bg-[#06080d] text-white font-sans p-4">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="text-center max-w-2xl"
      >
        <div className="flex justify-center mb-8">
          <div className="relative w-24 h-24 bg-slate-900/50 rounded-3xl flex items-center justify-center border border-primary/20 backdrop-blur-sm p-4">
            <div className="absolute -inset-2 bg-primary/20 rounded-[28px] blur-xl opacity-75"></div>
            <AeThexLogo className="h-full" hideText />
          </div>
        </div>
        
        <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4 flex items-center justify-center gap-4">
          <HardDrive className="w-10 h-10" />
          Under Maintenance
        </h1>
        <p className="text-lg text-gray-300 mb-2">
          Our site is temporarily unavailable.
        </p>
        <p className="text-md text-gray-400">
          {message || defaultMessage}
        </p>
      </motion.div>
    </div>
  );
};

export default MaintenanceScreen;