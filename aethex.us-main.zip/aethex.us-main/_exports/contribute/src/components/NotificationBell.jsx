import React from 'react';
import { Bell, MessageSquare, Briefcase, UserPlus } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuFooter
} from "@/components/ui/dropdown-menu";
import { Button } from './ui/button';
import { useNotifications } from '@/contexts/NotificationContext';
import { timeAgo } from '@/lib/utils';
import { Link, useNavigate } from 'react-router-dom';

const NotificationIcon = ({ type }) => {
    switch (type) {
        case 'new_message':
            return <MessageSquare className="w-5 h-5 text-blue-400" />;
        case 'new_job_application':
            return <Briefcase className="w-5 h-5 text-green-400" />;
        case 'user_joined':
             return <UserPlus className="w-5 h-5 text-purple-400" />;
        default:
            return <Bell className="w-5 h-5 text-gray-400" />;
    }
}

const getNotificationDetails = (notification) => {
    const { type, data } = notification;
    switch(type) {
        case 'new_message':
            return {
                text: <p>New message from <strong>{data.sender_username}</strong>: "{data.message_preview}..."</p>,
                link: `/messages/${data.conversation_id}`
            };
        case 'new_job_application':
            return {
                text: <p>New application for <strong>{data.job_title}</strong> from {data.applicant_username}.</p>,
                link: `/admin/applications/${data.application_id}`
            };
        case 'user_joined':
            return {
                text: <p><strong>{data.username}</strong> just joined the platform!</p>,
                link: `/profile/${data.user_id}`
            };
        default:
            return {
                text: <p>{data.message || 'New notification'}</p>,
                link: '#'
            };
    }
};

const NotificationItem = ({ notification }) => {
    const { markAsRead } = useNotifications();
    const navigate = useNavigate();
    const { text, link } = getNotificationDetails(notification);

    const handleClick = (e) => {
        e.preventDefault();
        markAsRead(notification.id);
        navigate(link);
    }
    
    return (
        <DropdownMenuItem
            className={`p-3 flex items-start gap-3 cursor-pointer focus:bg-gray-800 ${!notification.is_read ? 'bg-primary/10' : ''}`}
            onSelect={handleClick}
        >
            <div className="flex-shrink-0 mt-1">
                <NotificationIcon type={notification.type} />
            </div>
            <div className="w-full">
                <div className="text-sm text-gray-300">{text}</div>
                <p className="text-xs text-gray-500 mt-1">{timeAgo(notification.created_at)}</p>
            </div>
        </DropdownMenuItem>
    )
}

const NotificationBell = () => {
    const { notifications, unreadCount, markAllAsRead } = useNotifications();

    return (
        <DropdownMenu>
            <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-10 w-10 p-0 rounded-full flex-shrink-0">
                    <Bell className="h-5 w-5 text-gray-400" />
                    {unreadCount > 0 && (
                        <span className="absolute top-1 right-1 flex h-4 w-4">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-4 w-4 bg-red-500 text-white text-xs items-center justify-center">{unreadCount}</span>
                        </span>
                    )}
                </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-80 md:w-96 bg-gray-900 border-white/10 text-white shadow-2xl">
                <div className="flex items-center justify-between p-3">
                    <DropdownMenuLabel className="p-0 text-base font-semibold">Notifications</DropdownMenuLabel>
                    {unreadCount > 0 && (
                        <Button variant="link" className="p-0 h-auto text-sm text-primary" onClick={(e) => { e.stopPropagation(); markAllAsRead(); }}>Mark all as read</Button>
                    )}
                </div>
                <DropdownMenuSeparator className="bg-white/10"/>
                
                <div className="max-h-80 overflow-y-auto custom-scrollbar">
                    {notifications.length > 0 ? (
                        notifications.slice(0, 5).map(notification => (
                            <NotificationItem key={notification.id} notification={notification} />
                        ))
                    ) : (
                        <div className="text-center text-gray-500 p-8">
                            <p>No new notifications</p>
                        </div>
                    )}
                </div>
                <DropdownMenuSeparator className="bg-white/10"/>
                <DropdownMenuFooter className="p-1">
                    <Link to="/notifications" className="w-full">
                        <Button variant="ghost" className="w-full text-primary">View All Notifications</Button>
                    </Link>
                </DropdownMenuFooter>
            </DropdownMenuContent>
        </DropdownMenu>
    );
};

export default NotificationBell;