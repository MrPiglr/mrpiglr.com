import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { X, Loader2, Mail, Lock, Shield, ArrowRight, Github, Chrome } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useToast } from '@/components/ui/use-toast';

const backdropVariants = {
  visible: { opacity: 1 },
  hidden: { opacity: 0 }
};

const modalVariants = {
  hidden: { opacity: 0, scale: 0.9, y: 50 },
  visible: { 
    opacity: 1, 
    scale: 1, 
    y: 0,
    transition: { type: 'spring', damping: 25, stiffness: 200 }
  },
  exit: { 
    opacity: 0, 
    scale: 0.9, 
    y: 50,
    transition: { duration: 0.2 }
  }
};

const AuthModal = ({ onClose }) => {
  const [view, setView] = useState('sign_in'); // 'sign_in', 'sign_up', 'forgot_password'
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const { signIn, signUp, signInWithGitHub, signInWithGoogle, sendPasswordResetEmail } = useAuth();
  const { toast } = useToast();

  const handleAuthAction = async (action, successMessage) => {
    setLoading(true);
    const { error } = await action();
    setLoading(false);
    if (!error) {
        if (successMessage) {
            toast(successMessage);
        }
        onClose();
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (view === 'sign_in') {
      await handleAuthAction(() => signIn(email, password));
    } else if (view === 'sign_up') {
      await handleAuthAction(() => signUp(email, password), {
        title: "Account Created",
        description: "Please check your email to verify your account.",
      });
    } else if (view === 'forgot_password') {
      await handleAuthAction(() => sendPasswordResetEmail(email), {
        title: "Password Reset Email Sent",
        description: "Please check your inbox for instructions.",
      });
      if(!loading) setView('sign_in');
    }
  };

  const renderContent = () => {
    switch (view) {
      case 'forgot_password':
        return (
          <>
            <h2 className="text-2xl font-bold text-white mb-2 text-center">Forgot Password?</h2>
            <p className="text-gray-400 mb-6 text-center font-mono text-sm">Enter your email to receive a password reset link.</p>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input type="email" id="email-forgot" value={email} onChange={(e) => setEmail(e.target.value)} required className="pl-10" placeholder="Enter your email" />
              </div>
              <Button type="submit" className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white py-3 text-base flex items-center justify-center gap-2" disabled={loading}>
                {loading ? <Loader2 className="animate-spin" /> : <>Send Reset Link <ArrowRight className="w-4 h-4" /></>}
              </Button>
            </form>
             <p className="mt-6 text-center text-sm text-gray-400">
              Remembered your password?{' '}
              <button onClick={() => setView('sign_in')} className="font-medium text-primary hover:underline">
                Sign In
              </button>
            </p>
          </>
        );
      case 'sign_up':
      case 'sign_in':
      default:
        return (
          <>
            <div className="flex justify-center mb-4">
              <div className="h-16 w-16 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center">
                <Shield className="w-8 h-8 text-primary" />
              </div>
            </div>
            <h2 className="text-2xl font-bold text-center">
              {view === 'sign_in' ? 'Welcome Back' : 'Become a Contributor'}
            </h2>
            <p className="text-gray-400 mb-6 text-center font-mono text-sm">
              {view === 'sign_in' ? 'Sign in to your AeThex account' : 'Create an account to start contributing'}
            </p>

            <Button variant="outline" className="w-full mb-2 bg-transparent border-gray-700 hover:bg-gray-800" onClick={() => handleAuthAction(signInWithGitHub)} disabled={loading}>
              <Github className="mr-2 h-4 w-4"/> Continue with GitHub
            </Button>
            <Button variant="outline" className="w-full mb-4 bg-transparent border-gray-700 hover:bg-gray-800" onClick={() => handleAuthAction(signInWithGoogle)} disabled={loading}>
              <Chrome className="mr-2 h-4 w-4"/> Continue with Google
            </Button>

            <div className="relative flex py-2 items-center">
              <div className="flex-grow border-t border-gray-700"></div>
              <span className="flex-shrink mx-4 text-gray-500 text-xs font-mono">OR CONTINUE WITH EMAIL</span>
              <div className="flex-grow border-t border-gray-700"></div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <Input type="email" id="email" value={email} onChange={(e) => setEmail(e.target.value)} required className="pl-10" placeholder="Enter your email" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <Input type="password" id="password" value={password} onChange={(e) => setPassword(e.target.value)} required className="pl-10" placeholder="Enter your password" />
                </div>
              </div>

              {view === 'sign_in' && (
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="remember" />
                    <Label htmlFor="remember" className="text-sm font-normal text-gray-400">Remember me</Label>
                  </div>
                  <button onClick={() => setView('forgot_password')} type="button" className="text-sm text-primary hover:underline">Forgot password?</button>
                </div>
              )}
              
              <Button type="submit" className="w-full bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white py-3 text-base flex items-center justify-center gap-2" disabled={loading}>
                {loading ? <Loader2 className="animate-spin" /> : <>{view === 'sign_in' ? 'Sign In' : 'Create Account'} <ArrowRight className="w-4 h-4" /></>}
              </Button>
            </form>
            <p className="mt-6 text-center text-sm text-gray-400">
              {view === 'sign_in' ? "Don't have an account?" : "Already have an account?"}{' '}
              <button onClick={() => setView(view === 'sign_in' ? 'sign_up' : 'sign_in')} className="font-medium text-primary hover:underline">
                {view === 'sign_in' ? 'Sign Up' : 'Sign In'}
              </button>
            </p>
          </>
        );
    }
  };

  return (
    <motion.div
      variants={backdropVariants}
      initial="hidden"
      animate="visible"
      exit="hidden"
      className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 font-mono"
      onClick={onClose}
    >
      <motion.div
        variants={modalVariants}
        className="radial-gradient-background bg-[#0A071E] rounded-2xl border border-primary/20 max-w-md w-full shadow-2xl shadow-primary/10 text-white"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-8 relative">
          <button onClick={onClose} className="absolute top-4 right-4 z-10 text-gray-400 hover:text-white p-1 rounded-full transition-colors">
            <X className="w-5 h-5" />
          </button>
          
          {renderContent()}

        </div>
      </motion.div>
    </motion.div>
  );
};

export default AuthModal;