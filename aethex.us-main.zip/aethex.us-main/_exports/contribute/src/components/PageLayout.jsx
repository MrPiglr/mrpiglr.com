import React from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import Header from '@/components/Header';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const PageLayout = () => {
  const location = useLocation();
  const { setShowAuthModal } = useAuth();
  
  const handleAuthClick = () => {
    if (setShowAuthModal) {
      setShowAuthModal(true);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col radial-gradient-background">
      <Header onAuthClick={handleAuthClick} />
      <main className="flex-1 w-full pt-8 pb-16">
        <motion.div
          key={location.key}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          transition={{ duration: 0.5, ease: 'easeInOut' }}
          className="container mx-auto px-4"
        >
          <Outlet context={{ onAuthClick: handleAuthClick }} />
        </motion.div>
      </main>
    </div>
  );
};

export default PageLayout;