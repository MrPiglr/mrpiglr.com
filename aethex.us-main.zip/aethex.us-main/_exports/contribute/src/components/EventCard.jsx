import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, MapPin, Star, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { formatDate } from '@/lib/utils';

const cardVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { duration: 0.5, ease: "easeOut" }
  },
  exit: { 
    opacity: 0, 
    y: -30,
    transition: { duration: 0.3, ease: "easeIn" }
  }
};

const EventCard = ({ event, onSelectEvent, getCategoryColor, getCategoryLabel }) => {
  const eventUrl = `https://events.aethex.biz/event/${event.id}`;

  return (
    <motion.div
      variants={cardVariants}
      whileHover={{ y: -8, scale: 1.03 }}
      transition={{ type: 'spring', stiffness: 300 }}
      className="group relative"
      layout
    >
      <div className="bg-gray-900/50 backdrop-blur-sm rounded-2xl border border-gray-800 overflow-hidden group-hover:border-primary/50 transition-all duration-300 h-full flex flex-col shadow-lg group-hover:shadow-primary/20">
        <div className="relative h-48 overflow-hidden">
          <div className={`absolute inset-0 bg-gradient-to-br ${getCategoryColor(event.category)} opacity-30 group-hover:opacity-50 transition-opacity duration-300`}></div>
          <motion.img
            whileHover={{ scale: 1.1 }}
            transition={{ duration: 0.4 }}
            className="w-full h-full object-cover opacity-60 group-hover:opacity-80 transition-opacity duration-300" 
            alt={`${event.title} event banner`}
            src="https://images.unsplash.com/photo-1540575467063-178a50c2df87?q=80&w=2070&auto=format&fit=crop" 
          />
          <div className="absolute top-4 left-4">
            <span className="bg-black/60 backdrop-blur-sm text-white px-3 py-1 rounded-full text-xs font-medium border border-white/20">
              {getCategoryLabel(event.category)}
            </span>
          </div>
          {event.featured && (
            <motion.div 
              initial={{ scale: 0, rotate: -45 }}
              animate={{ scale: 1, rotate: 0 }}
              transition={{ delay: 0.5, type: 'spring' }}
              className="absolute top-4 right-4 z-10"
            >
              <div className="bg-yellow-500/80 backdrop-blur-sm text-black px-3 py-1 rounded-full text-xs font-semibold flex items-center border border-yellow-300/50">
                <Star className="w-3 h-3 mr-1" />
                Featured
              </div>
            </motion.div>
          )}
        </div>

        <div className="p-6 flex flex-col flex-grow">
          <h2 className="text-lg font-bold text-white mb-2 group-hover:text-primary transition-colors">
            {event.title}
          </h2>
          <p className="text-gray-400 mb-4 text-sm line-clamp-2 flex-grow">
            {event.description}
          </p>

          <div className="space-y-2 mb-6 text-sm">
            <div className="flex items-center text-gray-400">
              <Calendar className="w-4 h-4 mr-2 text-primary/70" />
              <span>{formatDate(event.date)}</span>
            </div>
            <div className="flex items-center text-gray-400">
              <MapPin className="w-4 h-4 mr-2 text-primary/70" />
              <span>{event.location}</span>
            </div>
          </div>

          <div className="flex items-center justify-between mt-auto">
            <div className="text-xl font-bold text-white">
              {event.price === 0 ? 'Free' : `$${event.price}`}
            </div>
            <Button asChild className="bg-primary hover:bg-primary/90 text-white px-4 py-2 text-sm">
              <a href={eventUrl} target="_blank" rel="noopener noreferrer">
                <span>View Details</span>
                <motion.div
                  className="inline-block"
                  whileHover={{ x: 4 }}
                >
                  <ArrowRight className="w-4 h-4 ml-2" />
                </motion.div>
              </a>
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default EventCard;