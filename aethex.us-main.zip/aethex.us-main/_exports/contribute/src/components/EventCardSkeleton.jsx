import React from 'react';
import { motion } from 'framer-motion';

const EventCardSkeleton = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="bg-gray-900/50 backdrop-blur-sm rounded-2xl border border-gray-800 overflow-hidden"
    >
      <div className="animate-pulse">
        <div className="bg-gray-800 h-48 w-full"></div>
        <div className="p-6">
          <div className="h-5 bg-gray-700 rounded w-3/4 mb-4"></div>
          <div className="h-3 bg-gray-700 rounded w-full mb-2"></div>
          <div className="h-3 bg-gray-700 rounded w-5/6 mb-6"></div>
          
          <div className="space-y-3 mb-6">
            <div className="flex items-center">
              <div className="h-4 w-4 bg-gray-700 rounded-full mr-2"></div>
              <div className="h-3 bg-gray-700 rounded w-1/2"></div>
            </div>
            <div className="flex items-center">
              <div className="h-4 w-4 bg-gray-700 rounded-full mr-2"></div>
              <div className="h-3 bg-gray-700 rounded w-1/3"></div>
            </div>
          </div>

          <div className="flex items-center justify-between mt-auto">
            <div className="h-8 bg-gray-700 rounded w-1/4"></div>
            <div className="h-10 bg-gray-700 rounded w-1/3"></div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default EventCardSkeleton;