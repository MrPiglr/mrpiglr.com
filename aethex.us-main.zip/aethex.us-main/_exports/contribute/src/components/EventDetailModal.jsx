import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, Clock, MapPin, Users, X, Loader2, ExternalLink } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { formatDate, formatTime } from '@/lib/utils';

const backdropVariants = {
  visible: { opacity: 1 },
  hidden: { opacity: 0 }
};

const modalVariants = {
  hidden: { opacity: 0, scale: 0.9, y: 50 },
  visible: { 
    opacity: 1, 
    scale: 1, 
    y: 0,
    transition: { type: 'spring', damping: 25, stiffness: 200 }
  },
  exit: { 
    opacity: 0, 
    scale: 0.9, 
    y: 50,
    transition: { duration: 0.2 }
  }
};

const EventDetailModal = ({ event, onClose, onRegister, onUnregister, isRegistered, getCategoryColor, getCategoryLabel, isLoading }) => {
  const eventUrl = `https://events.aethex.biz/event/${event.id}`;
  
  return (
    <motion.div
      variants={backdropVariants}
      initial="hidden"
      animate="visible"
      exit="hidden"
      className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        variants={modalVariants}
        className="bg-gray-900 rounded-2xl border border-gray-800 max-w-4xl w-full max-h-[90vh] overflow-y-auto shadow-2xl shadow-primary/10"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 z-10 bg-black/50 hover:bg-black/70 text-white p-2 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="relative h-64 overflow-hidden rounded-t-2xl">
            <div className={`absolute inset-0 bg-gradient-to-br ${getCategoryColor(event.category)} opacity-30`}></div>
            <motion.img
              initial={{ scale: 1.1, opacity: 0.7 }}
              animate={{ scale: 1, opacity: 0.6 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="w-full h-full object-cover" 
              alt={`${event.title} detailed view`}
              src="https://images.unsplash.com/photo-1523580494863-6f3031224c94?q=80&w=2070&auto=format&fit=crop" 
            />
            <motion.div 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="absolute bottom-6 left-6"
            >
              <span className="bg-black/60 backdrop-blur-sm text-white px-4 py-2 rounded-full font-medium border border-white/20">
                {getCategoryLabel(event.category)}
              </span>
            </motion.div>
          </div>

          <div className="p-8">
            <div className="flex flex-col lg:flex-row gap-8">
              <div className="flex-1">
                <h1 className="text-3xl font-bold text-white mb-4">{event.title}</h1>
                <p className="text-gray-300 mb-6 leading-relaxed">{event.full_description}</p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  <div className="space-y-4">
                    <h2 className="text-xl font-semibold text-white mb-3">Event Details</h2>
                    <div className="space-y-3">
                      <div className="flex items-center text-gray-300"><Calendar className="w-5 h-5 mr-3 text-primary" /><span>{formatDate(event.date)}</span></div>
                      <div className="flex items-center text-gray-300"><Clock className="w-5 h-5 mr-3 text-primary" /><span>{formatTime(event.time)}</span></div>
                      <div className="flex items-center text-gray-300"><MapPin className="w-5 h-5 mr-3 text-primary" /><span>{event.location}</span></div>
                      <div className="flex items-center text-gray-300"><Users className="w-5 h-5 mr-3 text-primary" /><span>{event.registered_count}/{event.capacity} registered</span></div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <h2 className="text-xl font-semibold text-white mb-3">Speakers</h2>
                    <ul className="space-y-2 list-disc list-inside text-gray-300">
                      {event.speakers && event.speakers.map((speaker, index) => <li key={index}>{speaker}</li>)}
                    </ul>
                  </div>
                </div>

                <div className="mb-8">
                  <h2 className="text-xl font-semibold text-white mb-4">Agenda</h2>
                  <div className="space-y-3">
                    {event.agenda && event.agenda.map((item, index) => (
                      <div key={index} className="flex items-start gap-4 p-4 bg-gray-900/50 rounded-lg border border-gray-800">
                        <div className="text-primary font-semibold min-w-[4rem]">{item.time}</div>
                        <div className="text-gray-300">{item.title}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="lg:w-80">
                <div className="bg-gray-900/50 rounded-xl p-6 border border-gray-800 sticky top-6">
                  <div className="text-center mb-6">
                    <div className="text-3xl font-bold text-white mb-2">{event.price === 0 ? 'Free' : `$${event.price}`}</div>
                    <div className="text-gray-400">per person</div>
                  </div>
                  <div className="mb-6">
                    <div className="flex justify-between text-sm text-gray-400 mb-2">
                      <span>Availability</span>
                      <span>{event.capacity - event.registered_count} spots left</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2.5">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${(event.registered_count / event.capacity) * 100}%` }}
                        transition={{ duration: 1, ease: 'easeOut' }}
                        className="bg-primary h-2.5 rounded-full"
                      ></motion.div>
                    </div>
                  </div>
                  {isRegistered ? (
                    <div className="space-y-3">
                      <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4 text-center">
                        <div className="text-green-400 font-semibold">✓ Registered</div>
                        <div className="text-green-300 text-sm mt-1">You're all set!</div>
                      </div>
                      <Button onClick={() => onUnregister(event.id)} variant="outline" className="w-full border-red-500/30 text-red-400 hover:bg-red-500/10 hover:text-red-300" disabled={isLoading}>
                         {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
                        Cancel Registration
                      </Button>
                    </div>
                  ) : (
                    <Button asChild className="w-full bg-primary hover:bg-primary/90 text-white py-3 text-base" disabled={event.registered_count >= event.capacity}>
                        <a href={eventUrl} target="_blank" rel="noopener noreferrer">
                          {event.registered_count >= event.capacity ? 'Event Full' : 'Register Now'}
                          <ExternalLink className="ml-2 h-4 w-4"/>
                        </a>
                    </Button>
                  )}
                  <div className="mt-4 text-xs text-gray-500 text-center">Registration and details are managed on our dedicated events platform.</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default EventDetailModal;