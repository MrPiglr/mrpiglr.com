import React from 'react';
import { AnimatePresence } from 'framer-motion';
import { Toaster } from '@/components/ui/toaster';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useSite } from '@/contexts/SiteContext';
import LoadingScreen from '@/components/LoadingScreen';
import MaintenanceScreen from '@/components/MaintenanceScreen';
import AuthModal from '@/components/AuthModal';
import { Route, Routes, useLocation, Navigate } from 'react-router-dom';

import PageLayout from '@/components/PageLayout';
import HomePage from '@/pages/HomePage';
import AboutPage from '@/pages/AboutPage';
import TeamPage from '@/pages/TeamPage';
import TechnologyPage from '@/pages/TechnologyPage';
import NewsPage from '@/pages/NewsPage';
import ContactPage from '@/pages/ContactPage';
import PrivacyPolicyPage from '@/pages/PrivacyPolicyPage';
import TermsAndConditionsPage from '@/pages/TermsAndConditionsPage';
import MyProfilePage from '@/pages/MyProfilePage';
import GetInvolvedPage from '@/pages/GetInvolvedPage';
import MyTicketsPage from '@/pages/MyTicketsPage';
import NotificationsPage from '@/pages/NotificationsPage';

import ProtectedRoute from '@/components/ProtectedRoute';
import AdminLayout from '@/pages/admin/AdminLayout';
import AdminDashboardPage from '@/pages/admin/AdminDashboardPage';
import AdminContributorsPage from '@/pages/admin/AdminContributorsPage';
import AdminProjectsPage from '@/pages/admin/AdminProjectsPage';
import AdminTicketsPage from '@/pages/admin/AdminTicketsPage';
import AdminSettingsPage from '@/pages/admin/AdminSettingsPage';

const AppContent = () => {
  const { showAuthModal, setShowAuthModal, loading: authLoading, profile } = useAuth();
  const { siteConfig, loading: siteLoading } = useSite();
  const location = useLocation();

  if (authLoading || siteLoading) {
    return <LoadingScreen />;
  }

  const isMaintenance = siteConfig?.system_status === 'maintenance';
  const isAdmin = profile && ['admin', 'site_owner', 'oversee'].includes(profile.role);

  if (isMaintenance && !isAdmin) {
    return <MaintenanceScreen message={siteConfig.system_status_message} />;
  }

  return (
    <>
      <AnimatePresence mode="wait">
        <Routes location={location} key={location.pathname}>
          <Route element={<PageLayout />}>
            <Route path="/" element={<HomePage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/get-involved" element={<GetInvolvedPage />} />
            <Route path="/team" element={<TeamPage />} />
            <Route path="/technology" element={<TechnologyPage />} />
            <Route path="/news" element={<NewsPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/privacy" element={<PrivacyPolicyPage />} />
            <Route path="/terms" element={<TermsAndConditionsPage />} />
            <Route path="/profile" element={
              <ProtectedRoute>
                <MyProfilePage />
              </ProtectedRoute>
            } />
            <Route path="/my-tickets" element={
              <ProtectedRoute>
                <MyTicketsPage />
              </ProtectedRoute>
            } />
            <Route path="/notifications" element={
              <ProtectedRoute>
                <NotificationsPage />
              </ProtectedRoute>
            } />
          </Route>

          <Route path="/admin" element={
            <ProtectedRoute adminOnly>
              <AdminLayout />
            </ProtectedRoute>
          }>
            <Route index element={<AdminDashboardPage />} />
            <Route path="contributors" element={<AdminContributorsPage />} />
            <Route path="projects" element={<AdminProjectsPage />} />
            <Route path="tickets" element={<AdminTicketsPage />} />
            <Route path="settings" element={<AdminSettingsPage />} />
            <Route path="*" element={<Navigate to="/admin" replace />} />
          </Route>

        </Routes>
      </AnimatePresence>

      <AnimatePresence>
        {showAuthModal && <AuthModal onClose={() => setShowAuthModal(false)} />}
      </AnimatePresence>
      
      <Toaster />
    </>
  );
};

function App() {
  return <AppContent />;
}

export default App;