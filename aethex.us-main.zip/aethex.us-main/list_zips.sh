#!/bin/bash
echo "=== Contribute.zip contents ==="
unzip -l "/workspaces/aethex.us/Contribute.zip" 2>&1
echo ""
echo "=== Events (2).zip contents ==="
unzip -l "/workspaces/aethex.us/Events (2).zip" 2>&1
echo ""
echo "=== gameforge.zip contents ==="
unzip -l "/workspaces/aethex.us/gameforge.zip" 2>&1
