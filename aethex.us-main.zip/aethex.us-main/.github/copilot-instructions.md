# AeThex.us Copilot Instructions

## Project Overview

AeThex.us is the main website for AeThex, built with Astro. The platform is organized into three Trinity divisions:

- **Foundation** (Red) - Education, community programs, and mentorship for developers
- **Corporation** (Blue) - Technology conglomerate powering digital ecosystems and platforms  
- **Labs** (Yellow) - The Grid bounty platform for creators to ship code and earn rewards

## Tech Stack

- **Framework**: Astro 5.x (static site generator)
- **Styling**: CSS with custom properties, no CSS frameworks
- **Fonts**: System fonts + JetBrains Mono for code
- **Icons**: Emoji-based icons throughout

## Project Structure

```
src/
├── components/     # Reusable Astro components
├── layouts/        # Page layouts (MainLayout.astro)
├── pages/          # All page routes
│   ├── index.astro         # Homepage
│   ├── foundation.astro    # Foundation division
│   ├── corporation.astro   # Corporation division
│   ├── labs.astro          # Labs division (The Grid)
│   ├── gameforge.astro     # GameForge product (Labs)
│   └── docs/               # Documentation pages
public/
├── favicon.svg     # Trinity circles logo
├── global.css      # Global styles
└── *.svg           # Logo assets
```

## Development Commands

```bash
npm install    # Install dependencies
npm run dev    # Start dev server (localhost:4321)
npm run build  # Build for production
```

## Design Guidelines

- **Trinity Colors**: Red (#FF0000), Blue (#0066ff), Yellow (#EAB308)
- **Dark Theme**: Primary backgrounds #0a0a0a, #0f0f0f, #1a1a1a
- **Responsive Breakpoints**: 1024px (tablet), 768px (mobile), 480px (small)
- **Animations**: Subtle CSS transitions, avoid heavy JavaScript animations

## Key Conventions

1. Each Trinity page has a distinct visual identity matching its purpose
2. Use scoped `<style>` blocks in Astro components
3. Mobile-first responsive design with comprehensive breakpoints
4. Keep external dependencies minimal
5. All educational content is free (Foundation mission)

## Notes

- GameForge is a **Labs product**, not a Trinity division
- The favicon shows three overlapping circles (Red, Blue, Yellow)
- Partner logos in public/ folder are placeholder SVGs
