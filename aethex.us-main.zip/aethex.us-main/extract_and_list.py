import zipfile
import os

base_path = "/workspaces/aethex.us"
output_base = os.path.join(base_path, "_extracted")
os.makedirs(output_base, exist_ok=True)

zips = [
    ("Contribute.zip", "contribute"),
    ("Events (2).zip", "events"),
    ("gameforge.zip", "gameforge")
]

for zip_name, folder_name in zips:
    zip_path = os.path.join(base_path, zip_name)
    out_path = os.path.join(output_base, folder_name)
    os.makedirs(out_path, exist_ok=True)
    
    print(f"\n=== {zip_name} ===")
    try:
        with zipfile.ZipFile(zip_path, 'r') as z:
            files = z.namelist()
            print(f"Total files: {len(files)}")
            for f in files[:30]:
                print(f"  {f}")
            if len(files) > 30:
                print(f"  ... and {len(files) - 30} more")
            z.extractall(out_path)
            print(f"Extracted to {out_path}")
    except Exception as e:
        print(f"Error: {e}")
