#!/bin/bash
cd /workspaces/aethex.us
mkdir -p _exports/contribute _exports/events _exports/gameforge
unzip -o "Contribute.zip" -d _exports/contribute
unzip -o "Events (2).zip" -d _exports/events
unzip -o "gameforge.zip" -d _exports/gameforge
echo "=== CONTRIBUTE ==="
find _exports/contribute -type f | head -50
echo "=== EVENTS ==="
find _exports/events -type f | head -50
echo "=== GAMEFORGE ==="
find _exports/gameforge -type f | head -50
